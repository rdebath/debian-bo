/*  $Id: bugs.h,v 1.5 1995/11/25 02:31:18 davem Exp $
 *  include/asm-sparc/bugs.h:  Sparc probes for various bugs.
 *
 *  Copyright (C) 1994 David S. Miller (davem@caip.rutgers.edu)
 */

static void check_bugs(void) { }
