/* $Id: clock.h,v 1.3 1995/11/25 02:31:25 davem Exp $
 * clock.h:  Definitions for clock operations on the Sparc.
 *
 * Copyright (C) 1995 David S. Miller (davem@caip.rutgers.edu)
 */
#ifndef _SPARC_CLOCK_H
#define _SPARC_CLOCK_H

/* Foo for now. */

#endif /* !(_SPARC_CLOCK_H) */
