/*
 * This file is included by 'init/main.c'
 */

void
check_bugs(void)
{
} 
