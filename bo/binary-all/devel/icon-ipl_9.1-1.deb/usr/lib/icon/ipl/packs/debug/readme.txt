DEBUGIFY.DOC is formatted for a printer set to 66 lines per inch
with a fixed width font.  Printing to most dot matrix and daisy wheel printers is
a cinch since this is the default format.  For instance a simple
"copy DEBUGIFY.DOC PRN" would work under MS-DOS.  I believe that
sending this file directly to a Postscript printer would trigger a Diablo
printer emulation (or maybe that's only for Laserwriters?).  If you have an HP
LaserJet, DeskJet, or compatible, set the printer to 66 lpi and 10cpi or 12 cpi
either using the front panel or a software utility.