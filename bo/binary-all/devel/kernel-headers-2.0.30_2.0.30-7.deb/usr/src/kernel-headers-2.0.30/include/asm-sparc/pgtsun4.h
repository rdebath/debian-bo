/* $Id: pgtsun4.h,v 1.2 1995/11/25 02:32:26 davem Exp $
 * pgtsun4.c:  Regular Sun4 MMU support goes in here.
 *
 * Copyright (C) 1995 David S. Miller (davem@caip.rutgers.edu)
 */

#ifndef _SPARC_PGTSUN4_H
#define _SPARC_PGTSUN4_H

#endif /* !(_SPARC_PGTSUN4_H) */
