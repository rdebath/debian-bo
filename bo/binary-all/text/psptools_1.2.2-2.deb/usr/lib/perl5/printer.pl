
require 'printcap.pl';

{

#
# printer.pl: utility routines for printers.
#
# Yves Arrouye <Yves.Arrouye@marin.fdn.fr>, 1996.
#

package printer;

#

sub printertype {
    local($printer, $pcap_type) = @_;
    local($ptype);

    &printcap::printcap($printer);

    $pcap_type = 'ty' unless $pcap_type;

    $ptype = $main::PRINTCAP{$pcap_type};

    local($ptypevar) = $printer;
    $ptypevar =~ tr/[a-z]/[A-Z]/;

    $ptype = $ENV{"{$ptypevar}_PRINTER_TYPE"} unless $ptype;
    $ptype = $ENV{'PRINTER_TYPE'} unless $ptype;

    $ptype = $ENV{"{$ptypevar}_PPD"} unless $ptype;
    $ptype = $ENV{'PPD'} unless $ptype;

    return $ptype;
}

#
# printers()
#
# Return a list of available printers.
#

sub printers {
    local($printcap) = '';
}

}

1;

