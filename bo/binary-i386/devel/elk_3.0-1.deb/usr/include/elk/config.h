/* This file was produced by the Makefile in this directory.
 * If you want to change the value of a constant, edit ../config/system
 * or ../config/site and run make again.
 */

#define          REGCOMP
#define          WAITPID
#define            WAIT3
#define            WAIT4
#define           MKTEMP
#define           TMPNAM
#define          TEMPNAM
#define           GETCWD
#define            GETWD
#define           RENAME
#define            UNAME
#define      GETHOSTNAME
#define     GETTIMEOFDAY
#define            FTIME
#define            VFORK
#define          VPRINTF
#define           DIRENT
#define           RANDOM
#define INCLUDE_UNISTD_H
#undef SYSCONF_OPEN_MAX
#define    GETDTABLESIZE
#define PATHCONF_PATH_MAX
#define      GETPAGESIZE
#undef SYSCONF_PAGESIZE
#undef      BSD_SIGNALS
#define    POSIX_SIGNALS
#undef      ALIGN_8BYTE
#undef             COFF
#undef            ECOFF
#undef            XCOFF
#define              ELF
#undef            MACH_O
#undef           CONVEX_AOUT
#undef             HP9K
#define   HPSHLIB
#define       DEBUG_DUMP
#define     CAN_LOAD_OBJ
#undef           USE_LD
#undef          USE_RLD
#undef          USE_SHL
#define       USE_DLOPEN
#  define              LOAD_LIBRARIES    ""
#define       CACHECTL_H        <sys/cachectl.h>
#define       FIONREAD_H        <termios.h>
#  define         ATEXIT
#undef  SYMS_BEGIN_WITH   
#define         CAN_DUMP
#  define              SEG_SIZ           1024
#  define              FILE_TEXT_START   N_TXTOFF(hdr)
#  define              MEM_TEXT_START    0
#  define              TEXT_LENGTH_ADJ   0
#  define              COFF_PAGESIZE     4096
#  undef  FCHMOD_BROKEN
#define           TERMIO
#undef        FLUSH_BSD
#undef     FLUSH_FPURGE
#undef  FLUSH_TIOCFLUSH
#define     FLUSH_TCFLSH
#define       USE_ALLOCA
#define INCLUDE_ALLOCA_H
#undef    PRAGMA_ALLOCA
#undef   MAX_STACK_SIZE    
#define  GENERATIONAL_GC
#undef         HAS_MPROTECT
#undef    MPROTECT_MMAP
#undef     SIGSEGV_SIGINFO
#undef  SIGSEGV_SIGCONTEXT
#undef        SIGSEGV_ARG4
#undef         SIGSEGV_AIX
#undef        SIGSEGV_HPUX




#define                AOUT_H            <a.out.h>
#define                SCM_DIR           "/usr/lib/elk/scm"
#define                OBJ_DIR           "/usr/lib/elk/obj"
#define                HEAP_SIZE         1024
#define                FIND_AOUT         defined(USE_LD) || defined(CAN_DUMP)\
				      || defined(INIT_OBJECTS)
#if !defined(WANT_PROTOTYPES) && !defined(NO_PROTOTYPES)
#  define       WANT_PROTOTYPES
#  undef         NO_PROTOTYPES
#endif
#define         ANSI_CPP
#define                SYSTEMTYPE        "i486-linux-gcc"
#define                GETGROUPS_TYPE    gid_t
#define                LD_NAME           "ld"
#define                LDFLAGS_SHARED    "-shared"
#define                INC_LDFLAGS       "-x -static"
#define          UTIME_H
#define                INIT_PREFIX       "elk_init_"
#define                FINIT_PREFIX      "elk_finit_"
#define                ELK_MAJOR         3
#define                ELK_MINOR         0
