/* whattime.h --- see whattime.c for explanation */

#ifndef __WHATTIME_H
#define __WHATTIME_H

void print_uptime(void);
char *sprint_uptime(void);

#endif
