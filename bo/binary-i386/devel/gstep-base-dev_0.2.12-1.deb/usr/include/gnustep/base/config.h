/* src/include/config.h.  Generated automatically by configure.  */
/* src/include/config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* #undef SYS_AUTOLOAD */
#define CON_AUTOLOAD 1

#define NeXT_cc 0
#define NeXT_runtime 0

#define VSPRINTF_RETURNS_LENGTH 1

/* Define if you have the register_printf_function function.  */
#define HAVE_REGISTER_PRINTF_FUNCTION 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the times function.  */
#define HAVE_TIMES 1

/* Define if you have the valloc function.  */
#define HAVE_VALLOC 1

/* Define if you have the vsprintf function.  */
#define HAVE_VSPRINTF 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/rusage.h> header file.  */
/* #undef HAVE_SYS_RUSAGE_H */

/* Define if you have the <ucbinclude/sys/resource.h> header file.  */
/* #undef HAVE_UCBINCLUDE_SYS_RESOURCE_H */

/* Define if you have the <values.h> header file.  */
#define HAVE_VALUES_H 1

/* Define if you have the nsl library (-lnsl).  */
/* #undef HAVE_LIBNSL */

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */
