#include_next <curses.h>
#include <sgtty.h>
