#include_next <ctype.h>

#undef isalnum
#define isalnum(c) (isalpha(c) || isdigit(c))
