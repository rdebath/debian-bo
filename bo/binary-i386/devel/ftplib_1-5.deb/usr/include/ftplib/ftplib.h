#if defined(__unix__) || defined(VMS)
#define GLOBALDEF
#define GLOBALREF extern
#elif defined(_WIN32)
#define GLOBALDEF __declspec(dllexport)
#define GLOBALREF __declspec(dllimport)
#endif

GLOBALREF char *ftplib_lastresp;
GLOBALREF int ftplib_debug;
GLOBALREF void ftpInit(void);
GLOBALREF int ftpOpen(char *host);
GLOBALREF int ftpLogin(char *user, char *pass);
GLOBALREF int ftpSite(char *cmd);
GLOBALREF int ftpMkdir(char *path);
GLOBALREF int ftpChdir(char *path);
GLOBALREF int ftpRmdir(char *path);
GLOBALREF int ftpNlst(char *output, char *path);
GLOBALREF int ftpDir(char *output, char *path);
GLOBALREF int ftpGet(char *output, char *path, char mode);
GLOBALREF int ftpPut(char *input, char *path, char mode);
GLOBALREF int ftpRename(char *src, char *dst);
GLOBALREF int ftpDelete(char *fnm);
GLOBALREF void ftpQuit(void);
