#if HAVE_CONFIG_H
#include <config.h>
#endif

#include <stdlib.h>

#if HAVE_UNISTD_H
#include <unistd.h>
#endif

#include <curses.h>

#if !defined(__GNUC__) && !defined(__attribute__)
#define __attribute__(p) /*nothing*/
#endif

