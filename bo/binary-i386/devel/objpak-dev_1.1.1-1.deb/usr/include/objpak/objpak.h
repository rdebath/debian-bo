
/*
 * ObjectPak Objective C Class Library
 */

#ifndef __objpak__
#define __objpak__

#define __objpak_revision__ "1.1.1"

#include "ObjCltn.h"
#include "ObjPak.h"
#include "ObjDic.h"
#include "ObjSet.h"
#include "ObjSeq.h"
#include "ObjSort.h"
#include "ObjStr.h"

#endif /* __objpak__ */

