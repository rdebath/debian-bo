/* runtime/conf.h.  Generated automatically by configure.  */
/*
** Copyright (C) 1995 University of Melbourne.
** This file may only be copied under the terms of the GNU Library General
** Public License - see the file COPYING.LIB in the Mercury distribution.
*/
/*
** @configure_input@
*/
/*
**	Various configuration parameters, generally automatically by
**	the auto-configuration script.  Their meanings are:
**
**	WORD_TYPE		the base type for the definition of Word.
**	LOW_TAG_BITS		the number of low-order tag bits we can use.
**	BOXED_FLOAT		double precision floats do not fit in a Word,
**				and must be boxed.
**	HAVE_SYSCONF		the machine has the sysconf() syscall.
**	HAVE_GETPAGESIZE	the machine has the getpagesize() syscall.
**	HAVE_MEMALIGN		the machine has the memalign() function.
**	HAVE_MPROTECT		the machine has the mprotect() syscall.
**	HAVE_STRERROR		the machine has the strerror() function.
**	RETSIGTYPE		the return type of signal handlers.
**	HAVE_SIGINFO		signal handlers are given siginfo arguments.
**				we have <sys/siginfo.h>
**	HAVE_UCONTEXT		signal handlers are given ucontext arguments
**				we have <ucontext.h>
**	HAVE_SYS_UCONTEXT	we have <sys/ucontext.h>
**	HAVE_SYS_TIME		we have <sys/time.h>
**	HAVE_SYS_PARAM		we have <sys/param.h>
**	HAVE_SETITIMER		we have setitimer()
**	PC_ACCESS		the way to access the saved PC in ucontexts.
**	PC_ACCESS_GREG		PC_ACCESS is in a gregs (general regs) array
**	HAVE_SIGACTION		the machine has the sigaction() syscall.
**	SIGACTION_FIELD		the name of the field in the sigaction struct
**				(either sa_handler or sa_sigaction).
*/

#define	WORD_TYPE int
#define	LOW_TAG_BITS 2
#define	BOXED_FLOAT 1
#define	HAVE_SYSCONF 1
#define	HAVE_GETPAGESIZE 1
#define	HAVE_MEMALIGN 1
#define	HAVE_MPROTECT 1
#define	HAVE_STRERROR 1
#define	RETSIGTYPE void
/* #undef	HAVE_SIGINFO */
/* #undef	HAVE_UCONTEXT */
/* #undef	HAVE_SYS_UCONTEXT */
#define	HAVE_SYS_TIME 1
#define	HAVE_SYS_PARAM 1
#define	HAVE_SETITIMER 1
/* #undef	PC_ACCESS */
/* #undef	PC_ACCESS_GREG */
#define	HAVE_SIGACTION 1
#define	SIGACTION_FIELD sa_handler
