/* Function prototype for the c_main() function defined in c_main.c */
void c_main(void);
