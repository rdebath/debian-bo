/* iluconf.h.  Generated automatically by configure.  */
#ifndef	_iluconf_h_
#define	_iluconf_h_

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
/* #undef WORDS_BIGENDIAN */

/* The number of bytes in a char */
#define SIZEOF_CHAR 1

/* Define this if the "char" type is unsigned */
/* #undef __CHAR_UNSIGNED__ */

/* The number of bytes in a short */
#define SIZEOF_SHORT 2

/* The number of bytes in an int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a void *.  */
#define SIZEOF_VOID_P 4

/* The number of bytes in a function pointer (void (*) (void)) */
#define SIZEOF_FN_P 4

/* The number of bytes in a long long.  */
#define SIZEOF_LONG_LONG 8

/* The number of bytes in a long double.  */
#define SIZEOF_LONG_DOUBLE 12

/* The number of bytes in an enum.  */
#define SIZEOF_ENUM 4

/* Whether there's a natural mapping for LONG CARDINAL */
#define LONG_CARDINAL_TYPE unsigned long long

/* Whether there's a natural mapping for LONG INTEGER */
#define LONG_INTEGER_TYPE long long

/* Whether there's a natural mapping for LONG REAL */
/* #undef LONG_REAL_TYPE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define this to be the appropriate type to use for places where "size_t" should really be used. */
#define SIZE_T size_t

/* Define this if you have alloca() in your libc */
/* #undef HAVE_ALLOCA */

/* Define if you don't have vprintf but do have _doprnt.  */
/* #undef HAVE_DOPRNT */

/* Define if you have the vprintf function.  */
#define HAVE_VPRINTF 1

/* Define if you have the gettimeofday function.  */
#define HAVE_GETTIMEOFDAY 1

/* Define if you have the BSD-ish function `getwd' */
#define HAVE_GETWD 1

/* Define if you have the strdup function.  */
#define HAVE_STRDUP 1

/* Define if you have the popen function.  */
/* #undef HAVE_POPEN */

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if SIG_IGN is broken.  */
/* #undef SIG_IGN_BROKEN */

/* Define if the system automatically restarts a system call that is
     interrupted by a signal */
/* #undef HAVE_RESTARTABLE_SYSCALLS */

/* Define if the system is more or less POSIX-compliant */
#define _IS_POSIX 1

/* HP UX seems to need the following defined to have the ANSI C header files work properly */
/* #undef _INCLUDE_POSIX_SOURCE */

/* Define this if you are using the #include files that come with the GNU C library */
/* #undef ILU_USING_GLIBC */

/* Define if the system has some BSD networking calls */
#define _IS_BSD 1

/* Define if the system has has a BSD-style socket library */
#define _HAS_SOCKETS 1

/* Define this if your POSIX way of doing nonblocking I/O is broken the same
   way SunOS 4.1 is broken */
/* #undef HAS_SOLARIS1_NONBLOCKING_BUG */

/* Define this if your POSIX getgroups call requires an int[] argument instead of
   the standard gid_t[] argument, as in SunOS 4.1 with acc */
/* #undef HAS_SOLARIS1_GID_T_SIZE_BUG */

/* Define this if your socket recv/send calls are broken over TCP as they are for
   Solaris 2.{4,5} */
/* #undef HAS_SOLARIS2_TCP_SOCKET_BUG */

/* Define this if your pthreads code is broken in the following way:

``On canaima, <pthread.h> says

int
pthread_mutex_init _CMA_PROTOTYPE_ ((
	pthread_mutex_t		*mutex,
	pthread_mutexattr_t	attr));

but the actual POSIX threads standard (P1003.1c) says the second argument
should be of type "pthread_mutexattr_t*".  I can't figure out how to write any
unconditional C code that's both standard-compliant and OSF1-compliant, so I'm
introducing a feature-test macro for this bug.  The macro is
"DEC_OSF1_PTHREADS_BUG".  It needs to be #defined on systems with this bug, and
not on others.''
*/

/* #undef HAS_DEC_OSF1_PTHREADS_BUG */

/* Define this if you're building the Solaris 2 thread support */
/* #undef ILU_SOLARIS2_THREADS */

/* Define this if you're building the Posix thread support */
/* #undef ILU_POSIX_THREADS */

/* Define this if you're building the WIN32 thread support */
/* #undef ILU_WIN32_THREADS */

/* Define if you need to include sys/select.h to use select(2) */
/* #undef _NEEDS_SELECT_H */

/* Define this if your system needs to #include <netinet/tcp.h>
   to get the NODELAY flag defined (BSDI 2.0 needs this) */
/* #undef ILU_NEEDS_NETINET_TCP_H_FOR_NODELAY */

/* Define this if you want debugging print statements included in the kernel */
#define ENABLE_DEBUGGING 1

/* Define this to be the value of the ILU registry directory */
/* #undef REGISTRY_LAST_RESORT */

/* Define this to be the value of the ILU root directory */
#define ILUHOME "/usr"

/* Define this to be the value of the ILU simple binding directory, if using shared files for simple binding */
#define ILU_BINDING_DIRECTORY "/var/run/ilu/binding"

/* Define this to be the domain of the simple binding server, if using ILU service for simple binding */
/* #undef ILU_BINDING_REALM */

/* Define this to be the host ip addr of the simple binding server, if using ILU service for simple binding */
/* #undef ILU_BINDING_HOST */

/* Define this to be the network port on the binding host, if using ILU service for simple binding */
/* #undef ILU_BINDING_PORT */

/* Define this to be the binding multicast address, if using multicast for simple binding */
/* #undef ILU_BINDING_MCASTADDR */

/* Define this if you are including support for Sun RPC protocol */
#define SUNRPC_PROTOCOL 1

/* Define this if you are including support for XNS Courier protocol */
#define COURIER_PROTOCOL 1

/* Define this if you are including support for World Wide Web HTTP protocol */
#define HTTP_PROTOCOL 1

/* Define this if you are including support for CORBA GIOP protocol */
#define IIOP_PROTOCOL 1

/* Define this if you are including support for the W3C NG protocol */
/* #undef W3NG_PROTOCOL */

/* Define this if you are including support for TCP/IP transport via sockets */
#define TCPIP_TRANSPORT 1

/* Define this if you are including support for UDP/IP transport via sockets */
#define UDPSOCKET_TRANSPORT 1

/* Define this if you are including support for XNS/SPP transport via TLI */
/* #undef XNSSPP_TRANSPORT */

/* Define this if you are including support for the Sun RPC record marking transport filter */
#define SUNRPCRM_TRANSPORT 1

/* Define this if you are including support for the W3C multiplexing record marking transport filter */
/* #undef W3MUX_TRANSPORT */

/* Define this if you are including support for the secure transport filter */
/* #undef SECURE_TRANSPORT */

/* Define this if you are including support for the SSL security mechanism */
/* #undef INCLUDE_SSL_SECMECH */

/* Define this if you are including support for the Sun RPC UNIX auth protocol */
/* #undef USE_SUNRPC_UNIX_AUTHENTICATION */

/* Define this is the Python libraries are installed (with libainstall) */
/* #undef PYTHON_LIBRARIES_INSTALLED */

#endif	/* _iluconf_h_ */
