#ifndef _CONFSTR_H
#define _CONFSTR_H

#ifndef CS_PATH
#define CS_PATH	"/bin:/usr/bin"
#endif

#endif /* _CONFSTR_H */
