#ifndef __LINUX_SMPLOCK_H
#define __LINUX_SMPLOCK_H

#ifdef __SMP__
#include <asm/pgtable.h>
#include <asm/smp_lock.h>
#endif

#endif
