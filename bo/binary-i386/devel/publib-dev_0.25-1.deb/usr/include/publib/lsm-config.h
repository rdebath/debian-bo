/* lsm-config.h.  Generated automatically by configure.  */
/*
 * File:	lsm-config.h (or lsm-config.h.in)
 * Purpose:	Configuration file for Publib's lsm module
 * Note:	This file is/has been processed by autoconf
 */
 
#ifndef __publib_lsm_config_h_included
#define __publib_lsm_config_h_included

#define HAVE_STRNCASECMP 1

#endif
