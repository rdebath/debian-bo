/*
 *	Nothing here yet.
 */

#ifndef _ASMI86_IOCTL_H
#define _ASMI86_IOCTL_H


#endif /* _ASMI86_IOCTL_H */
