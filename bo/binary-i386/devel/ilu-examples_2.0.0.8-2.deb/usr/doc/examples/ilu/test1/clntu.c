/* $Id: clntu.c,v 1.1 1996/04/03 23:06:57 spreitze Exp $ */
/* Last edited by Mike Spreitzer April 3, 1996 2:43 pm PST */

#include "clnt.h"

int main(int ac, char **av)
{
  return doit();
}
