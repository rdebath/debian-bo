// The -*- C++ -*- setjmp/longjmp header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSETJMP__
#define __CSETJMP__
#include <setjmp.h>
#endif

