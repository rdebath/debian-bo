#ifndef _strclass_h
#define _strclass_h
#include <String.h>
typedef class String string;
#endif
