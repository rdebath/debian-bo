#! /usr/bin/perl 
#
#  driver.pl
#
#  $Id: driver.pl.in,v 1.15 1997/03/21 10:26:20 cg Exp $
#
#  SGML-Tools driver core. This contains all the basic functionality
#  we need to control all other components.
#
#  � Copyright 1996, Cees de Groot.
#
require 5.003;

#
#  Configuration
#
$prefix = "/usr";
$LibDir = "${prefix}/lib/sgml-tools";
$BinDir = "${prefix}/bin";

use File::Basename;
use Cwd;

$progs = {};
$progs->{NSGMLS} = "/usr/bin/nsgmls";
$progs->{SGMLSASP} = "${prefix}/bin/sgmlsasp";
$progs->{GROFF} = "/usr/bin/groff";

#
#  Utils is not a real package, just splitted from the main file. Maybe
#  we should correct this...
#
require "$LibDir/utils.pl";
use subs qw(Usage);

#
#  Get our packages
#
unshift (@INC, $LibDir);
require Lang;

&trapSignals;

#
#  Register the ``global'' pseudoformat.
#
$global = {};
$global->{NAME} = "global";
$global->{HELP} = "";
$global->{OPTIONS} = [
  { option => "papersize", type => "l",
    'values' => [ "a4", "letter" ], short => "s" },
  { option => "language",  type => "l",
    'values' => [ @Lang::Languages ], short => "l" },
  { option => "charset",   type => "l",
    'values' => [ "latin", "ascii" ], short => "c" },
  { option => "style",     type => "s", short => "S" },
  { option => "tabsize",   type => "i", short => "t" },
  { option => "verbose",   type => "f", short => "v" },
  { option => "debug",     type => "f", short => "d" }
];
$global->{papersize} = "a4";
$global->{language}  = "en";
$global->{charset}   = "ascii";
$global->{style}     = "";
$global->{tabsize}   = 8;
$global->{verbose}   = 0;
$global->{debug}     = 0;
$Formats{$global->{NAME}} = $global;
$FmtList{$global->{NAME}} = $global;

#
#  Used when $theFormat is global (from sgmlcheck).
#
$global->{preNSGMLS} = <<'EOF';
  $NsgmlsOpts .= " -s ";
  $ENV{SGML_SEARCH_PATH} =~ s/global/latex2e/;
EOF

#
#  Register all formats
#
while (<$LibDir/fmt_*.pl>)
{
  require;
}


#
#  Real work starts here: determine the output format,
#  and parse all the options. The language the user might
#  have given is normalized.
#
$theFormat = $ARGV[0] || Usage "driver.pl: format required as first argument";
$FmtList{$theFormat} = $Formats{$theFormat} || Usage "driver.pl: unknown format";
shift;
&ProcessOptions;
$#InFiles > -1 || Usage "no filenames given";
$global->{language} = Lang::Any2ISO ($global->{language});


#
#  Setup the environment.
#
$ENV{SGML_CATALOG_FILES} = "$LibDir/dtd/catalog";
$SGML_SEARCH_PATH = "$LibDir/dtd:$LibDir/rep/$theFormat";
if (-f "$LibDir/dtd/$theFormat.dcl")
  {
    $ENV{SGMLDECL} = "$LibDir/dtd/$theFormat.dcl";
  }
elsif (-f "$LibDir/dtd/$global->{style}.dcl")
  {
    $ENV{SGMLDECL} = "$LibDir/dtd/$global->{style}.dcl";
  }
elsif (-f "$LibDir/dtd/sgml.dcl")
  {
    $ENV{SGMLDECL} = "$LibDir/dtd/sgml.dcl";
  }


#
#  Now, start processing the files.
#
foreach $file (@InFiles)
  {
    ProcessFile ($file);
  }
sub ProcessFile
{
  my $file = shift (@_);

  print "Processing file $file\n";
  ($FileName, $FilePath, $FileSuffix) = fileparse ($file, "\.sgml");
  $tmpnam = $FilePath . '/' . $FileName;
  $file = $tmpnam . $FileSuffix;
  -f $file || $file =~ /.*.sgml$/ || ($file .= '.sgml');
  -f $file || ($file = $tmpnam . '.SGML');
  -f $file || die "Cannot find $file\n";

  $TmpBase = '/tmp/sgmltmp.' . $FileName . $$;
  $ENV{SGML_SEARCH_PATH} = "$SGML_SEARCH_PATH:$FilePath";

  #
  #  You can hack $NsgmlsOpts here, etcetera. If you really need to,
  #  munch $file into $file...
  #
  $NsgmlsOpts = "";
  $NsgmlsPrePipe = "cat $file";
  eval $Formats{$theFormat}{preNSGMLS};
  die ("error pre-sgml-processing $theFormat: $@\n") if $@;
  #
  #  Run nsgmls.
  #
  if ($global->{charset} eq "latin")
    {
      system "$NsgmlsPrePipe | sed -f $LibDir/latin1.sed | 
         $progs->{NSGMLS} $NsgmlsOpts $ENV{SGMLDECL} >$TmpBase.1" ||
	 die "SGML parsing error...";
    }
  else
    {
      system "$NsgmlsPrePipe | $progs->{NSGMLS} $ENV{SGMLDECL} >$TmpBase.1";
    }
        
  #
  #  Special case: if $theFormat is global, we're just checking.
  #
  $theFormat eq "global" && &cleanUp;


  #
  #  If a preASP stage is defined, let the format handle it.
  #  
  #  preASP ($TmpBase.1) => $TmpBase.2
  #
  if ($Formats{$theFormat}{preASP})
    {
      eval $Formats{$theFormat}{preASP};
      die ("error pre-processing $theFormat: $@\n") if $@;
    }  
  else
    {
      `cp $TmpBase.1 $TmpBase.2`;
    }

  #
  #  Run sgmlsasp, with an optional style if specified.
  #
  my $style = '';
  $style = "$LibDir/rep/$theFormat/$global->{style}mapping" 
    if ($global->{style});

  `cat $TmpBase.2 | $progs->{SGMLSASP} $style $LibDir/rep/$theFormat/mapping |
      expand -$global->{tabsize} >$TmpBase.3`;

  #
  #  If a postASP stage is defined, let the format handle it.
  #  It should leave whatever it thinks is right based on $file.
  #
  #  postASP ($TmpBase.3) => final file.
  #
  if ($Formats{$theFormat}{postASP})
    {
      eval $Formats{$theFormat}{postASP};
      die ("error post-processing $theFormat: $@\n") if $@;
    }

  #
  #  All done, remove the temporaries.
  #
  $global->{debug} || unlink <$TmpBase.*>;
}


exit 0;
