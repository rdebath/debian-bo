/* paths.h: Generated from texmf.cnf Tue Apr 29 19:01:39 MET DST 1997.  */
#ifndef DEFAULT_TETEXDIR
#define DEFAULT_TETEXDIR "/usr"
#endif
#ifndef DEFAULT_TEXMF
#define DEFAULT_TEXMF "$TETEXDIR/lib/texmf"
#endif
#ifndef DEFAULT_TEXMFL
#define DEFAULT_TEXMFL "/usr/local/lib/texmf"
#endif
#ifndef DEFAULT_TEXMFS
#define DEFAULT_TEXMFS "{$TEXMFL,!!$TEXMF}"
#endif
#ifndef DEFAULT_VARFONTS
#define DEFAULT_VARFONTS "/var/spool/texmf"
#endif
#ifndef DEFAULT_TRFONTS
#define DEFAULT_TRFONTS "/usr/lib/font/devpost"
#endif
#ifndef DEFAULT_KPSE_DOT
#define DEFAULT_KPSE_DOT "."
#endif
#ifndef DEFAULT_TEXFORMATS
#define DEFAULT_TEXFORMATS "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_MFBASES
#define DEFAULT_MFBASES "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_MPMEMS
#define DEFAULT_MPMEMS "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_TEXPOOL
#define DEFAULT_TEXPOOL "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_MFPOOL
#define DEFAULT_MFPOOL "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_MPPOOL
#define DEFAULT_MPPOOL "$KPSE_DOT:$TEXMFS/web2c"
#endif
#ifndef DEFAULT_TEXINPUTS
#define DEFAULT_TEXINPUTS "$KPSE_DOT:$TEXMFS/tex//"
#endif
#ifndef DEFAULT_MFINPUTS
#define DEFAULT_MFINPUTS "$KPSE_DOT:$TEXMFS/{metafont,fonts/source}//:$VARFONTS/source//"
#endif
#ifndef DEFAULT_MPINPUTS
#define DEFAULT_MPINPUTS "$KPSE_DOT:$TEXMFS/metapost//"
#endif
#ifndef DEFAULT_MPSUPPORT
#define DEFAULT_MPSUPPORT "$KPSE_DOT:$TEXMFS/metapost/support"
#endif
#ifndef DEFAULT_VFFONTS
#define DEFAULT_VFFONTS "$TEXMFS/fonts/vf//:$KPSE_DOT"
#endif
#ifndef DEFAULT_TFMFONTS
#define DEFAULT_TFMFONTS "{$TEXMFS/fonts,$VARFONTS}/tfm//:$KPSE_DOT"
#endif
#ifndef DEFAULT_PKFONTS
#define DEFAULT_PKFONTS "{$TEXMFS/fonts,$VARFONTS}/pk/{$MAKETEX_MODE,gsftopk,ps2pk}//:$KPSE_DOT"
#endif
#ifndef DEFAULT_GFFONTS
#define DEFAULT_GFFONTS "$KPSE_DOT"
#endif
#ifndef DEFAULT_GLYPHFONTS
#define DEFAULT_GLYPHFONTS "$KPSE_DOT:$TEXMFS/fontname"
#endif
#ifndef DEFAULT_BIBINPUTS
#define DEFAULT_BIBINPUTS "$KPSE_DOT:$TEXMFS/bibtex/bib//"
#endif
#ifndef DEFAULT_BSTINPUTS
#define DEFAULT_BSTINPUTS "$KPSE_DOT:$TEXMFS/bibtex/bst//"
#endif
#ifndef DEFAULT_TEXCONFIG
#define DEFAULT_TEXCONFIG "$KPSE_DOT:~:$TEXMFS/{dvips//,web2c}"
#endif
#ifndef DEFAULT_DVIPSHEADERS
#define DEFAULT_DVIPSHEADERS "$KPSE_DOT:$TEXMFS/{dvips,fonts/type1}//"
#endif
#ifndef DEFAULT_INDEXSTYLE
#define DEFAULT_INDEXSTYLE "$KPSE_DOT:$TEXMFS/makeindex//"
#endif
#ifndef DEFAULT_TEXMFCNF
#define DEFAULT_TEXMFCNF ".:/etc/texmf"
#endif
