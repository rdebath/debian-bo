/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define if using alloca.c.  */
/* #undef C_ALLOCA */

/* Define if the closedir function returns void instead of int.  */
/* #undef CLOSEDIR_VOID */

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to one of _getb67, GETB67, getb67 for Cray-2 and Cray-YMP systems.
   This function is required for alloca.c support on those systems.  */
/* #undef CRAY_STACKSEG_END */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef gid_t */

/* Define if you have alloca, as a function or macro.  */
#define HAVE_ALLOCA 1

/* Define if you have <alloca.h> and it should be used (not on Ultrix).  */
#define HAVE_ALLOCA_H 1

/* Define if your struct stat has st_blksize.  */
#define HAVE_ST_BLKSIZE 1

/* Define if your struct stat has st_blocks.  */
#define HAVE_ST_BLOCKS 1

/* Define if your struct stat has st_rdev.  */
#define HAVE_ST_RDEV 1

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* Define if your struct tm has tm_zone.  */
/* #undef HAVE_TM_ZONE */

/* Define if you don't have tm_zone but do have the external array
   tzname.  */
#define HAVE_TZNAME 1

/* Define if on MINIX.  */
/* #undef _MINIX */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef mode_t */

/* Define to `long' if <sys/types.h> doesn't define.  */
/* #undef off_t */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef pid_t */

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* If using the C implementation of alloca, define if you know the
   direction of stack growth for your system; otherwise it will be
   automatically deduced at run-time.
 STACK_DIRECTION > 0 => grows toward higher addresses
 STACK_DIRECTION < 0 => grows toward lower addresses
 STACK_DIRECTION = 0 => direction of growth unknown
 */
/* #undef STACK_DIRECTION */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if `sys_siglist' is declared by <signal.h>.  */
#define SYS_SIGLIST_DECLARED 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if your <sys/time.h> declares struct tm.  */
/* #undef TM_IN_SYS_TIME */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef uid_t */

/* Define if you want bounds checking on element references for
   internal array and matrix classes. */
/* #undef BOUNDS_CHECKING */

/* Define if your math.h declares struct exception for matherr() */
/* #undef EXCEPTION_IN_MATH */

/* Define if your Fortran compiler appends an underscore to external
   names. */ 
#define F77_APPEND_UNDERSCORE 1

/* Define if your Fortran compiler converts external names to
   upper case. */
/* #undef F77_UPPERCASE_NAMES */

/* Define if you don't have FSQP. */
#define FSQP_MISSING 1

/* Define if your system has a single-arg prototype for gettimeofday. */
/* #undef GETTIMEOFDAY_NO_TZ */ 

/* Define if your gnuplot supports multiplt plot windows with X11. */
#define GNUPLOT_HAS_FRAMES 1

/* Define if your gnuplot has mutliplot. */
#define GNUPLOT_HAS_MULTIPLOT 1

/* Define if your system's struct group has a gr_passwd field. */
#define HAVE_GR_PASSWD 1

/* Define if you have isinf(). */
#define HAVE_ISINF 1

/* Define if you have isnan(). */
#define HAVE_ISNAN 1

/* Define if you have BSD style signals. */
/* #undef HAVE_BSD_SIGNALS */

/* Define if you have POSIX style signals. */
#define HAVE_POSIX_SIGNALS 1

/* Define if your system has program_invocation_name. */
/* #undef HAVE_PROGRAM_INVOCATION_NAME */

/* Define if your system has a sys_siglist variable. */
#define HAVE_SYS_SIGLIST 1

/* Define if you have System V Release 3 style signals. */
/* #undef HAVE_USG_SIGHOLD */

/* Define if signal handlers must be reinstalled after they are called. */
/* #undef MUST_REINSTALL_SIGHANDLERS */

/* Define (to string::npos) if <string> doesn't. */
/* #undef NPOS */

/* Define if you don't have NPSOL. */
#define NPSOL_MISSING 1

/* Define to compile smaller kernel. */
#define OCTAVE_LITE 1

/* Define if this is Octave. */
#define OCTAVE_SOURCE 1

/* Define if you don't have QPSOL. */
#define QPSOL_MISSING 1

/* Define if your struct rusage only has time information. */
/* #undef RUSAGE_TIMES_ONLY */

/* Define if you are using an SCO system. */
/* #undef SCO */

/* Define this to be the path separator for your system, as a
   character constant */
#define SEPCHAR ':'

/* Define this to be the path separator for your system, as a
   character string */
#define SEPCHAR_STR ":"

/* To quiet autoheader. */
/* #undef SMART_PUTENV */

/* Use GNU info for extended help system. */
#define USE_GNU_INFO 1

/* Use GNU readline for command line editing and history. */
#define USE_READLINE 1

/* Define if using dlopen/dlsym for dynamic linking of object files. */
#define WITH_DL 1

/* Define if using dld for dynamic linking of object files. */
/* #undef WITH_SHL */

/* Define if using some method of dynamic linking. */
#define WITH_DYNAMIC_LINKING 1

/* Define to `short' if <sys/types.h> doesn't define. */
/* #undef dev_t */

/* Define to `unsigned long' if <sys/types.h> doesn't define. */
/* #undef ino_t */

/* Define to `short' if <sys/types.h> doesn't define. */
/* #undef nlink_t */

/* Define to `int' if <signal.h> doesn't define. */
/* #undef sigset_t */

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* Define if you have the acosh function.  */
#define HAVE_ACOSH 1

/* Define if you have the asinh function.  */
#define HAVE_ASINH 1

/* Define if you have the atanh function.  */
#define HAVE_ATANH 1

/* Define if you have the atexit function.  */
#define HAVE_ATEXIT 1

/* Define if you have the bcopy function.  */
#define HAVE_BCOPY 1

/* Define if you have the bzero function.  */
#define HAVE_BZERO 1

/* Define if you have the dlclose function.  */
#define HAVE_DLCLOSE 1

/* Define if you have the dlerror function.  */
#define HAVE_DLERROR 1

/* Define if you have the dlopen function.  */
#define HAVE_DLOPEN 1

/* Define if you have the dlsym function.  */
#define HAVE_DLSYM 1

/* Define if you have the dup2 function.  */
#define HAVE_DUP2 1

/* Define if you have the endgrent function.  */
#define HAVE_ENDGRENT 1

/* Define if you have the endpwent function.  */
#define HAVE_ENDPWENT 1

/* Define if you have the erf function.  */
#define HAVE_ERF 1

/* Define if you have the erfc function.  */
#define HAVE_ERFC 1

/* Define if you have the execvp function.  */
#define HAVE_EXECVP 1

/* Define if you have the fcntl function.  */
#define HAVE_FCNTL 1

/* Define if you have the finite function.  */
#define HAVE_FINITE 1

/* Define if you have the fork function.  */
#define HAVE_FORK 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the getegid function.  */
#define HAVE_GETEGID 1

/* Define if you have the geteuid function.  */
#define HAVE_GETEUID 1

/* Define if you have the getgid function.  */
#define HAVE_GETGID 1

/* Define if you have the getgrent function.  */
#define HAVE_GETGRENT 1

/* Define if you have the getgrgid function.  */
#define HAVE_GETGRGID 1

/* Define if you have the getgrnam function.  */
#define HAVE_GETGRNAM 1

/* Define if you have the gethostname function.  */
#define HAVE_GETHOSTNAME 1

/* Define if you have the getpgrp function.  */
#define HAVE_GETPGRP 1

/* Define if you have the getpid function.  */
#define HAVE_GETPID 1

/* Define if you have the getppid function.  */
#define HAVE_GETPPID 1

/* Define if you have the getpwent function.  */
#define HAVE_GETPWENT 1

/* Define if you have the getpwnam function.  */
#define HAVE_GETPWNAM 1

/* Define if you have the getpwuid function.  */
#define HAVE_GETPWUID 1

/* Define if you have the getrusage function.  */
#define HAVE_GETRUSAGE 1

/* Define if you have the getuid function.  */
#define HAVE_GETUID 1

/* Define if you have the infinity function.  */
/* #undef HAVE_INFINITY */

/* Define if you have the isinf function.  */
#define HAVE_ISINF 1

/* Define if you have the isnan function.  */
#define HAVE_ISNAN 1

/* Define if you have the lstat function.  */
#define HAVE_LSTAT 1

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1

/* Define if you have the mkdir function.  */
#define HAVE_MKDIR 1

/* Define if you have the mkfifo function.  */
#define HAVE_MKFIFO 1

/* Define if you have the on_exit function.  */
#define HAVE_ON_EXIT 1

/* Define if you have the pipe function.  */
#define HAVE_PIPE 1

/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1

/* Define if you have the quiet_nan function.  */
/* #undef HAVE_QUIET_NAN */

/* Define if you have the rename function.  */
#define HAVE_RENAME 1

/* Define if you have the rindex function.  */
#define HAVE_RINDEX 1

/* Define if you have the rmdir function.  */
#define HAVE_RMDIR 1

/* Define if you have the setgrent function.  */
#define HAVE_SETGRENT 1

/* Define if you have the setpwent function.  */
#define HAVE_SETPWENT 1

/* Define if you have the setvbuf function.  */
#define HAVE_SETVBUF 1

/* Define if you have the shl_findsym function.  */
/* #undef HAVE_SHL_FINDSYM */

/* Define if you have the shl_load function.  */
/* #undef HAVE_SHL_LOAD */

/* Define if you have the sigaction function.  */
#define HAVE_SIGACTION 1

/* Define if you have the sigpending function.  */
#define HAVE_SIGPENDING 1

/* Define if you have the sigprocmask function.  */
#define HAVE_SIGPROCMASK 1

/* Define if you have the sigsuspend function.  */
#define HAVE_SIGSUSPEND 1

/* Define if you have the stat function.  */
#define HAVE_STAT 1

/* Define if you have the strcasecmp function.  */
#define HAVE_STRCASECMP 1

/* Define if you have the strdup function.  */
#define HAVE_STRDUP 1

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the stricmp function.  */
/* #undef HAVE_STRICMP */

/* Define if you have the strncasecmp function.  */
#define HAVE_STRNCASECMP 1

/* Define if you have the strnicmp function.  */
/* #undef HAVE_STRNICMP */

/* Define if you have the tempnam function.  */
#define HAVE_TEMPNAM 1

/* Define if you have the times function.  */
#define HAVE_TIMES 1

/* Define if you have the umask function.  */
#define HAVE_UMASK 1

/* Define if you have the unlink function.  */
#define HAVE_UNLINK 1

/* Define if you have the usleep function.  */
#define HAVE_USLEEP 1

/* Define if you have the vfprintf function.  */
#define HAVE_VFPRINTF 1

/* Define if you have the vsprintf function.  */
#define HAVE_VSPRINTF 1

/* Define if you have the waitpid function.  */
#define HAVE_WAITPID 1

/* Define if you have the <assert.h> header file.  */
#define HAVE_ASSERT_H 1

/* Define if you have the <curses.h> header file.  */
#define HAVE_CURSES_H 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <float.h> header file.  */
#define HAVE_FLOAT_H 1

/* Define if you have the <floatingpoint.h> header file.  */
/* #undef HAVE_FLOATINGPOINT_H */

/* Define if you have the <grp.h> header file.  */
#define HAVE_GRP_H 1

/* Define if you have the <ieeefp.h> header file.  */
/* #undef HAVE_IEEEFP_H */

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <nan.h> header file.  */
#define HAVE_NAN_H 1

/* Define if you have the <ncurses.h> header file.  */
#define HAVE_NCURSES_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <pwd.h> header file.  */
#define HAVE_PWD_H 1

/* Define if you have the <sgtty.h> header file.  */
/* #undef HAVE_SGTTY_H */

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/param.h> header file.  */
#define HAVE_SYS_PARAM_H 1

/* Define if you have the <sys/resource.h> header file.  */
#define HAVE_SYS_RESOURCE_H 1

/* Define if you have the <sys/select.h> header file.  */
/* #undef HAVE_SYS_SELECT_H */

/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/times.h> header file.  */
#define HAVE_SYS_TIMES_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/utsname.h> header file.  */
#define HAVE_SYS_UTSNAME_H 1

/* Define if you have the <termcap.h> header file.  */
#define HAVE_TERMCAP_H 1

/* Define if you have the <termio.h> header file.  */
#define HAVE_TERMIO_H 1

/* Define if you have the <termios.h> header file.  */
#define HAVE_TERMIOS_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <varargs.h> header file.  */
#define HAVE_VARARGS_H 1

/* Define if you have the dl library (-ldl).  */
#define HAVE_LIBDL 1

/* Define if you have the dld library (-ldld).  */
/* #undef HAVE_LIBDLD */

/* Define if you have the m library (-lm).  */
#define HAVE_LIBM 1

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

/* Define if you have the sun library (-lsun).  */
/* #undef HAVE_LIBSUN */

/* Define if you have the sunmath library (-lsunmath).  */
/* #undef HAVE_LIBSUNMATH */

#if defined (__GNUC__)
#define GCC_ATTR_NORETURN __attribute__ ((__noreturn__))
#define GCC_ATTR_UNUSED __attribute__ ((__unused__))
#else
#define GCC_ATTR_NORETURN
#define GCC_ATTR_UNUSED
#endif

#define STATIC_CAST(T, E) (T) (E)

#define DYNAMIC_CAST(T, E) (T) (E)

#define REINTERPRET_CAST(T, E) (T) (E)

#define HEAVYWEIGHT_INDEXING 1

#define WITH_KPATHSEARCH 1
