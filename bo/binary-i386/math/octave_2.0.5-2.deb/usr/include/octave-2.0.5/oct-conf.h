// oct-conf.h.in
/*

Copyright (C) 1996 John W. Eaton

This file is part of Octave.

Octave is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2, or (at your option) any
later version.

Octave is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
for more details.

You should have received a copy of the GNU General Public License
along with Octave; see the file COPYING.  If not, write to the Free
Software Foundation, 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

*/

#if !defined (octave_conf_h)
#define octave_conf_h 1

#ifndef config_opts
#define config_opts "--prefix=/usr --with-g77 --libdir=/usr/lib/octave --enable-dl --enable-shared --enable-lite-kernel"
#endif

#ifndef TARGET_HOST_TYPE
#define TARGET_HOST_TYPE "i586-pc-linux-gnu"
#endif

#ifndef F77
#define F77 "g77"
#endif

#ifndef FFLAGS
#define FFLAGS "-O2"
#endif

#ifndef FPICFLAG
#define FPICFLAG "-fPIC"
#endif

#ifndef F2C
#define F2C ""
#endif

#ifndef F2CFLAGS
#define F2CFLAGS ""
#endif

#ifndef FLIBS
#define FLIBS "-lf2c -L/usr/lib/gcc-lib/i486-linux/2.7.2.1 -lgcc"
#endif

#ifndef CPPFLAGS
#define CPPFLAGS ""
#endif

#ifndef INCFLAGS
#define INCFLAGS "-I/usr/include -I/usr/include/octave-2.0.5"
#endif

#ifndef CC
#define CC "gcc"
#endif

#ifndef CC_VERSION
#define CC_VERSION "2.7.2.1"
#endif

#ifndef CFLAGS
#define CFLAGS "-DHAVE_CONFIG_H -mieee-fp -O2"
#endif

#ifndef CPICFLAG
#define CPICFLAG "-fPIC"
#endif

#ifndef CXX
#define CXX "c++"
#endif

#ifndef CXX_VERSION
#define CXX_VERSION "2.7.2.1"
#endif

#ifndef CXXFLAGS
#define CXXFLAGS "-DHAVE_CONFIG_H  -fno-implicit-templates -mieee-fp -O2"
#endif

#ifndef CXXPICFLAG
#define CXXPICFLAG "-fPIC"
#endif

#ifndef LDFLAGS
#define LDFLAGS "-s"
#endif

#ifndef LIBFLAGS
#define LIBFLAGS "-L/usr/lib/octave"
#endif

#ifndef RLD_FLAG
#define RLD_FLAG "-Xlinker -rpath -Xlinker /usr/lib/octave"
#endif

#ifndef CXXLIBS
#define CXXLIBS "-lstdc++ -lm -L/usr/lib/gcc-lib/i486-linux/2.7.2.1 -lstdc++ -lm -lgcc -lc -lgcc"
#endif

#ifndef TERMLIBS
#define TERMLIBS "-lncurses"
#endif

#ifndef LIBS
#define LIBS "-lm -ldl "
#endif

#ifndef LEXLIB
#define LEXLIB ""
#endif

#ifndef LIBPLPLOT
#define LIBPLPLOT ""
#endif

#ifndef LIBDLFCN
#define LIBDLFCN ""
#endif

#ifndef DEFS
#define DEFS "-DOCTAVE_SOURCE=1 -DSEPCHAR=':' -DSEPCHAR_STR=\":\" -DUSE_GNU_INFO=1 -DUSE_READLINE=1 -DOCTAVE_LITE=1 -DSIZEOF_SHORT=2 -DSIZEOF_INT=4 -DSIZEOF_LONG=4 -DHAVE_ALLOCA_H=1 -DHAVE_ALLOCA=1 -DF77_APPEND_UNDERSCORE=1 -DSTDC_HEADERS=1 -DHAVE_DIRENT_H=1 -DTIME_WITH_SYS_TIME=1 -DHAVE_SYS_WAIT_H=1 -DHAVE_ASSERT_H=1 -DHAVE_CURSES_H=1 -DHAVE_FCNTL_H=1 -DHAVE_FLOAT_H=1 -DHAVE_GRP_H=1 -DHAVE_LIMITS_H=1 -DHAVE_MEMORY_H=1 -DHAVE_NAN_H=1 -DHAVE_NCURSES_H=1 -DHAVE_PWD_H=1 -DHAVE_STDLIB_H=1 -DHAVE_STRING_H=1 -DHAVE_SYS_PARAM_H=1 -DHAVE_SYS_RESOURCE_H=1 -DHAVE_SYS_STAT_H=1 -DHAVE_SYS_TIME_H=1 -DHAVE_SYS_TIMES_H=1 -DHAVE_SYS_TYPES_H=1 -DHAVE_SYS_UTSNAME_H=1 -DHAVE_TERMCAP_H=1 -DHAVE_TERMIO_H=1 -DHAVE_TERMIOS_H=1 -DHAVE_UNISTD_H=1 -DHAVE_VARARGS_H=1 -DNPSOL_MISSING=1 -DQPSOL_MISSING=1 -DFSQP_MISSING=1 -DHAVE_ATEXIT=1 -DHAVE_BCOPY=1 -DHAVE_BZERO=1 -DHAVE_DUP2=1 -DHAVE_ENDGRENT=1 -DHAVE_ENDPWENT=1 -DHAVE_EXECVP=1 -DHAVE_FCNTL=1 -DHAVE_FORK=1 -DHAVE_GETCWD=1 -DHAVE_GETEGID=1 -DHAVE_GETEUID=1 -DHAVE_GETGID=1 -DHAVE_GETGRENT=1 -DHAVE_GETGRGID=1 -DHAVE_GETGRNAM=1 -DHAVE_GETHOSTNAME=1 -DHAVE_GETPGRP=1 -DHAVE_GETPID=1 -DHAVE_GETPPID=1 -DHAVE_GETPWENT=1 -DHAVE_GETPWNAM=1 -DHAVE_GETPWUID=1 -DHAVE_GETUID=1 -DHAVE_LSTAT=1 -DHAVE_MEMMOVE=1 -DHAVE_MKDIR=1 -DHAVE_MKFIFO=1 -DHAVE_ON_EXIT=1 -DHAVE_PIPE=1 -DHAVE_PUTENV=1 -DHAVE_RENAME=1 -DHAVE_RINDEX=1 -DHAVE_RMDIR=1 -DHAVE_SETGRENT=1 -DHAVE_SETPWENT=1 -DHAVE_SETVBUF=1 -DHAVE_SIGACTION=1 -DHAVE_SIGPENDING=1 -DHAVE_SIGPROCMASK=1 -DHAVE_SIGSUSPEND=1 -DHAVE_STAT=1 -DHAVE_STRCASECMP=1 -DHAVE_STRDUP=1 -DHAVE_STRERROR=1 -DHAVE_STRNCASECMP=1 -DHAVE_TEMPNAM=1 -DHAVE_UMASK=1 -DHAVE_UNLINK=1 -DHAVE_USLEEP=1 -DHAVE_VFPRINTF=1 -DHAVE_VSPRINTF=1 -DHAVE_WAITPID=1 -DHAVE_LIBDL=1 -DHAVE_DLOPEN=1 -DHAVE_DLSYM=1 -DHAVE_DLERROR=1 -DHAVE_DLCLOSE=1 -DWITH_DL=1 -DWITH_DYNAMIC_LINKING=1 -DHAVE_LIBM=1 -DHAVE_FINITE=1 -DHAVE_ISNAN=1 -DHAVE_ISINF=1 -DHAVE_ACOSH=1 -DHAVE_ASINH=1 -DHAVE_ATANH=1 -DHAVE_ERF=1 -DHAVE_ERFC=1 -DHAVE_ST_BLKSIZE=1 -DHAVE_ST_BLOCKS=1 -DHAVE_ST_RDEV=1 -DHAVE_TZNAME=1 -DHAVE_GR_PASSWD=1 -DRETSIGTYPE=void -DSYS_SIGLIST_DECLARED=1 -DHAVE_SYS_SIGLIST=1 -DHAVE_POSIX_SIGNALS=1 -DHAVE_GETRUSAGE=1 -DHAVE_TIMES=1 -DGNUPLOT_HAS_MULTIPLOT=1 -DGNUPLOT_HAS_FRAMES=1"
#endif

#endif

/*
;;; Local Variables: ***
;;; mode: C++ ***
;;; page-delimiter: "^/\\*" ***
;;; End: ***
*/
