/* Native primitive data formats computed by FMCALC */

#define CHAR_ALIGN 1

#define SHORT_SIZE 2L
#define SHORT_ALIGN 2
#define SHORT_ORDER -1

#define INT_SIZE 4L
#define INT_ALIGN 4
#define INT_ORDER -1

#define LONG_SIZE 4L
#define LONG_ALIGN 4
#define LONG_ORDER -1

#define FLOAT_SIZE 4L
#define FLOAT_ALIGN 4
#define FLOAT_ORDER -1
#define FLOAT_LAYOUT {0, 0, 1, 8, 9, 23, 0, 127}

#define DOUBLE_SIZE 8L
#define DOUBLE_ALIGN 4
#define DOUBLE_ORDER -1
#define DOUBLE_LAYOUT {0, 0, 1, 11, 12, 52, 0, 1023}

#define POINTER_ALIGN 4

#define STRUCT_ALIGN 1
