/* example.3.c
   compile with gcc -O2 -o example.3 example.3.c -lm -llip
*/

#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "lip.h"
main()
{
    register long i;
    long p;
    scanf("%d",&p);
    for (i=1; i<p; i++) {
        printf("%d inverse module %d is %d\n",i,p zinvodds(i,p));
}
