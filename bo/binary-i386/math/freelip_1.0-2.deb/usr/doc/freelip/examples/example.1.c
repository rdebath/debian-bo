/* example.1.c
   compile with gcc -O2 -o example.1 example.1.c -lm -llip
*/

#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "lip.h"
main()
{
    verylong a = 0;
    verylong b = 0;
    verylong c = 0;
    zread(&a);
    zread(&b);
    zmul(a,b,&c);
    zwriteln(c);
}
