/* example.2.c
   compile with gcc -O2 -o example.2 example.2.c -lm -llip
*/

#include <stddef.h>
#include <stdio.h>
#include <math.h>
#include <malloc.h>
#include <signal.h>
#include <sys/time.h>
#include <sys/resource.h>
#include "lip.h"
main()
{
    verylong seed = 0;
    verylong prime = 0;
    long bitlength;
    zread(&seed);
    zrstart(seed);
    for (bitlength = 64; bitlength <= 128; bitlength += 16) {
        if (zrandomprime(bitlength,5 &prime,zrandomb)) {
            printf("3d bits: ",bitlength);
            zhwriteln(prime);
        }
        else
            printf("no %3d bit prime found\n",bitlength);
    }    
}
