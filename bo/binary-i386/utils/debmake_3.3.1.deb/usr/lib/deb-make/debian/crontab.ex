0 4	* * *	root	#PACKAGE#_maintenance
