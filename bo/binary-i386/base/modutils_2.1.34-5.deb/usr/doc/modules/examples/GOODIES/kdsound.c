This file is obsolete and no longer user by Debian GNU/Linux 1.3
It has been replaced for backwards compatibilty and will be
removed in the next release.
