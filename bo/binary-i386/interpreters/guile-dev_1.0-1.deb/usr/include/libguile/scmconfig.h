/* scmconfig.h.  Generated automatically by configure.  */
/* scmconfig.h.in.  Generated automatically from configure.in by autoheader.  */

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to the type of elements in the array set by `getgroups'.
   Usually this is either `int' or `gid_t'.  */
#define GETGROUPS_T gid_t

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef gid_t */

/* Define if your struct stat has st_blksize.  */
#define HAVE_ST_BLKSIZE 1

/* Define if your struct stat has st_blocks.  */
#define HAVE_ST_BLOCKS 1

/* Define if your struct stat has st_rdev.  */
#define HAVE_ST_RDEV 1

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
#define HAVE_SYS_WAIT_H 1

/* Define if on MINIX.  */
/* #undef _MINIX */

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef mode_t */

/* Define if the system does not provide POSIX.1 features except
   with this defined.  */
/* #undef _POSIX_1_SOURCE */

/* Define if you need to in order for stat and other things to work.  */
/* #undef _POSIX_SOURCE */

/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define to `int' if <sys/types.h> doesn't define.  */
/* #undef uid_t */

/* Define these two if you want support for debugging of Scheme
   programs.  */
#define DEBUG_EXTENSIONS 1
#define READER_EXTENSIONS 1

/* Define this if your system has a way to set a stdio stream's file
   descriptor.  You should also copy fd.h.in to fd.h, and give the
   macro SET_FILE_FD_FIELD an appropriate definition.  See
   configure.in for more details.  */
#define HAVE_FD_SETTER 1

/* Define this if your system has a way to set a stdio stream's file
   descriptor.  You should also copy fd.h.in to fd.h, and give the
   macro SET_FILE_FD_FIELD an appropriate definition.  See
   configure.in for more details.  */
#define HAVE_FD_SETTER 1

/* Set this to the name of a field in FILE which contains the number
   of buffered characters waiting to be read.  */
/* #undef FILE_CNT_FIELD */

/* Define this if your stdio has _gptr and _egptr fields which can
   be compared to give the number of buffered characters waiting to
   be read.  */
/* #undef FILE_CNT_GPTR */

/* Define this if your stdio has _IO_read_ptr and _IO_read_end fields
   which can be compared to give the number of buffered characters
   waiting to be read.  */
#define FILE_CNT_READPTR 1

/* Define this if your system defines struct linger, for use with the
   getsockopt and setsockopt system calls.  */
#define HAVE_STRUCT_LINGER 1

/* Define this if floats are the same size as longs.  */
#define SCM_SINGLES 1

/* Define this if a callee's stack frame has a higher address than the
   caller's stack frame.  On most machines, this is not the case.  */
/* #undef SCM_STACK_GROWS_UP */

/* Define this if <utime.h> doesn't define struct utimbuf unless
   _POSIX_SOURCE is #defined.  See GUILE_STRUCT_UTIMBUF in aclocal.m4.  */
/* #undef UTIMBUF_NEEDS_POSIX */

/* Define this if we should #include <libc.h> when we've already
   #included <unistd.h>.  On some systems, they conflict, and libc.h
   should be omitted.  See GUILE_HEADER_LIBC_WITH_UNISTD in
   aclocal.m4.  */
/* #undef LIBC_H_WITH_UNISTD_H */

/* Define these to indicate the current version of Guile.  These
   values are supposed to be supplied by the configuration system.  */
#define GUILE_MAJOR_VERSION "1"
#define GUILE_MINOR_VERSION "0"
#define GUILE_VERSION "1.0"

/* Define if using cooperative multithreading.  */
/* #undef USE_COOP_THREADS */

/* Define if using "FSU" pthreads.  */
/* #undef USE_FSU_PTHREADS */

/* Define if using MIT pthreads.  */
/* #undef USE_MIT_PTHREADS */

/* Define if using PCthreads pthreads.  */
/* #undef USE_PCTHREADS_PTHREADS */

/* Define if using any sort of threads.  */
/* #undef USE_THREADS */

/* Name of this package.  */
#define PACKAGE "guile"

/* Define if you want support for dynamic linking. */
/* #undef DYNAMIC_LINKING */

/* Define if you have the ctermid function.  */
#define HAVE_CTERMID 1

/* Define if you have the ftime function.  */
#define HAVE_FTIME 1

/* Define if you have the getcwd function.  */
#define HAVE_GETCWD 1

/* Define if you have the geteuid function.  */
#define HAVE_GETEUID 1

/* Define if you have the inet_aton function.  */
#define HAVE_INET_ATON 1

/* Define if you have the lstat function.  */
#define HAVE_LSTAT 1

/* Define if you have the mkdir function.  */
#define HAVE_MKDIR 1

/* Define if you have the mknod function.  */
#define HAVE_MKNOD 1

/* Define if you have the nice function.  */
#define HAVE_NICE 1

/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1

/* Define if you have the readlink function.  */
#define HAVE_READLINK 1

/* Define if you have the rename function.  */
#define HAVE_RENAME 1

/* Define if you have the rmdir function.  */
#define HAVE_RMDIR 1

/* Define if you have the select function.  */
#define HAVE_SELECT 1

/* Define if you have the setegid function.  */
#define HAVE_SETEGID 1

/* Define if you have the seteuid function.  */
#define HAVE_SETEUID 1

/* Define if you have the setlocale function.  */
#define HAVE_SETLOCALE 1

/* Define if you have the setpgid function.  */
#define HAVE_SETPGID 1

/* Define if you have the setsid function.  */
#define HAVE_SETSID 1

/* Define if you have the shl_load function.  */
/* #undef HAVE_SHL_LOAD */

/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1

/* Define if you have the strftime function.  */
#define HAVE_STRFTIME 1

/* Define if you have the strptime function.  */
#define HAVE_STRPTIME 1

/* Define if you have the symlink function.  */
#define HAVE_SYMLINK 1

/* Define if you have the sync function.  */
#define HAVE_SYNC 1

/* Define if you have the tcgetpgrp function.  */
#define HAVE_TCGETPGRP 1

/* Define if you have the tcsetpgrp function.  */
#define HAVE_TCSETPGRP 1

/* Define if you have the times function.  */
#define HAVE_TIMES 1

/* Define if you have the uname function.  */
#define HAVE_UNAME 1

/* Define if you have the waitpid function.  */
#define HAVE_WAITPID 1

/* Define if you have the <dirent.h> header file.  */
#define HAVE_DIRENT_H 1

/* Define if you have the <libc.h> header file.  */
/* #undef HAVE_LIBC_H */

/* Define if you have the <limits.h> header file.  */
#define HAVE_LIMITS_H 1

/* Define if you have the <malloc.h> header file.  */
#define HAVE_MALLOC_H 1

/* Define if you have the <memory.h> header file.  */
#define HAVE_MEMORY_H 1

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/ioctl.h> header file.  */
#define HAVE_SYS_IOCTL_H 1

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/select.h> header file.  */
/* #undef HAVE_SYS_SELECT_H */

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/timeb.h> header file.  */
#define HAVE_SYS_TIMEB_H 1

/* Define if you have the <sys/times.h> header file.  */
#define HAVE_SYS_TIMES_H 1

/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1

/* Define if you have the <sys/utime.h> header file.  */
/* #undef HAVE_SYS_UTIME_H */

/* Define if you have the <time.h> header file.  */
#define HAVE_TIME_H 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the <utime.h> header file.  */
#define HAVE_UTIME_H 1

/* Define if you have the dl library (-ldl).  */
/* #undef HAVE_LIBDL */

/* Define if you have the dld library (-ldld).  */
/* #undef HAVE_LIBDLD */
