#
# Local customizations
#

# Where to find the Universal Header include files:
INCLUDEDIR="Sap:CW8 Gold:Metrowerks CodeWarrior:MacOS Support:Headers:Universal Headers:"

# Where to put the python definitions file:
TOOLBOXDIR="Moes:Development:Jack:Python 1.3:Mac:Lib:toolbox:"

# Creator for C files:
CREATOR="CWIE"
