/* version.h 1.45 1997/04/18 03:55:31 (David Hinds) */

#define CS_RELEASE "2.9.5"
#define CS_RELEASE_CODE 0x2905
