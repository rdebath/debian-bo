/* acconfig.h

/* Set to the type your C compiler uses for 8 bit variables */
#define U8_TYPE  (unsigned char)

/* Set to the type your C compiler uses for 16 bit variables */
#define U16_TYPE  (unsigned short)

/* Set to the type your C compiler uses for 32 bit variables */
#define U32_TYPE  (unsigned long)

/* Define if compiler can use __atribute__((packed)) */
#undef USE_PACKED

/* Define if system has __u8, __u16 and __u32 defined */
#undef USE__UXX

