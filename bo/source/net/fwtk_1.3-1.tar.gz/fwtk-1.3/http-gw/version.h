#define VERSION "Ver 1.0 / 42"
