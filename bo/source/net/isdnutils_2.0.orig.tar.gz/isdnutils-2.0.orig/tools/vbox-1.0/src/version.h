
#ifndef _VBOX_VERSION_H
#define _VBOX_VERSION_H 1

/** Version **************************************************************/

#define COPYRIGHT	"(C) 1996 Michael Herold"

#endif /* _VBOX_VERSION_H */
