/* $Id: patchlevel.h,v 1.17 1995/08/17 11:57:28 paulus Exp $ */
#define	PATCHLEVEL	0

#define VERSION		"2.2"
#define IMPLEMENTATION	""
#define DATE		"17 August 95"
