/*
 * Copyright (c) 1990,1993 Regents of The University of Michigan.
 * All Rights Reserved.  See COPYRIGHT.
 */

extern int		debug;
extern int		uservolfirst;
extern int		afp_version;
extern int		nologin;
extern char		*username;
extern char		*defaultvol;
extern char		*systemvol;
extern struct vol	*volumes;
extern struct dir	*curdir;
extern char		getwdbuf[];
extern char		*Obj;
extern char		*guest;
extern char		*Trash;
