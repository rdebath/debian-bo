/*
 * Copyright (c) 1990,1993 Regents of The University of Michigan.
 * All Rights Reserved. See COPYRIGHT.
 */

extern unsigned char	ethermultitab[ 253 ][ 6 ];
extern unsigned char	tokenmultitab[ 19 ][ 6 ];
extern unsigned char	ethermulti[ 6 ];
