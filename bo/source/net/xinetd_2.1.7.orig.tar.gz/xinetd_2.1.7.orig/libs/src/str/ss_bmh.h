/*
 * (c) Copyright 1992, 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

#ifndef SS_BMH_H
#define SS_BMH_H

/*
 * $Id: ss_bmh.h,v 3.1 1993/06/13 02:42:53 panos Exp $
 */

typedef unsigned shift_int ;

struct bmh_header
{
	shift_int *shift ;
} ;

#endif	/* SS_BMH_H */

