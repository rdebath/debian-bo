/*
 *	$Id: customconf.h,v 1.1 1995/05/01 04:17:38 chuck Exp $
 *
 *	customconf.h - sio config for Linux
 *
 */

#define SIO_MNEED( addr, len )
