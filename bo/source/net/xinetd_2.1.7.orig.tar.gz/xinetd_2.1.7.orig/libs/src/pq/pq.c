/*
 * (c) Copyright 1993 by Panagiotis Tsirigotis
 * All rights reserved.  The file named COPYRIGHT specifies the terms 
 * and conditions for redistribution.
 */

static char RCSid[] = "$Id: pq.c,v 1.1 1992/11/23 16:25:25 panos Exp $" ;
static char version[] = VERSION ;

int pq_errno ;

