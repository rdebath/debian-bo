#ifndef lint
static char Version[] = "@(#)vers.c	e07@nikhef.nl (Eric Wassenaar) 970203";
#endif

char *version = "970203";

#if defined(apollo)
int h_errno = 0;
#endif
