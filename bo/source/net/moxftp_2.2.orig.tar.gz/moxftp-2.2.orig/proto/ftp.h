static char * get_note P_(());
static char * next P_((FILE*));
