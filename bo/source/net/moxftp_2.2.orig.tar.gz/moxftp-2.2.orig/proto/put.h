static void finish_put P_((struct _output*, int, DATA));
static void percent P_((caddr_t, XtIntervalId*));
static void status P_((char*, int));
