static void finish_pwd P_((struct _output*, int, DATA));
static void status P_((char*, int));
