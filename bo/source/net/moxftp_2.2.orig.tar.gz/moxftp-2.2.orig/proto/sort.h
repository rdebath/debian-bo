static int sort_by_age P_((char*, char*));
static int sort_by_name P_((char*, char*));
static int sort_by_size P_((char*, char*));
static int sort_by_type P_((char*, char*));
static int weight_type P_((struct _files*));
