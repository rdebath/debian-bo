static void do_animate_icon P_((caddr_t, XtIntervalId*));
static Pixel getpixel P_((char*));
static void init_proto P_((Widget));
