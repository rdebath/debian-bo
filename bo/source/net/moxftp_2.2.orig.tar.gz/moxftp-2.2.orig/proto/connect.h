static void finish_connect P_((struct _output*, int, DATA));
static void guess_system_type P_((struct _output*));
static void status P_((char*, int));
