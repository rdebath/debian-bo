static int sort_by_name P_((char*, char*));
