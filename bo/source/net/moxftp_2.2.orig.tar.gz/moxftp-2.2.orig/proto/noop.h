static void clear_noop_act P_((Widget, XEvent *, String *, Cardinal *));
static void clear_noop_cb P_((Widget, char*, caddr_t));
static void clear_noop_xx P_((Widget, char*));
static void noop_cb P_((Widget, char*, caddr_t));
static void set_noop_cb P_((Widget, char*, caddr_t));
