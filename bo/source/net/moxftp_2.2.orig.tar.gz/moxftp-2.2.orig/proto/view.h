static int file_recognition P_((char*, char*));
