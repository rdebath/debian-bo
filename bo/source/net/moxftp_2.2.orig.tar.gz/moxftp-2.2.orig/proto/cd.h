static void finish_cd P_((struct _output*, int, DATA));
static void status P_((char*, int));
