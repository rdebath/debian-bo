static void finish_type P_((struct _output*, int, DATA));
static void status P_((char*, int));
