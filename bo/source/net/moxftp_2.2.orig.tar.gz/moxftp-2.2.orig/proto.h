#ifndef __PROTO_
/*
 * Define proto macro.
 */
#if defined(USE_PROTO)
#define P_(X) X
#else
#define P_(X) ()
#endif


#endif
