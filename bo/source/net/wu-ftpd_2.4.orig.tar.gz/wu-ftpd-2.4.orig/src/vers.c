char version[] = "Version wu-2.4(1) Wed Apr 13 16:38:41 CDT 1994";
