
/*
 * move this declaration into an extra module, so theres no
 * confusion with declarations in applications.
 */

int snmp_dump_packet = 0;

