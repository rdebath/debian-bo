#ifndef lint
static char Version[] = "@(#)vers.c	e07@nikhef.nl (Eric Wassenaar) 950410";
#endif

char *version = "950410";

#if defined(apollo)
int h_errno = 0;
#endif
