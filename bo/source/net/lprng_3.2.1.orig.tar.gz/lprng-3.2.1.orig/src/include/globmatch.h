/***************************************************************************
 * LPRng - An Extended Print Spooler System
 *
 * Copyright 1988-1997, Patrick Powell, San Diego, CA
 *     papowell@sdsu.edu
 * See LICENSE for conditions of use.
 *
 ***************************************************************************
 * MODULE: globmatch.h
 * PURPOSE: glob pattern matching
 * $Id: globmatch.h,v 3.1 1996/12/28 21:40:28 papowell Exp $
 **************************************************************************/
int Globmatch( char *pattern, char *str );
