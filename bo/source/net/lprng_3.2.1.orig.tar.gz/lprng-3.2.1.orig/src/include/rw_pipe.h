/***************************************************************************
 * LPRng - An Extended Print Spooler System
 *
 * Copyright 1988-1997, Patrick Powell, San Diego, CA
 *     papowell@sdsu.edu
 * See LICENSE for conditions of use.
 *
 ***************************************************************************
 * MODULE: rw_pipe.h
 * PURPOSE: declare rw_pipe()
 * $Id: rw_pipe.h,v 3.1 1996/12/28 21:40:34 papowell Exp $
 **************************************************************************/

int rw_pipe( int p[] );
