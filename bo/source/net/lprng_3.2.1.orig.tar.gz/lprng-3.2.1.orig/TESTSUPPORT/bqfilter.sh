#!/bin/sh
# Bounce Queue Filter - Example of its use
# - we simple prepend a text line to this
echo "Bounce Queue Filter - prepended line"
cat
exit 0
