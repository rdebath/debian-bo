#ifndef lint
static char Version[] = "@(#)vers.c	e07@nikhef.nl (Eric Wassenaar) 961013";
#endif

char *version = "961013";

#if defined(apollo)
int h_errno = 0;
#endif
