Delivery-Date: Sun, 24 Sep 1995 08:23:13 -0700
Return-Path: brad@azathoth.ops.aol.com
Received: by gw.home.vix.com id AA02752; Sun, 24 Sep 95 08:23:11 -0700
Received: by azathoth.ops.aol.com
	(1.37.109.16/16.3(BK)) id AA162616304; Sun, 24 Sep 1995 10:25:04 -0500
From: Brad Knowles <brad@azathoth.ops.aol.com>
Message-Id: <199509241525.AA162616304@azathoth.ops.aol.com>
Subject: note on lamers
To: paul@vix.com
Date: Sun, 24 Sep 1995 10:25:04 CDT
Reply-To: Brad Knowles <BKnowles@aol.net>
Organization: America Online, Inc.
X-Telephone: (703) 918-2256
X-Telefacsimile: (703) 883-1514
X-Mailer: Elm [revision: 109.14]

Paul,

    You can put this notice in as a replacement for the previous
lamers code.  Feel free to include as much of this mail message as you
think appropriate.


    Unfortunately, as BIND 4.9.3 is getting ready to go final, I
haven't had time to modify lamers to understand the new lame
delegation reporting format.  Instead of giving you all code that
won't work with the new version of BIND, I have decided to pull the
package completely and make it available separately when ready.  Look
for it in the "DNS Resource Directory" maintained by Andras Salamon at
<URL:http://www.dns.net/dnsrd/>.  I'll also send a copy to Paul Vixie
in consideration for inclusion in the next version of BIND.

--
Brad Knowles, Internet Mail Systems Administrator     BKnowles@aol.net
comp.mail.sendmail FAQ Maintainer                         brad@his.com
                The comp.mail.sendmail FAQ is located at:
  <URL:ftp://rtfm.mit.edu/pub/usenet/news.answers/mail/sendmail-faq>

