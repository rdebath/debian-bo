void
commxForkExec(const char *cmd, char c10, char c01);
