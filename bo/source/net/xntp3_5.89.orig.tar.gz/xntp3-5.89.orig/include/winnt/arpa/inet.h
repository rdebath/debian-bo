/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for XNTP package
 **************************************************************/
/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for XNTP package
 **************************************************************/
