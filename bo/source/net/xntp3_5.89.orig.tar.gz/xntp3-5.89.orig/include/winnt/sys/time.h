/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for XNTP package
 **************************************************************/

#ifndef SYS_TIME_H
#define SYS_TIME_H

#include "ntp_types.h"
#include <time.h>
#include <sys/timeb.h>

extern int gettimeofday P((struct timeval *));
extern int settimeofday P((struct timeval *));

#endif /* SYS_TIME_H */
/**************************************************************
 * Dummy Header for Unix to Windows NT portability
 * Created for XNTP package
 **************************************************************/
