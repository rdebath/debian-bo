#define PARSESTREAM
#include "parse.c"
