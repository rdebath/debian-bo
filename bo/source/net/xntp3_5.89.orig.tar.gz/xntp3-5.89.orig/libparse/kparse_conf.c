#define PARSESTREAM
#include "parse_conf.c"
