#define PARSESTREAM
#include "clk_rawdcf.c"
