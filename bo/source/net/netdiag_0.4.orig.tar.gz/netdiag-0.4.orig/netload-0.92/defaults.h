/***************************************************************************
Just fiddle with this if you know what you're doing, and is really necessary
to change it.
Read the README file for further information on how to change it.
**************************************************************************/

#define PPP 2      /* factor fot a regular 28.8 modem */
#define ETHER 20   /* factor for the ethernet 10Mbs */

