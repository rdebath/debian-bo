/*
 * queue.h: header for queue.c
 *
 * copyright(c) 1994 matthew green
 *
 * See the copyright file, or do a help ircii copyright 
 *
 * @(#)$Id: queue.h,v 1.4 1995/08/31 03:51:53 scottr Exp $
 */

#ifndef __queue_h
# define __queue_h

	void	queuecmd _((char *, char *, char *));

#endif /* __queue_h */
