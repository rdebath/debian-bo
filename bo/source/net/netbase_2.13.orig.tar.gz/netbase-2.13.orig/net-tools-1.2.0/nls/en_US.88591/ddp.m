$set 12  #ddp

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_ddp Original Message:(Appletalk DDP)
# Appletalk DDP

