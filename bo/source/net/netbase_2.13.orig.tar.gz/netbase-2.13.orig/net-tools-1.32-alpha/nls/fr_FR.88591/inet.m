$set 14  #inet

$ #_debug1 Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: famille d'adresse pas support�e %d !\n

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_darpa Original Message:(DARPA Internet)
# DARPA Internet

$ #_table Original Message:(Kernel IP routing table\n)
# Table de routage IP noyau\n

$ #_header1 Original Message:(Destination     Gateway         Genmask         Flags Metric Ref    Use Iface\n)
# Destination     Gateway         Genmask         Flags Metric Ref    Use Iface\n

$ #_header2 Original Message:(Destination     Gateway         Genmask         Flags   MSS Window  irtt Iface\n)
# Destination     Gateway         Genmask         Flags   MSS Window  irtt Iface\n

$ #_header3 Original Message:(Destination     Gateway         Genmask         Flags Metric Ref    Use Iface    MSS   Window irtt\n)
# Destination     Gateway         Genmask         Flags Metric Ref    Use Iface    MSS   Window irtt\n

$ #_route Original Message:(unsupported address family %d !\n)
# unsupported address family %d !\n
