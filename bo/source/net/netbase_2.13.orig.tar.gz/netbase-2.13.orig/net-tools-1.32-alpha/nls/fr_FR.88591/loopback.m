$set 16  #loopback

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_unspec Original Message:(UNSPEC)
# INDEFINI

$ #_loop Original Message:(Local Loopback)
# Boucle locale

