$set 22  #lib

$ #_unknown_af Original Message:(Unknown address family `%s'.\n)
# Unknown address family `%s'.\n

$ #_toomuch_af Original Message:(Too much address family arguments.\n)
# Too much address family arguments.\n

$ #_nofeature Original Message:(%s: feature `%s' not supported. Please recompile with newer kernel.\n)
# %s: feature `%s' not supported. Please recompile with newer kernel.\n

$ #_sysnot Original Message:(%s: no support for `%s' on this system.\n)
# %s: no support for `%s' on this system.\n

$ #_masq Original Message:(IP masquerading entries\n)
# IP masquerading entries\n

$ #_masq_tit1 Original Message:(prot expire   source               destination         ports\n)
# prot expire   source               destination         ports\n

$ #_masq_tit2 Original Message:(prot expire   initseq    delta prevd source               destination         ports\n)
# prot expire   initseq    delta prevd source               destination         ports\n
