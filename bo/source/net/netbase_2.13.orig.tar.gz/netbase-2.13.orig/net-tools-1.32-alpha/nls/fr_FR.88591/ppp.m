$set 17  #ppp

$ #_cant_start Original Message:(You cannot start PPP with this program.\n)
# Vous ne pouvez pas d�marrer PPP avec ce programme.\n

$ #_ppp Original Message:(Point-Point Protocol)
# Protocole Point-�-Point

