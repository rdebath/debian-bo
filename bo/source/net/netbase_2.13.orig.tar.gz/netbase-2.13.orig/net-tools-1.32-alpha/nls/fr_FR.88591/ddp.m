$set 12  #ddp

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_ddp Original Message:(Appletalk DDP)
# DDP Appletalk 

$ #_notyet Original Message:(Routing table for `ddp' not yet supported.\n)
# Routing table for `ddp' not yet supported.\n
