$set 20  #netrom

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_debug1 Original Message:(Invalid callsign)
# Donne incorrecte

$ #_debug2 Original Message:(Callsign too long)
# Donne trop longue

$ #_hw Original Message:(AMPR NET/ROM)
# AMPR NET/ROM

$ #_netrom Original Message:(AMPR NET/ROM)
# AMPR NET/ROM

$ #_notyet Original Message:(Routing table for `netrom' not yet supported.\n)
# Routing table for `netrom' not yet supported.\n
