$set 19  #unix

$ #_none Original Message:([NONE SET])
# [PAS DEFINI]

$ #_unix Original Message:(UNIX Domain)
# Domaine UNIX

$ #_unspec Original Message:(UNSPEC)
# INDEFINI
