$set 7  #rarp

$ #_invalid Original Message:(Invalid Ethernet address: %s\n)
# Ung�ltige Ethernet-Adresse: %s\n

$ #_unkn_host Original Message:(rarp: %s: unknown host\n)
# rarp: %s: unbekannter Rechner\n

$ #_noentry Original Message:(No ARP entry for %s\n)
# Kein ARP-Eintrag f�r %s\n

$ #_usage1 Original Message:(Usage: rarp -a                   List Entries in cache.     \n)
# Benutzung: rarp -a                   Gibt Eintr�ge im Cache aus.\n

$ #_usage2 Original Message:(       rarp -d hostname          Delete hostname from cache.\n)
#        rarp -d Rechnername          L�scht Eintr�ge im Cache.\n

$ #_usage3 Original Message:(       rarp -s hostname hw_addr  Add hostname to cache.\n)
#        rarp -s Rechnername hw_Adresse  F�ge Rechnernamen zum Cache hinzu.\n

$ #_unkn_hw Original Message:(rarp: %s: unknown hardware type.\n)
# rarp: %s: unbekannter Hardwaretyp.\n
