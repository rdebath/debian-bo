$set 18  #slip

$ #_slip Original Message:(Serial Line IP)
# Serial Line IP

$ #_cslip Original Message:(VJ Serial Line IP)
# VJ Serial Line IP

$ #_slip6 Original Message:(6-bit Serial Line IP)
# 6-Bit Serial Line IP

$ #_cslip6 Original Message:(VJ 6-bit Serial Line IP)
# VJ 6-Bit Serial Line IP

$ #_adaptive Original Message:(Adaptive Serial Line IP)
# Adaptive Serial Line IP

