$set 10  #arcnet

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_debug1 Original Message:(in_arcnet(%s): invalid arcnet address!\n)
# in_arcnet(%s): ung�ltige Arcnet-Adresse!\n

$ #_debug2 Original Message:(in_arcnet(%s): invalid arcnet address!\n)
# in_arcnet(%s): ung�ltige Arcnet-Adresse!\n

$ #_debug3 Original Message:(in_arcnet(%s): trailing : ignored!\n)
# in_arcnet(%s): am Ende : ignoriert!\n

$ #_debug4 Original Message:(in_arcnet(%s): trailing junk!\n)
# in_arcnet(%s): Unsinn am Ende!\n

$ #_arcnet Original Message:(1.5Mbps ARCnet)
# 1.5Mbps ARCnet

