$set 2  #route

$ #_rresolve Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: Adressfamilie nicht unterst�tzt: %d !\n

$ #_usage1 Original Message:(Usage: route [-nvee] [-A inet|ipx|ddp|netrom],...  route {--version|--help}