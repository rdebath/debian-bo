$set 19  #unix

$ #_none Original Message:([NONE SET])
# [NICHT GESETZT]

$ #_unix Original Message:(UNIX Domain)
# UNIX Dom�ne

$ #_unspec Original Message:(UNSPEC)
# UNSPEZIFIZIERT
