$set 16  #loopback

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_unspec Original Message:(UNSPEC)
# UNSPEZIFIZIERT

$ #_loop Original Message:(Local Loopback)
# Lokaler Loopback

