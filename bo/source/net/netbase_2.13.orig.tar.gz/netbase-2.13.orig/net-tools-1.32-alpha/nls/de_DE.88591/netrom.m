$set 20  #netrom

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_debug1 Original Message:(Invalid callsign)
# Ung�ltiges Rufzeichen

$ #_debug2 Original Message:(Callsign too long)
# Rufzeichen zu lang

$ #_hw Original Message:(AMPR NET/ROM)
# AMPR NET/ROM

$ #_netrom Original Message:(AMPR NET/ROM)
# AMPR NET/ROM

$ #_notyet Original Message:(Routing table for `netrom' not yet supported.\n)
# Routing table for `netrom' not yet supported.\n

