$set 13  #ether

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_debug1 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): ung�ltige Ethernet-Adresse!\n

$ #_debug2 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): ung�ltige Ethernet-Adresse!\n

$ #_debug3 Original Message:(in_ether(%s): trailing : ignored!\n)
# in_ether(%s): am Ende : ignoriert!\n

$ #_debug4 Original Message:(in_ether(%s): trailing junk!\n)
# in_ether(%s): Unsinn am Ende!\n

$ #_ether Original Message:(10Mbps Ethernet)
# 10Mbps Ethernet

