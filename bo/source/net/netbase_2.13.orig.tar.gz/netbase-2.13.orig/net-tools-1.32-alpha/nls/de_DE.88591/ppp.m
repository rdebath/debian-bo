$set 17  #ppp

$ #_cant_start Original Message:(You cannot start PPP with this program.\n)
# Sie k�nnen PPP mit diesem Programm nicht starten.\n

$ #_ppp Original Message:(Point-Point Protocol)
# Punkt-zu-Punkt-Protokoll

