$set 12  #ddp

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_ddp Original Message:(Appletalk DDP)
# Appletalk DDP

$ #_notyet Original Message:(Routing table for `ddp' not yet supported.\n)
# Routingtabelle f�r `ddp' noch nicht unterst�tzt.\n
