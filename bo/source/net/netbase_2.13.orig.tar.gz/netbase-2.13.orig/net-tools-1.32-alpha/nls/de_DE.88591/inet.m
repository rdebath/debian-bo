$set 14  #inet

$ #_debug1 Original Message:(rresolve: unsupport address family %d !\n)
# rresolve: Adressfamilie %d nicht unterst�tzt !\n

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_darpa Original Message:(DARPA Internet)
# DARPA Internet

$ #_table Original Message:(Kernel IP routing table\n)
# Kernel IP Routing-Tabelle\n

$ #_header1 Original Message:(Destination     Gateway         Genmask         Flags Metric Ref    Use Iface\n)
# Ziel            Gateway         Maske           Optn  Metrik Ref    Ben Iface\n

$ #_header2 Original Message:(Destination     Gateway         Genmask         Flags   MSS Window  irtt Iface\n)
# Ziel            Gateway         Maske           Optn    MSS Fenster irtt Iface\n

$ #_header3 Original Message:(Destination     Gateway         Genmask         Flags Metric Ref    Use Iface    MSS   Window irtt\n)
# Ziel            Gateway         Maske            Optn Metrik Ref    Ben Iface    MSS   Fenst. irtt\n

$ #_route Original Message:(unsupported address family %d !\n)
# Adressfamilie %d nicht unterst�tzt!\n
