$set 15  #ipx

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_ipx Original Message:(IPX)
# IPX

$ #_notyet Original Message:(Routing table for `ipx' not yet supported.\n)
# Routingtabelle f�r `ipx' noch nicht unterst�tzt.\n
