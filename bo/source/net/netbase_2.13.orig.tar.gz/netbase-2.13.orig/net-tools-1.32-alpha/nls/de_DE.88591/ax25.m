$set 11  #ax25

$ #_none Original Message:([NONE SET])
# [NICHTS GESETZT]

$ #_debug1 Original Message:(Invalid callsign)
# Ung�ltiges Rufzeichen

$ #_debug2 Original Message:(Callsign too long)
# Rufzeichen zu lang

$ #_hw Original Message:(AMPR AX.25)
# AMPR AX.25

$ #_ax25 Original Message:(AMPR AX.25)
# AMPR AX.25

