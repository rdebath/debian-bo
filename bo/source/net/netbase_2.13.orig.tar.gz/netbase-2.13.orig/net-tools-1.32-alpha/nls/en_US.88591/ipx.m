$set 15  #ipx

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_ipx Original Message:(IPX)
# IPX

$ #_notyet Original Message:(Routing table for `ipx' not yet supported.\n)
# Routing table for `ipx' not yet supported.\n
