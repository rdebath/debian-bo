$set 13  #ether

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_debug1 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): invalid ether address!\n

$ #_debug2 Original Message:(in_ether(%s): invalid ether address!\n)
# in_ether(%s): invalid ether address!\n

$ #_debug3 Original Message:(in_ether(%s): trailing : ignored!\n)
# in_ether(%s): trailing : ignored!\n

$ #_debug4 Original Message:(in_ether(%s): trailing junk!\n)
# in_ether(%s): trailing junk!\n

$ #_ether Original Message:(10Mbps Ethernet)
# 10Mbps Ethernet

