$set 17  #ppp

$ #_cant_start Original Message:(You cannot start PPP with this program.\n)
# You cannot start PPP with this program.\n

$ #_ppp Original Message:(Point-Point Protocol)
# Point-Point Protocol

