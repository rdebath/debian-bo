$set 11  #ax25

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_debug1 Original Message:(Invalid callsign)
# Invalid callsign

$ #_debug2 Original Message:(Callsign too long)
# Callsign too long

$ #_hw Original Message:(AMPR AX.25)
# AMPR AX.25

$ #_ax25 Original Message:(AMPR AX.25)
# AMPR AX.25

