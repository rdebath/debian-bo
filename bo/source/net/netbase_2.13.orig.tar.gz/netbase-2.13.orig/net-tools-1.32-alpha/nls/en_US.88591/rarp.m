$set 7  #rarp

$ #_invalid Original Message:(Invalid Ethernet address: %s\n)
# Invalid Ethernet address: %s\n

$ #_unkn_host Original Message:(rarp: %s: unknown host\n)
# rarp: %s: unknown host\n

$ #_noentry Original Message:(No ARP entry for %s\n)
# No ARP entry for %s\n

$ #_usage1 Original Message:(Usage: rarp -a                   List Entries in cache.     \n)
# Usage: rarp -a                   List Entries in cache.     \n

$ #_usage2 Original Message:(       rarp -d hostname          Delete hostname from cache.\n)
#        rarp -d hostname          Delete hostname from cache.\n

$ #_usage3 Original Message:(       rarp -s hostname hw_addr  Add hostname to cache.\n)
#        rarp -s hostname hw_addr  Add hostname to cache.\n

$ #_unkn_hw Original Message:(rarp: %s: unknown hardware type.\n)
# rarp: %s: unknown hardware type.\n
