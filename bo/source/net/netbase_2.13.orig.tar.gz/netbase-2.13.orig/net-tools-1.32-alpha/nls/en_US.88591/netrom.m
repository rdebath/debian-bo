$set 20  #netrom

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_debug1 Original Message:(Invalid callsign)
# Invalid callsign

$ #_debug2 Original Message:(Callsign too long)
# Callsign too long

$ #_hw Original Message:(AMPR NetROM)
# AMPR NET/ROM

$ #_netrom Original Message:(AMPR NET/ROM)
# AMPR NET/ROM

$ #_notyet Original Message:(Routing table for `netrom' not yet supported.\n)
# Routing table for `netrom' not yet supported.\n

