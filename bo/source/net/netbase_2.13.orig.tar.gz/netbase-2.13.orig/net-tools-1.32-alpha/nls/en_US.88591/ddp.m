$set 12  #ddp

$ #_none Original Message:([NONE SET])
# [NONE SET]

$ #_ddp Original Message:(Appletalk DDP)
# Appletalk DDP

$ #_notyet Original Message:(Routing table for `ddp' not yet supported.\n)
# Routing table for `ddp' not yet supported.\n
