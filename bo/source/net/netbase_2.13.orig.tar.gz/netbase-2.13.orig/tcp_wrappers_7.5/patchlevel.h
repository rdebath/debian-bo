#ifndef lint
static char patchlevel[] = "@(#) patchlevel 7.5 97/02/12 02:13:24";
#endif
