#define	FUNC	cos
#include <acos.c>
