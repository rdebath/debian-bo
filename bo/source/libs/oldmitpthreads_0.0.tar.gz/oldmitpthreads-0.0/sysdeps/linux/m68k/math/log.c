#define	FUNC	log
#define	OP	logn
#include <acos.c>
