#define	FUNC	__expm1
#define	OP	expm1
#include <acos.c>
