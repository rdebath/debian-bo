#define	FUNC	log10l
#include <acosl.c>
