
#define	FUNC	ceil

#include <acos.c>
