#define	FUNC	asin
#include <acos.c>
