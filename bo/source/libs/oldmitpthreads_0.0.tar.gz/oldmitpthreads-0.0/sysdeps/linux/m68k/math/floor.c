#define	FUNC	floor
#define	OP	intrz
#include <acos.c>
