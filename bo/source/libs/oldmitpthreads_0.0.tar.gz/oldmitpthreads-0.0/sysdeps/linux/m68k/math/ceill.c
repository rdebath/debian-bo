
#define	FUNC	ceill

#include <acosl.c>
