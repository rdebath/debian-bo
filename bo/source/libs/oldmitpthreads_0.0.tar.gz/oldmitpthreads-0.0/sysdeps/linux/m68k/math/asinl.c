#define	FUNC	asinl
#include <acosl.c>
