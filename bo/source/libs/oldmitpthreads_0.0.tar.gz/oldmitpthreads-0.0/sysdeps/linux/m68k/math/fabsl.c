#define	FUNC	fabsl
#include <acosl.c>
