#define	FUNC	log1p
#include <acos.c>
