#include <fpu_control.h>

unsigned long __fpu_control = _FPU_IEEE;
