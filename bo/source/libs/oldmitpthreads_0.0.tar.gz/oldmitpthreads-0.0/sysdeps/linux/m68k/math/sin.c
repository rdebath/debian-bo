#define	FUNC	sin
#include <acos.c>
