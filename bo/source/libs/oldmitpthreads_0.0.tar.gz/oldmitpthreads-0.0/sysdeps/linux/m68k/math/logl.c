#define	FUNC	logl
#include <acosl.c>
