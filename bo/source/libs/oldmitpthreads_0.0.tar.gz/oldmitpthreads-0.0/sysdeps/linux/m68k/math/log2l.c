#define	FUNC	log2l
#include <acosl.c>
