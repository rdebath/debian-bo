#define	FUNC	atanh
#include <acos.c>
