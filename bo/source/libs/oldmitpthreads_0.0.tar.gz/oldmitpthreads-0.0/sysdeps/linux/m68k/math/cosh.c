#define	FUNC	cosh
#include <acos.c>
