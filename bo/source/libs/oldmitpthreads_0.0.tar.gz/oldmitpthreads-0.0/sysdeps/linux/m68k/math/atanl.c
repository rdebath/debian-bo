#define	FUNC	atanl
#include <acosl.c>
