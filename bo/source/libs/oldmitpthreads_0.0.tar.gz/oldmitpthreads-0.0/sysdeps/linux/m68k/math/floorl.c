#define	FUNC	floorl
#include <acosl.c>
