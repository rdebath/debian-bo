#define	FUNC	coshl
#include <acosl.c>
