unsigned long __fpu_control = 0;
