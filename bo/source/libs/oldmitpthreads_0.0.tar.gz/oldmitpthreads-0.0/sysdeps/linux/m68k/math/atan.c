#define	FUNC	atan
#include <acos.c>
