#define	FUNC	fabs
#define	OP	abs
#include <acos.c>
