#define	FUNC	log1pl
#include <acosl.c>
