#define	FUNC	log10
#include <acos.c>
