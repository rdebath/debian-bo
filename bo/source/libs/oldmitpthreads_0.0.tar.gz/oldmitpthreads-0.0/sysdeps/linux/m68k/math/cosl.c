#define	FUNC	cosl
#include <acosl.c>
