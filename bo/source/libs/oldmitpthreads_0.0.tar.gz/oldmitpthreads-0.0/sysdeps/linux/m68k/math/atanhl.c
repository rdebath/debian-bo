#define	FUNC	atanhl
#include <acosl.c>
