#include <locale.h>

DEFAULT_LOCALE:LC_ALL
