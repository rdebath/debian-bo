#include <fpu_control.h>

unsigned short __fpu_control = _FPU_IEEE;
