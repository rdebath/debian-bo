typedef struct Transfer_s {
	Widget          widget;
	unsigned char   operation;
}               Transfer_t, *Transfer_p;
