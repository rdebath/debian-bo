#include <Xm/DragDrop.h>

extern void drop_site_validate();

void 
drag_proc(w, client_data, cd)
	Widget          w;
	XtPointer       client_data;
	XtPointer       cd;
{
	XmDragProcCallbackStruct *call_data
	= (XmDragProcCallbackStruct *) cd;
	static Pixmap   enter_pixmap;

	if (call_data->reason == XmCR_DROP_SITE_ENTER_MESSAGE &&
	    call_data->dropSiteStatus == XmVALID_DROP_SITE) {
		Atom            selection;

		XtVaGetValues(call_data->dragContext, XmNiccHandle, &selection,
			      0);
		XtVaGetValues(w, XmNlabelPixmap, &enter_pixmap, 0);
		XtGetSelectionValue(w, selection, XA_PIXMAP, drop_site_validate,
			       (XtPointer) call_data, call_data->timeStamp);
	} else if (call_data->reason == XmCR_DROP_SITE_LEAVE_MESSAGE)
		XtVaSetValues(w, XmNlabelPixmap, enter_pixmap, 0);
}
