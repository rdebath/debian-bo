/**
 *
 * print out the translations
 *
 **/
#include <Xm/TransltnsP.h>
#include <stdio.h>

int
main() {
  printf("_XmArrowB_defaultTranslations:=\n");
  puts( _XmArrowB_defaultTranslations);
  putchar('\n');

  printf("_XmBulletinB_defaultTranslations:=\n");
  puts( _XmBulletinB_defaultTranslations);
  putchar('\n');

  printf("_XmCascadeB_menubar_events:=\n");
  puts( _XmCascadeB_menubar_events);
  putchar('\n');

  printf("_XmCascadeB_p_events:=\n");
  puts( _XmCascadeB_p_events);
  putchar('\n');

  printf("_XmDrawingA_defaultTranslations:=\n");
  puts( _XmDrawingA_defaultTranslations);
  putchar('\n');

  printf("_XmDrawingA_traversalTranslations:=\n");
  puts( _XmDrawingA_traversalTranslations);
  putchar('\n');

  printf("_XmDrawnB_defaultTranslations:=\n");
  puts( _XmDrawnB_defaultTranslations);
  putchar('\n');

  printf("_XmFrame_defaultTranslations:=\n");
  puts( _XmFrame_defaultTranslations);
  putchar('\n');

  printf("_XmLabel_defaultTranslations:=\n");
  puts( _XmLabel_defaultTranslations);
  putchar('\n');

  printf("_XmLabel_menuTranslations:=\n");
  puts( _XmLabel_menuTranslations);
  putchar('\n');

  printf("_XmLabel_menu_traversal_events:=\n");
  puts( _XmLabel_menu_traversal_events);
  putchar('\n');

  printf("_XmList_ListXlations1:=\n");
  puts( _XmList_ListXlations1);
  putchar('\n');

  printf("_XmList_ListXlations2:=\n");
  puts( _XmList_ListXlations2);
  putchar('\n');

  printf("_XmManager_managerTraversalTranslations:=\n");
  puts( _XmManager_managerTraversalTranslations);
  putchar('\n');

  printf("_XmManager_defaultTranslations:=\n");
  puts( _XmManager_defaultTranslations);
  putchar('\n');

  printf("_XmMenuShell_translations :=\n");
  puts( _XmMenuShell_translations);
  putchar('\n');

  printf("_XmPrimitive_defaultTranslations:=\n");
  puts( _XmPrimitive_defaultTranslations);
  putchar('\n');

  printf("_XmPushB_defaultTranslations:=\n");
  puts( _XmPushB_defaultTranslations);
  putchar('\n');

  printf("_XmPushB_menuTranslations:=\n");
  puts( _XmPushB_menuTranslations);
  putchar('\n');

  printf("_XmRowColumn_menu_traversal_table:=\n");
  puts( _XmRowColumn_menu_traversal_table);
  putchar('\n');

  printf("_XmRowColumn_bar_table:=\n");
  puts( _XmRowColumn_bar_table);
  putchar('\n');

  printf("_XmRowColumn_option_table:=\n");
  puts( _XmRowColumn_option_table);
  putchar('\n');

  printf("_XmRowColumn_menu_table:=\n");
  puts( _XmRowColumn_menu_table);
  putchar('\n');

  printf("_XmSash_defTranslations:=\n");
  puts( _XmSash_defTranslations);
  putchar('\n');

  printf("_XmScrollBar_defaultTranslations:=\n");
  puts( _XmScrollBar_defaultTranslations);
  putchar('\n');

  printf("_XmScrolledW_ScrolledWindowXlations:=\n");
  puts( _XmScrolledW_ScrolledWindowXlations);
  putchar('\n');

  printf("_XmScrolledW_ClipWindowTranslationTable:=\n");
  puts( _XmScrolledW_ClipWindowTranslationTable);
  putchar('\n');

  printf("_XmScrolledW_WorkWindowTranslationTable:=\n");
  puts( _XmScrolledW_WorkWindowTranslationTable);
  putchar('\n');

  printf("_XmSelectioB_defaultTextAccelerators:=\n");
  puts( _XmSelectioB_defaultTextAccelerators);
  putchar('\n');

  printf("_XmTearOffB_overrideTranslations:=\n");
  puts( _XmTearOffB_overrideTranslations);
  putchar('\n');

  printf("_XmTextF_EventBindings1:=\n");
  puts( _XmTextF_EventBindings1);
  putchar('\n');

  printf("_XmTextF_EventBindings2:=\n");
  puts( _XmTextF_EventBindings2);
  putchar('\n');

  printf("_XmTextF_EventBindings3:=\n");
  puts( _XmTextF_EventBindings3);
  putchar('\n');

  printf("_XmTextIn_XmTextEventBindings1:=\n");
  puts( _XmTextIn_XmTextEventBindings1);
  putchar('\n');

  printf("_XmTextIn_XmTextEventBindings2:=\n");
  puts( _XmTextIn_XmTextEventBindings2);
  putchar('\n');

  printf("_XmTextIn_XmTextEventBindings3:=\n");
  puts( _XmTextIn_XmTextEventBindings3);
  putchar('\n');

  printf("_XmTextIn_XmTextEventBindings3:=\n");
  puts( _XmTextIn_XmTextEventBindings3);
  putchar('\n');

  printf("_XmToggleB_defaultTranslations:=\n");
  puts( _XmToggleB_defaultTranslations);
  putchar('\n');

  printf("_XmToggleB_menuTranslations:=\n");
  puts( _XmToggleB_menuTranslations);
  putchar('\n');

  printf("_XmVirtKeys_fallbackBindingString:=\n");
  puts( _XmVirtKeys_fallbackBindingString);
  putchar('\n');
  exit(0);
}
