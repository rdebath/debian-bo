SHLIB      = libg++.sl
BUILD_LIBS = $(ARLIB) $(SHLIB)
SHFLAGS    = $(PICFLAG)
SHDEPS     =
