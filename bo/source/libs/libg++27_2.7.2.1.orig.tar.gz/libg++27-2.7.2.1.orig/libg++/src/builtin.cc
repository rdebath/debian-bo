#ifdef __GNUG__
#pragma implementation
#endif
#include <builtin.h>
