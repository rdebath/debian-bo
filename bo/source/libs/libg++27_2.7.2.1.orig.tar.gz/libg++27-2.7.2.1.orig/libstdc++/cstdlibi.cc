// Implementation file for the -*- C++ -*- standard library header.
// This file is part of the GNU ANSI C++ Library.

#ifdef __GNUG__
#pragma implementation "std/cstdlib.h"
#endif
#include <std/cstdlib.h>
