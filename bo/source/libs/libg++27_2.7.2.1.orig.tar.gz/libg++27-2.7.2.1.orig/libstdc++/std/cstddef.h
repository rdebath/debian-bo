// The -*- C++ -*- wrapper for the C standard definitions header.
// This file is part of the GNU ANSI C++ Library.

#ifndef __CSTDDEF__
#define __CSTDDEF__
#include <stddef.h>
#endif
