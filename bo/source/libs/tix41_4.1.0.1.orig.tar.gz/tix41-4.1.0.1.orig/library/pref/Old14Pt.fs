proc tixSetFontset {} {

    global tixOption

    set tixOption(font)         -*-helvetica-medium-r-normal-*-14-*-*-*-*-*-*-*
    set tixOption(bold_font)    -*-helvetica-bold-r-normal-*-14-*-*-*-*-*-*-*
    set tixOption(menu_font)    -*-helvetica-bold-o-normal-*-14-*-*-*-*-*-*-*
    set tixOption(italic_font)  -*-helvetica-bold-o-normal-*-14-*-*-*-*-*-*-*
    set tixOption(fixed_font) -*-courier-medium-r-*-*-14-*-*-*-*-*-*-*
}
