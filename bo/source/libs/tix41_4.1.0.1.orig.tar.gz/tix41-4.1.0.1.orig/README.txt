
                        TIX DOCUMENTATION MASTER INDEX
                                       
   This file is the master index of all the documentation included in
   this package. For additional information about Tix, please visit the
   Tix Home Page at http://www.xpi.com/tix/ .
   
   The documentation in this package is available in both HTML and plain
   text formats.
     * A brief descriptions of Tix.
       
     * Release notes on this version of Tix.
       
     * Compiling and installing Tix .
       
     * Programming with Tix:
          + Tix Programmer's Guide.
          + Loading Tix with the "package require" command.
          + Using Tix Stand Alone Modules (SAM).
   
       
     * The Tix Frequent Asked Questions.
       
     * Changes made to Tix since the previous release.
       
     * Useful development tools included in this package.
       
     * Programmer's Reference Manual.
       
     * Information about porting Tix to various platforms .
       
     * Documentation about Embedded TK (ET) by Richard Hipp. ET provides
       an easy way to compile your Tcl script and C source code into a
       single executable binary.
       
   
     _________________________________________________________________
   
   Last modified Sat Feb 15 13:36:14 EST 1997 --- Serial 856069647
