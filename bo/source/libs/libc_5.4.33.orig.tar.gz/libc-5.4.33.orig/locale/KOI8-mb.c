#include <ansidecl.h>
#include <localeinfo.h>
#include <stddef.h>


CONST struct ctype_mbchar_info __ctype_mbchar_KOI_8 =
  {
    0, NULL
  };
