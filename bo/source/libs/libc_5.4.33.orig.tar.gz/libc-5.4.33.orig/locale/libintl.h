#define gettext(str) (str)
#define textdomain(dom)
