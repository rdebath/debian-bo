$set 5 #HerrorList

$ #1 Original Message:(Error 0)
# Error 0

$ #2 Original Message:(Unknown host)
# Host desconocido

$ #3 Original Message:(Host name lookup failure)
# Nombre de host no encontrado

$ #4 Original Message:(Unknown server error)
# Error. Servidor desconocido

$ #5 Original Message:(No address associated with name)
# No hay una direcci�n asociada con el nombre

