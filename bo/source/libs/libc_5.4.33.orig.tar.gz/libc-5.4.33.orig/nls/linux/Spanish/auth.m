$set 7 #AuthList

$ #1 Original Message:(Authentication OK)
# Autenticaci�n correcta

$ #2 Original Message:(Invalid client credential)
# Credencial de cliente no v�lida

$ #3 Original Message:(Server rejected credential)
# Credential rechazada por el servidor

$ #4 Original Message:(Invalid client verifier)
# Verificador de cliente no v�lido

$ #5 Original Message:(Server rejected verifier)
# Verificador rechazado por el servidor

$ #6 Original Message:(Client credential too weak)
# Credential de cliente demasiado d�bil

$ #7 Original Message:(Invalid server verifier)
# Verificador de servidor no v�lido

$ #8 Original Message:(Failed (unspecified error))
# Fallo (error no especificado)

