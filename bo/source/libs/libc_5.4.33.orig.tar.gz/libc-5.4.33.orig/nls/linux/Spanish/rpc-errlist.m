$set 8 #RpcErrList

$ #1 Original Message:(RPC: Success)
# RPC: Exito

$ #2 Original Message:(RPC: Can't encode arguments)
# RPC: No puedo codificar los argumentos

$ #3 Original Message:(RPC: Can't decode result)
# RPC: No puedo decodificar el resultado

$ #4 Original Message:(RPC: Unable to send)
# RPC: Incapaz de enviar

$ #5 Original Message:(RPC: Unable to receive)
# RPC: Incapaz de recibir

$ #6 Original Message:(RPC: Timed out)
# RPC: Timed out

$ #7 Original Message:(RPC: Incompatible versions of RPC)
# RPC: Versiones incompatibles de RPC

$ #8 Original Message:(RPC: Authentication error)
# RPC: Error de autenticaci�n

$ #9 Original Message:(RPC: Program unavailable)
# RPC: Programa no disponible

$ #10 Original Message:(RPC: Program/version mismatch)
# RPC: Programa/versi�n no coinciden (mismatch)

$ #11 Original Message:(RPC: Procedure unavailable)
# RPC: Procedimiento no disponible

$ #12 Original Message:(RPC: Server can't decode arguments)
# RPC: El servidor no puede decodificar argumentos

$ #13 Original Message:(RPC: Remote system error)
# RPC: Error de sistema remoto

$ #14 Original Message:(RPC: Unknown host)
# RPC: Host desconocido

$ #15 Original Message:(RPC: Port mapper failure)
# RPC: Port mapper failure

$ #16 Original Message:(RPC: Program not registered)
# RPC: Programa no registrado

$ #17 Original Message:(RPC: Failed (unspecified error))
# RPC: Fallo (error no especificado)

$ #18 Original Message:(RPC: Unknown protocol)
# RPC: Protocolo desconocido

$ #Unknown Original Message:(RPC: (unknown error code))
# RPC: (c�digo de error desconocido)
