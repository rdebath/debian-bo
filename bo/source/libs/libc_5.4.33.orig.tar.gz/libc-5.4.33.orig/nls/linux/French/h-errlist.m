$set 5 #HerrorList

$ #1 Original Message:(Error 0)
# Erreur 0

$ #2 Original Message:(Unknown host)
# H�te inconnu

$ #3 Original Message:(Host name lookup failure)
# Echec lors de la recherche du nom de l'h�te

$ #4 Original Message:(Unknown server error)
# Erreur inconnue du serveur

$ #5 Original Message:(No address associated with name)
# Aucune adresse ne peut �tre associ�e avec le nom

