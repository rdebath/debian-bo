$set 4 #UnknownSignal

$ #0 Original Message:(Unknown signal 000000000000000000)
# Unknown signal 000000000000000000

$ #1 Original Message:(Unknown signal %d)
# Unknown signal %d
