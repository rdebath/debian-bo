$set 3  #SignalList

$ #0 Original Message:(Unknown signal)
# Unknown signal

$ #1 Original Message:(Hangup)
# Hangup

$ #2 Original Message:(Interrupt)
# Interrupt

$ #3 Original Message:(Quit)
# Quit

$ #4 Original Message:(Illegal instruction)
# Illegal instruction

$ #5 Original Message:(Trace/breakpoint trap)
# Trace/breakpoint trap

$ #6 Original Message:(IOT trap/Abort)
# IOT trap/Abort

$ #7 Original Message:(Bus Error)
# Bus Error

$ #8 Original Message:(Floating point exception)
# Floating point exception

$ #9 Original Message:(Killed)
# Killed

$ #10 Original Message:(User defined signal 1)
# User defined signal 1

$ #11 Original Message:(Segmentation fault)
# Segmentation fault

$ #12 Original Message:(User defined signal 2)
# User defined signal 2

$ #13 Original Message:(Broken pipe)
# Broken pipe

$ #14 Original Message:(Alarm clock)
# Alarm clock

$ #15 Original Message:(Terminated)
# Terminated

$ #16 Original Message:(Stack fault)
# Stack fault

$ #17 Original Message:(Child exited)
# Child exited

$ #18 Original Message:(Continued)
# Continued

$ #19 Original Message:(Stopped (signal))
# Stopped (signal)

$ #20 Original Message:(Stopped)
# Stopped

$ #21 Original Message:(Stopped (tty input))
# Stopped (tty input)

$ #22 Original Message:(Stopped (tty output))
# Stopped (tty output)

$ #23 Original Message:(Urgent condition)
# Urgent condition

$ #24 Original Message:(CPU time limit exceeded)
# CPU time limit exceeded

$ #25 Original Message:(File size limit exceeded)
# File size limit exceeded

$ #26 Original Message:(Virtual time alarm)
# Virtual time alarm

$ #27 Original Message:(Profile signal)
# Profile signal

$ #28 Original Message:(Window size changed)
# Window size changed

$ #29 Original Message:(Possible I/O)
# Possible I/O

$ #30 Original Message:(Power Failure)
# Power Failure

$ #31 Original Message:(Unused signal)
# Unused signal
