$set 6 #Getopt

$ #Ambiguous Original Message:(%s: option `%s' is ambiguous\n)
# %s: option `%s' is ambiguous\n

$ #NoArgumentsAllowed1 Original Message:(%s: option `--%s' doesn't allow an argument\n)
# %s: option `--%s' doesn't allow an argument\n

$ #NoArgumentsAllowed2 Original Message:(%s: option `%c%s' doesn't allow an argument\n)
# %s: option `%c%s' doesn't allow an argument\n

$ #RequiresArgument1 Original Message:(%s: option `%s' requires an argument\n)
# %s: option `%s' requires an argument\n

$ #RequiresArgument2 Original Message:(%s: option requires an argument -- %c\n)
# %s: option requires an argument -- %c\n

$ #Unrecognized1 Original Message:(%s: unrecognized option `--%s'\n)
# %s: unrecognized option `--%s'\n

$ #Unrecognized2 Original Message:(%s: unrecognized option `%c%s'\n)
# %s: unrecognized option `%c%s'\n

$ #Illegal Original Message:(%s: illegal option -- %c\n)
# %s: illegal option -- %c\n
