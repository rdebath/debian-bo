$set 6 #Getopt

$ #Ambiguous Original Message:(%s: option `%s' is ambiguous\n)
# %s: Option `%s' ist nicht eindeutig\n

$ #NoArgumentsAllowed1 Original Message:(%s: option `--%s' doesn't allow an argument\n)
# %s: Option `--%s' darf keine Argument haben\n

$ #NoArgumentsAllowed2 Original Message:(%s: option `%c%s' doesn't allow an argument\n)
# %s: Option `%c%s' darf keine Argument haben\n

$ #RequiresArgument1 Original Message:(%s: option `%s' requires an argument\n)
# %s: Option `%s' nur mit einem Argument m�glich\n

$ #RequiresArgument2 Original Message:(%s: option requires an argument -- %c\n)
# %s: Option ist nur mit einem Argument m�glich -- %c\n

$ #Unrecognized1 Original Message:(%s: unrecognized option `--%s'\n)
# %s: unbekannte Option `--%s'\n

$ #Unrecognized2 Original Message:(%s: unrecognized option `%c%s'\n)
# %s: unbekannte Option `%c%s'\n

$ #Illegal Original Message:(%s: illegal option -- %c\n)
# %s: ung�ltige Option -- %c\n
