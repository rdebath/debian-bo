$set 5 #HerrorList

$ #1 Original Message:(Error 0)
# Fehler 0

$ #2 Original Message:(Unknown host)
# unbekannter Host

$ #3 Original Message:(Host name lookup failure)
# Fehler beim Aufl�sen des Host-Namens

$ #4 Original Message:(Unknown server error)
# Fehler: unbekannter Server

$ #5 Original Message:(No address associated with name)
# Keine Adresse zum Namen gefunden


