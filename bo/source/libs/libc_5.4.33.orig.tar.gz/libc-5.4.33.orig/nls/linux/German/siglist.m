$set 3  #SignalList

$ #0 Original Message:(Unknown signal)
# Unbekanntes Signal

$ #1 Original Message:(Hangup)
# Aufgelegt

$ #2 Original Message:(Interrupt)
# Unterbrechung

$ #3 Original Message:(Quit)
# Verlassen

$ #4 Original Message:(Illegal instruction)
# Ung�ltiger Maschinenbefehl

$ #5 Original Message:(Trace/breakpoint trap)
# Ablaufverfolgung/Unterbrechungspunkt Falle

$ #6 Original Message:(IOT trap/Abort)
# Eingabe/Ausgabe-Falle/Abbruch

$ #7 Original Message:(Bus Error)
# Bus-Fehler

$ #8 Original Message:(Floating point exception)
# Gleitkomma-Ausnahme

$ #9 Original Message:(Killed)
# Get�tet

$ #10 Original Message:(User defined signal 1)
# Benutzer-definiertes Signal 1

$ #11 Original Message:(Segmentation fault)
# Segmentation Fehler

$ #12 Original Message:(User defined signal 2)
# Benutzer-definiertes Signal 2

$ #13 Original Message:(Broken pipe)
# Daten�bergabe unterbrochen

$ #14 Original Message:(Alarm clock)
# Wecker klingelt

$ #15 Original Message:(Terminated)
# Beendet 

$ #16 Original Message:(Stack fault)
# Stapelspeicher-Fehler

$ #17 Original Message:(Child exited)
# Kind-Proze� ist beendet

$ #18 Original Message:(Continued)
# Fortgesetzt

$ #19 Original Message:(Stopped (signal))
# Angehalten (Signal)

$ #20 Original Message:(Stopped)
# Angehalten

$ #21 Original Message:(Stopped (tty input))
# Angehalten (tty Eingabe)

$ #22 Original Message:(Stopped (tty output))
# Angehalten (tty Ausgabe)

$ #23 Original Message:(Urgent condition)
# Dringender Zustand

$ #24 Original Message:(CPU time limit exceeded)
# Prozessor-Zeit-Beschr�nkung �berschritten

$ #25 Original Message:(File size limit exceeded)
# Dateigr��enbeschr�nkung �berschritten

$ #26 Original Message:(Virtual time alarm)
# Virtueller Wecker klingelt

$ #27 Original Message:(Profile signal)
# Profile Signal

$ #28 Original Message:(Window size changed)
# Fenstergr��e ver�ndert

$ #29 Original Message:(Possible I/O)
# M�glicherweise E/A

$ #30 Original Message:(Power Failure)
# Fehler bei der Stromversorgung

$ #31 Original Message:(Unused signal)
# Unbenutztes Signal
