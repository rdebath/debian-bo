$set 8 #RpcErrList

$ #1 Original Message:(RPC: Success)
# RPC: Erfolgreich

$ #2 Original Message:(RPC: Can't encode arguments)
# RPC: Kann Argument nicht kodieren

$ #3 Original Message:(RPC: Can't decode result)
# RPC: Kann Ergebnis nicht dekodieren

$ #4 Original Message:(RPC: Unable to send)
# RPC: Kann nicht senden

$ #5 Original Message:(RPC: Unable to receive)
# RPC: Kann nicht empfangen

$ #6 Original Message:(RPC: Timed out)
# RPC: Wartezeit abgelaufen

$ #7 Original Message:(RPC: Incompatible versions of RPC)
# RPC: Inkompatible RPC Versionen

$ #8 Original Message:(RPC: Authentication error)
# RPC: Authentifizierungsfehler

$ #9 Original Message:(RPC: Program unavailable)
# RPC: Programm nicht verf�gbar

$ #10 Original Message:(RPC: Program/version mismatch)
# RPC: Programm/Version unpassend

$ #11 Original Message:(RPC: Procedure unavailable)
# RPC: Prozedur nicht verf�gbar

$ #12 Original Message:(RPC: Server can't decode arguments)
# RPC: Server kann Argumente nicht dekodieren

$ #13 Original Message:(RPC: Remote system error)
# RPC: Fehler auf dem entfernten System

$ #14 Original Message:(RPC: Unknown host)
# RPC: Host unbekannt

$ #15 Original Message:(RPC: Port mapper failure)
# RPC: Fehler des Portmappers

$ #16 Original Message:(RPC: Program not registered)
# RPC: Programm nicht registriert

$ #17 Original Message:(RPC: Failed (unspecified error))
# RPC: Fehlgeschlagen (nicht spezifizierter Fehler)

$ #18 Original Message:(RPC: Unknown protocol)
# RPC: Unbekanntes Protokoll

$ #Unknown Original Message:(RPC: (unknown error code))
# RPC: (unbekannter Fehlercode)
