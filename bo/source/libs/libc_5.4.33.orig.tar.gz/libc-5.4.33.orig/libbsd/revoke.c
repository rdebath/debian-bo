/* revoke.c - can't quite emulate BSD revoke? - rick sladkey */

int revoke(char *);		/* GCC says we need a prototype .. blah vch */

int revoke(char *line)
{
	return 0;	
}

