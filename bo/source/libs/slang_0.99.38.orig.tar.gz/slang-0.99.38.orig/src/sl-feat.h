/* Set this to 1 to enable Kanji support */
#define SLANG_HAS_KANJI_SUPPORT 0
