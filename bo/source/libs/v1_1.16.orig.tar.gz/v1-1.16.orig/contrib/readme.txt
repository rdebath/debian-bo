This directory contains contributions from V users.
Because of system limitations, I have not been able
to personally verify that these contributions work
as advertised. Generally, each contribution will
include a .txt file that will describe it. Some
contributions may be tarred. To date, this
directory contains the following:

------------------------------------------------------------
vmake_wc.zip is a Windows ZIP format file of Watcom make files
for using Watcom C++.

Contributed by:
Stig Valentini,  <x1develop@internet.dk>

------------------------------------------------------------
pstest.tar is a simple test program for testing
the PostScript printer driver.

------------------------------------------------------------
oldmake.tar contains the makefiles from previous versions
of V. They should work with 1.16, but they won't be kept
up to date with new releases of V. all the files are
named xxxx.mkf, where xxxx is the directory they belong in.
