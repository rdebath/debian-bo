/* xalloccolor.c */

/*
 * A replacement for XAllocColor which never fails.
 */


/* see Mesa/src/xmesa1.c for NoFaultXAllocColor() */

