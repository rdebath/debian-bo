/*-------------------------------------------------------------------------
 *
 * port.c--
 *    Linux-specific routines
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 *
 * IDENTIFICATION
 *    $Header: /usr/local/cvsroot/postgres95/src/backend/port/dgux/port.c,v 1.1 1996/07/25 20:44:00 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */
