/*-------------------------------------------------------------------------
 *
 * scansup.h--
 *    scanner support routines.  used by both the bootstrap lexer
 * as well as the normal lexer
 *
 * Copyright (c) 1994, Regents of the University of California
 *
 * $Id: scansup.h,v 1.1.1.1 1996/07/09 06:21:41 scrappy Exp $
 *
 *-------------------------------------------------------------------------
 */

extern char* scanstr(char *s);



