#ifndef B_H
#define B_H	"$Header: /gd5/gnu/guile-repository/guile/qt/b.h,v 1.1 1996/10/01 03:27:25 mdj Exp $"

#include "copyright.h"

extern void b_call_reg (int n);
extern void b_call_imm (int n);
extern void b_add (int n);
extern void b_load (int n);

#endif /* ndef B_H */
