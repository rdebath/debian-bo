/* Header file to be included by modules using new naming conventions */
#define Py_USE_NEW_NAMES
#include "allobjects.h"
