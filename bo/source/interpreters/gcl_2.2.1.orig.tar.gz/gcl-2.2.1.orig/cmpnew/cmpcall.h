
static object LI1();
static object LI5();
static object LI6();
static L9();
static object LI15();
static object LI1();
#define VMB1 register object *base=vs_top; object  V18 ,V10; object Vcs[2];
#define VMS1 vs_top += 2;
#define VMV1 vs_reserve(2);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2  register object *sup=vs_top+1;vs_top=sup;
#define VMV2 vs_reserve(1);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V42 ,V41 ,V37 ,V36 ,V34;
#define VMS3 vs_top += 4;
#define VMV3 vs_reserve(4);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top;
#define VMS4 vs_top += 4;
#define VMV4 vs_reserve(4);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V67 ,V65; object Vcs[4];
#define VMS5 vs_top += 2;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V75 ,V74 ,V71; object Vcs[1];
#define VMS6 vs_top += 3;
#define VMV6 vs_reserve(3);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V85;
#define VMS7 vs_top += 2;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 object  V98 ,V97;
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
#define VC9
static object LI10();
#define VMB10 register object *base=vs_top; object  V124 ,V123 ,V119 ,V114;
#define VMS10  register object *sup=vs_top+5;vs_top=sup;
#define VMV10 vs_reserve(5);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
static object LI11();
#define VMB11 register object *base=vs_top; object  V158 ,V156 ,V155 ,V154 ,V153 ,V151 ,V145 ,V142;
#define VMS11  register object *sup=vs_top+5;vs_top=sup;
#define VMV11 vs_reserve(5);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI12();
#define VMB12 object  V173 ,V172 ,V171 ,V170 ,V169 ,V166;
#define VMS12
#define VMV12
#define VMR12(VMT12) return(VMT12);
static object LI13();
#define VMB13 register object *base=vs_top;
#define VMS13  register object *sup=vs_top+1;vs_top=sup;
#define VMV13 vs_reserve(1);
#define VMR13(VMT13) vs_top=base ; return(VMT13);
static object LI14();
#define VMB14 register object *base=vs_top; object  V197 ,V194 ,V193 ,V192 ,V191;
#define VMS14  register object *sup=vs_top+7;vs_top=sup;
#define VMV14 vs_reserve(7);
#define VMR14(VMT14) vs_top=base ; return(VMT14);
static object LI15();
#define VMB15 object Vcs[4];
#define VMS15
#define VMV15
#define VMR15(VMT15) return(VMT15);
static object LI16();
#define VMB16 register object *base=vs_top; object  V214 ,V213;
#define VMS16 vs_top += 2;
#define VMV16 vs_reserve(2);
#define VMR16(VMT16) vs_top=base ; return(VMT16);
static object LI17();
#define VMB17 register object *base=vs_top; object  V227 ,V226;
#define VMS17 vs_top += 3;
#define VMV17 vs_reserve(3);
#define VMR17(VMT17) vs_top=base ; return(VMT17);
static object LI18();
#define VMB18 register object *base=vs_top; object  V235;
#define VMS18 vs_top += 2;
#define VMV18 vs_reserve(2);
#define VMR18(VMT18) vs_top=base ; return(VMT18);
static object LI19();
#define VMB19 object  V263 ,V262 ,V261 ,V259 ,V258 ,V255 ,V254 ,V253 ,V251 ,V250 ,V249 ,V245 ,V244;
#define VMS19
#define VMV19
#define VMR19(VMT19) return(VMT19);
static LC20();
#define VC20 object  V266;
static LC20();
#define VM20 3
#define VM19 0
#define VM18 2
#define VM17 3
#define VM16 2
#define VM15 0
#define VM14 7
#define VM13 1
#define VM12 0
#define VM11 5
#define VM10 5
#define VM9 3
#define VM8 0
#define VM7 2
#define VM6 3
#define VM5 2
#define VM4 4
#define VM3 4
#define VM2 1
#define VM1 2
static char * VVi[149]={
#define Cdata VV[148]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(L9),
(char *)(LI10),
(char *)(LI11),
(char *)(LI12),
(char *)(LI13),
(char *)(LI14),
(char *)(LI15),
(char *)(LI16),
(char *)(LI17),
(char *)(LI18),
(char *)(LI19)
};
#define VV ((object *)VVi)
static  LnkT147() ;
static  (*Lnk147)() = LnkT147;
static object  LnkTLI146() ;
static object  (*LnkLI146)() = LnkTLI146;
static  LnkT144() ;
static  (*Lnk144)() = LnkT144;
static object  LnkTLI143() ;
static object  (*LnkLI143)() = LnkTLI143;
static object  LnkTLI142() ;
static object  (*LnkLI142)() = LnkTLI142;
static int  LnkTLI141() ;
static int  (*LnkLI141)() = LnkTLI141;
static object  LnkTLI140() ;
static object  (*LnkLI140)() = LnkTLI140;
static object  LnkTLI139() ;
static object  (*LnkLI139)() = LnkTLI139;
static  LnkT138() ;
static  (*Lnk138)() = LnkT138;
static  LnkT137() ;
static  (*Lnk137)() = LnkT137;
static object  LnkTLI136() ;
static object  (*LnkLI136)() = LnkTLI136;
static object  LnkTLI135() ;
static object  (*LnkLI135)() = LnkTLI135;
static object  LnkTLI134() ;
static object  (*LnkLI134)() = LnkTLI134;
static object  LnkTLI133() ;
static object  (*LnkLI133)() = LnkTLI133;
static object  LnkTLI132() ;
static object  (*LnkLI132)() = LnkTLI132;
static object  LnkTLI131() ;
static object  (*LnkLI131)() = LnkTLI131;
static object  LnkTLI130() ;
static object  (*LnkLI130)() = LnkTLI130;
static  LnkT129() ;
static  (*Lnk129)() = LnkT129;
static object  LnkTLI128() ;
static object  (*LnkLI128)() = LnkTLI128;
static object  LnkTLI127() ;
static object  (*LnkLI127)() = LnkTLI127;
static object  LnkTLI126() ;
static object  (*LnkLI126)() = LnkTLI126;
static object  LnkTLI125() ;
static object  (*LnkLI125)() = LnkTLI125;
static object  LnkTLI124() ;
static object  (*LnkLI124)() = LnkTLI124;
static object  LnkTLI123() ;
static object  (*LnkLI123)() = LnkTLI123;
static  LnkT122() ;
static  (*Lnk122)() = LnkT122;
static object  LnkTLI121() ;
static object  (*LnkLI121)() = LnkTLI121;
static object  LnkTLI120() ;
static object  (*LnkLI120)() = LnkTLI120;
static object  LnkTLI119() ;
static object  (*LnkLI119)() = LnkTLI119;
static object  LnkTLI118() ;
static object  (*LnkLI118)() = LnkTLI118;
static object  LnkTLI117() ;
static object  (*LnkLI117)() = LnkTLI117;
static object  LnkTLI116() ;
static object  (*LnkLI116)() = LnkTLI116;
static object  LnkTLI115() ;
static object  (*LnkLI115)() = LnkTLI115;
static object  LnkTLI114() ;
static object  (*LnkLI114)() = LnkTLI114;
static object  LnkTLI113() ;
static object  (*LnkLI113)() = LnkTLI113;
static object  LnkTLI112() ;
static object  (*LnkLI112)() = LnkTLI112;
static object  LnkTLI111() ;
static object  (*LnkLI111)() = LnkTLI111;
static object  LnkTLI110() ;
static object  (*LnkLI110)() = LnkTLI110;
static object  LnkTLI109() ;
static object  (*LnkLI109)() = LnkTLI109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static object  LnkTLI107() ;
static object  (*LnkLI107)() = LnkTLI107;
static object  LnkTLI106() ;
static object  (*LnkLI106)() = LnkTLI106;
static object  LnkTLI105() ;
static object  (*LnkLI105)() = LnkTLI105;
static object  LnkTLI104() ;
static object  (*LnkLI104)() = LnkTLI104;
static object  LnkTLI103() ;
static object  (*LnkLI103)() = LnkTLI103;
static object  LnkTLI102() ;
static object  (*LnkLI102)() = LnkTLI102;
static object  LnkTLI101() ;
static object  (*LnkLI101)() = LnkTLI101;
static object  LnkTLI100() ;
static object  (*LnkLI100)() = LnkTLI100;
static object  LnkTLI99() ;
static object  (*LnkLI99)() = LnkTLI99;
static object  LnkTLI98() ;
static object  (*LnkLI98)() = LnkTLI98;
static object  LnkTLI97() ;
static object  (*LnkLI97)() = LnkTLI97;
static object  LnkTLI96() ;
static object  (*LnkLI96)() = LnkTLI96;
