
static L6();
static object LI1();
#define VMB1 object  V3;
#define VMS1
#define VMV1
#define VMR1(VMT1) return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top;
#define VMS2 vs_top += 2;
#define VMV2 vs_reserve(2);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 object  V14;
#define VMS3
#define VMV3
#define VMR3(VMT3) return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V25 ,V24 ,V23 ,V22 ,V21;
#define VMS4  register object *sup=vs_top+1;vs_top=sup;
#define VMV4 vs_reserve(1);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V35 ,V33;
#define VMS5  register object *sup=vs_top+3;vs_top=sup;
#define VMV5 vs_reserve(3);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
#define VC6
static object LI7();
#define VMB7 register object *base=vs_top; object  V48 ,V44;
#define VMS7 vs_top += 4;
#define VMV7 vs_reserve(4);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 object  V69 ,V68 ,V67 ,V64 ,V63 ,V62 ,V59 ,V57 ,V55;
#define VMS8
#define VMV8
#define VMR8(VMT8) return(VMT8);
static object LI9();
#define VMB9
#define VMS9
#define VMV9
#define VMR9(VMT9) return(VMT9);
static object LI10();
#define VMB10
#define VMS10
#define VMV10
#define VMR10(VMT10) return(VMT10);
#define VM10 0
#define VM9 0
#define VM8 0
#define VM7 4
#define VM6 5
#define VM5 3
#define VM4 1
#define VM3 0
#define VM2 2
#define VM1 0
static char * VVi[72]={
#define Cdata VV[71]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(L6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(LI10)
};
#define VV ((object *)VVi)
static object  LnkTLI70() ;
static object  (*LnkLI70)() = LnkTLI70;
static object  LnkTLI69() ;
static object  (*LnkLI69)() = LnkTLI69;
static object  LnkTLI68() ;
static object  (*LnkLI68)() = LnkTLI68;
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static object  LnkTLI66() ;
static object  (*LnkLI66)() = LnkTLI66;
static object  LnkTLI65() ;
static object  (*LnkLI65)() = LnkTLI65;
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static object  LnkTLI63() ;
static object  (*LnkLI63)() = LnkTLI63;
static object  LnkTLI62() ;
static object  (*LnkLI62)() = LnkTLI62;
static object  LnkTLI61() ;
static object  (*LnkLI61)() = LnkTLI61;
static object  LnkTLI60() ;
static object  (*LnkLI60)() = LnkTLI60;
static  LnkT59() ;
static  (*Lnk59)() = LnkT59;
static object  LnkTLI58() ;
static object  (*LnkLI58)() = LnkTLI58;
static object  LnkTLI57() ;
static object  (*LnkLI57)() = LnkTLI57;
static object  LnkTLI56() ;
static object  (*LnkLI56)() = LnkTLI56;
static  LnkT55() ;
static  (*Lnk55)() = LnkT55;
static object  LnkTLI54() ;
static object  (*LnkLI54)() = LnkTLI54;
static object  LnkTLI53() ;
static object  (*LnkLI53)() = LnkTLI53;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static object  LnkTLI45() ;
static object  (*LnkLI45)() = LnkTLI45;
