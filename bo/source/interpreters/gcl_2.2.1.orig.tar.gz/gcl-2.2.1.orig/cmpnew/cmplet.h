
static L8();
static object LI1();
#define VMB1 register object *base=vs_top; object  V28 ,V25 ,V22 ,V21 ,V20 ,V19 ,V17 ,V16;
#define VMS1  register object *sup=vs_top+4;vs_top=sup;
#define VMV1 vs_reserve(4);
#define VMR1(VMT1) vs_top=base ; return(VMT1);
static object LI2();
#define VMB2 register object *base=vs_top; object  V80 ,V77 ,V76 ,V75 ,V74 ,V73 ,V72 ,V71 ,V70 ,V69 ,V67 ,V66 ,V64 ,V62 ,V61 ,V60 ,V59 ,V58 ,V57 ,V55 ,V52 ,V50 ,V49 ,V47 ,V45;
#define VMS2  register object *sup=vs_top+8;vs_top=sup;
#define VMV2 vs_reserve(8);
#define VMR2(VMT2) vs_top=base ; return(VMT2);
static object LI3();
#define VMB3 register object *base=vs_top; object  V110 ,V107 ,V106 ,V105 ,V104 ,V103 ,V101 ,V100;
#define VMS3  register object *sup=vs_top+4;vs_top=sup;
#define VMV3 vs_reserve(4);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V152 ,V150 ,V149 ,V143 ,V142 ,V141 ,V139 ,V137 ,V136 ,V134 ,V131 ,V129 ,V128 ,V125;
#define VMS4  register object *sup=vs_top+8;vs_top=sup;
#define VMV4 vs_reserve(8);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 object  V169 ,V167 ,V165 ,V163 ,V160 ,V159;
#define VMS5
#define VMV5
#define VMR5(VMT5) return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top; object  V182;
#define VMS6 vs_top += 1;
#define VMV6 vs_reserve(1);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top;
#define VMS7  register object *sup=vs_top+2;vs_top=sup;
#define VMV7 vs_reserve(2);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
#define VC8
static object LI9();
#define VMB9 register object *base=vs_top; object  V206 ,V205 ,V200;
#define VMS9 vs_top += 1;
#define VMV9 vs_reserve(1);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
static object LI10();
#define VMB10 register object *base=vs_top; object  V213;
#define VMS10  register object *sup=vs_top+3;vs_top=sup;
#define VMV10 vs_reserve(3);
#define VMR10(VMT10) vs_top=base ; return(VMT10);
#define VM10 3
#define VM9 1
#define VM8 4
#define VM7 2
#define VM6 1
#define VM5 0
#define VM4 8
#define VM3 4
#define VM2 8
#define VM1 4
static char * VVi[78]={
#define Cdata VV[77]
(char *)(LI1),
(char *)(LI2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(L8),
(char *)(LI9),
(char *)(LI10)
};
#define VV ((object *)VVi)
static object  LnkTLI76() ;
static object  (*LnkLI76)() = LnkTLI76;
static object  LnkTLI75() ;
static object  (*LnkLI75)() = LnkTLI75;
static object  LnkTLI74() ;
static object  (*LnkLI74)() = LnkTLI74;
static object  LnkTLI73() ;
static object  (*LnkLI73)() = LnkTLI73;
static  LnkT72() ;
static  (*Lnk72)() = LnkT72;
static object  LnkTLI71() ;
static object  (*LnkLI71)() = LnkTLI71;
static object  LnkTLI69() ;
static object  (*LnkLI69)() = LnkTLI69;
static  LnkT68() ;
static  (*Lnk68)() = LnkT68;
static object  LnkTLI67() ;
static object  (*LnkLI67)() = LnkTLI67;
static object  LnkTLI66() ;
static object  (*LnkLI66)() = LnkTLI66;
static object  LnkTLI12() ;
static object  (*LnkLI12)() = LnkTLI12;
static object  LnkTLI65() ;
static object  (*LnkLI65)() = LnkTLI65;
static object  LnkTLI64() ;
static object  (*LnkLI64)() = LnkTLI64;
static object  LnkTLI63() ;
static object  (*LnkLI63)() = LnkTLI63;
static object  LnkTLI62() ;
static object  (*LnkLI62)() = LnkTLI62;
static object  LnkTLI55() ;
static object  (*LnkLI55)() = LnkTLI55;
static object  LnkTLI54() ;
static object  (*LnkLI54)() = LnkTLI54;
static  LnkT53() ;
static  (*Lnk53)() = LnkT53;
static object  LnkTLI52() ;
static object  (*LnkLI52)() = LnkTLI52;
static object  LnkTLI51() ;
static object  (*LnkLI51)() = LnkTLI51;
static object  LnkTLI50() ;
static object  (*LnkLI50)() = LnkTLI50;
static object  LnkTLI49() ;
static object  (*LnkLI49)() = LnkTLI49;
static object  LnkTLI48() ;
static object  (*LnkLI48)() = LnkTLI48;
static object  LnkTLI47() ;
static object  (*LnkLI47)() = LnkTLI47;
static object  LnkTLI46() ;
static object  (*LnkLI46)() = LnkTLI46;
static object  LnkTLI45() ;
static object  (*LnkLI45)() = LnkTLI45;
static object  LnkTLI44() ;
static object  (*LnkLI44)() = LnkTLI44;
static object  LnkTLI43() ;
static object  (*LnkLI43)() = LnkTLI43;
static object  LnkTLI42() ;
static object  (*LnkLI42)() = LnkTLI42;
static  LnkT41() ;
static  (*Lnk41)() = LnkT41;
static object  LnkTLI40() ;
static object  (*LnkLI40)() = LnkTLI40;
static object  LnkTLI39() ;
static object  (*LnkLI39)() = LnkTLI39;
