
static L1();
static L2();
static L10();
static L14();
static L15();
static L16();
#define VC1
#define VC2
static object LI3();
#define VMB3 register object *base=vs_top; object  V26 ,V25 ,V24 ,V19 ,V18 ,V17 ,V16 ,V15 ,V14;
#define VMS3  register object *sup=vs_top+1;vs_top=sup;
#define VMV3 vs_reserve(1);
#define VMR3(VMT3) vs_top=base ; return(VMT3);
static object LI4();
#define VMB4 register object *base=vs_top; object  V30;
#define VMS4  register object *sup=vs_top+2;vs_top=sup;
#define VMV4 vs_reserve(2);
#define VMR4(VMT4) vs_top=base ; return(VMT4);
static object LI5();
#define VMB5 register object *base=vs_top; object  V38 ,V37;
#define VMS5  register object *sup=vs_top+2;vs_top=sup;
#define VMV5 vs_reserve(2);
#define VMR5(VMT5) vs_top=base ; return(VMT5);
static object LI6();
#define VMB6 register object *base=vs_top;
#define VMS6  register object *sup=vs_top+3;vs_top=sup;
#define VMV6 vs_reserve(3);
#define VMR6(VMT6) vs_top=base ; return(VMT6);
static object LI7();
#define VMB7 register object *base=vs_top; object  V63;
#define VMS7  register object *sup=vs_top+4;vs_top=sup;
#define VMV7 vs_reserve(4);
#define VMR7(VMT7) vs_top=base ; return(VMT7);
static object LI8();
#define VMB8 register object *base=vs_top;
#define VMS8  register object *sup=vs_top+2;vs_top=sup;
#define VMV8 vs_reserve(2);
#define VMR8(VMT8) vs_top=base ; return(VMT8);
static object LI9();
#define VMB9 register object *base=vs_top;
#define VMS9 vs_top += 1;
#define VMV9 vs_reserve(1);
#define VMR9(VMT9) vs_top=base ; return(VMT9);
#define VC10 object  V88 ,V87 ,V85 ,V84 ,V83 ,V82 ,V81;
static object LI12();
#define VMB11 register object *base=vs_top; object  V96 ,V95 ,V94 ,V93;
#define VMS11  register object *sup=vs_top+4;vs_top=sup;
#define VMV11 vs_reserve(4);
#define VMR11(VMT11) vs_top=base ; return(VMT11);
static object LI13();
#define VMB12 register object *base=vs_top;
#define VMS12  register object *sup=vs_top+2;vs_top=sup;
#define VMV12 vs_reserve(2);
#define VMR12(VMT12) vs_top=base ; return(VMT12);
#define VC13 object  V106 ,V105;
#define VC14
#define VC15 object  V122 ,V115 ,V113 ,V112;
static LC17();
#define VC16
static LC17();
#define VM16 2
#define VM15 14
#define VM14 4
#define VM13 5
#define VM12 2
#define VM11 4
#define VM10 12
#define VM9 1
#define VM8 2
#define VM7 4
#define VM6 3
#define VM5 2
#define VM4 2
#define VM3 1
#define VM2 4
#define VM1 4
static char * VVi[116]={
#define Cdata VV[115]
(char *)(L1),
(char *)(L2),
(char *)(LI3),
(char *)(LI4),
(char *)(LI5),
(char *)(LI6),
(char *)(LI7),
(char *)(LI8),
(char *)(LI9),
(char *)(L10),
(char *)(LI12),
(char *)(LI13),
(char *)(L14),
(char *)(L15),
(char *)(L16)
};
#define VV ((object *)VVi)
static  LnkT114() ;
static  (*Lnk114)() = LnkT114;
static  LnkT113() ;
static  (*Lnk113)() = LnkT113;
static  LnkT112() ;
static  (*Lnk112)() = LnkT112;
static object  LnkTLI111() ;
static object  (*LnkLI111)() = LnkTLI111;
static  LnkT60() ;
static  (*Lnk60)() = LnkT60;
static object  LnkTLI110() ;
static object  (*LnkLI110)() = LnkTLI110;
static object  LnkTLI109() ;
static object  (*LnkLI109)() = LnkTLI109;
static object  LnkTLI108() ;
static object  (*LnkLI108)() = LnkTLI108;
static object  LnkTLI107() ;
static object  (*LnkLI107)() = LnkTLI107;
static object  LnkTLI106() ;
static object  (*LnkLI106)() = LnkTLI106;
static object  LnkTLI105() ;
static object  (*LnkLI105)() = LnkTLI105;
static object  LnkTLI104() ;
static object  (*LnkLI104)() = LnkTLI104;
static object  LnkTLI103() ;
static object  (*LnkLI103)() = LnkTLI103;
