package Tk::ImageBack;
require DynaLoader;
require Tk;

@ISA = qw(DynaLoader);

bootstrap Tk::ImageBack;

1;
__END__
