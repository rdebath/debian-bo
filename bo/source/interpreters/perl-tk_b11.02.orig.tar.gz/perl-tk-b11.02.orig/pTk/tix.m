#ifndef _TIX_VM
#define _TIX_VM
#include "tix_f.h"
#define Tix_GetScrollFractions (*TixVptr->V_Tix_GetScrollFractions)
#define Tix_HandleSubCmds (*TixVptr->V_Tix_HandleSubCmds)
#define Tix_LinkListAppend (*TixVptr->V_Tix_LinkListAppend)
#define Tix_LinkListDelete (*TixVptr->V_Tix_LinkListDelete)
#define Tix_LinkListDeleteRange (*TixVptr->V_Tix_LinkListDeleteRange)
#define Tix_LinkListFind (*TixVptr->V_Tix_LinkListFind)
#define Tix_LinkListInit (*TixVptr->V_Tix_LinkListInit)
#define Tix_LinkListInsert (*TixVptr->V_Tix_LinkListInsert)
#define Tix_LinkListIteratorInit (*TixVptr->V_Tix_LinkListIteratorInit)
#define Tix_LinkListNext (*TixVptr->V_Tix_LinkListNext)
#define Tix_LinkListStart (*TixVptr->V_Tix_LinkListStart)
#endif /* _TIX_VM */
