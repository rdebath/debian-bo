#ifndef KEY___FILE__
#include <keywords.h>
#endif
#ifndef KEY___DATA__
#define pregexec regexec
#define pregcomp regcomp
#define pregfree regfree
#endif

