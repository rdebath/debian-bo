ccflags="$ccflags -DCRIPPLED_CC"
d_lstat=define
