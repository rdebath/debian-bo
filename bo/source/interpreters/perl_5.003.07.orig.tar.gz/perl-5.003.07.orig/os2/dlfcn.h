void *dlopen(char *path, int mode);
void *dlsym(void *handle, char *symbol);
char *dlerror(void);
