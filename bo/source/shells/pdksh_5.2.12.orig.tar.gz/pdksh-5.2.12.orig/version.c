/*
 * value of $KSH_VERSION (or $SH_VERSION)
 */

#include "sh.h"

const char ksh_version [] =
	"@(#)PD KSH v5.2.12 96/10/29";
