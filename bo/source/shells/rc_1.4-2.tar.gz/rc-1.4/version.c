const char id[] = "@(#)rc version 1.4, 5/26/92.";
