/*
 * Copyright (c) 1995, 1996, 1997 Joey Hess (joey@kite.ml.org)
 * All rights reserved. See COPYING for full copyright information (GPL).
 */

void Handle_Ctrl_C(void);
void DrawAll(void);
void Force_Redraw(void);
void Resize_Screen(void);
