/* $Header: /u/christos/cvsroot/tcsh/patchlevel.h,v 3.102 1996/10/27 17:00:27 christos Exp $ */
/*
 * patchlevel.h: Our life story.
 */
#ifndef _h_patchlevel
#define _h_patchlevel

#define ORIGIN "Astron"
#define REV 6
#define VERS 7
#define PATCHLEVEL 2
#define DATE "1996-10-27"

#endif /* _h_patchlevel */
