/*
 *	This is for Motorola System V/88 Release 3.
 *	From: Jeff Johnson <jjohnson@urbana.mcd.mot.com>
 *	      Motorola Inc -- Urbana Design Center, May 22, 90
 */

#include "s-sys5.h"

#define HAVE_JOBCONTROL
#define HAVE_MULTIGROUP
#define OLD_AWK	"oawk"
