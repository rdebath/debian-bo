/*
 *	This file is for the Texas Instruments System 1500
 *	68020/68030 based multiprocessor systems (use with m-m680x0.h).
 */

#include "s-sys5.h"
