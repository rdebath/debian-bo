/*
 *	This version is for SunOS 3.x systems (tested on 3.5)
 */

#define	USE_STRINGS_H

#include "s-bsd4-2.h"

#define	HAVE_STRCHR

/*
 *	Define if your system has a 4.3BSD like ualarm call.
 */

#define HAVE_UALARM
