/*
 *	This version is for 4.3 systems
 */

#include "s-bsd4-2.h"

/*
 *	Define if your system has a 4.3BSD like ualarm call.
 */

#define HAVE_UALARM

/*
 *	Define if your system has a 4.3BSD like syslog library.
 */

#define HAVE_SYSLOG

#define HAVE_TRUNCATE
