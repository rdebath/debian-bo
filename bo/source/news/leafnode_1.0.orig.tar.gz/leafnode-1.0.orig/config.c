const char * spooldir = SPOOLDIR ;
const char * libdir = LIBDIR ;
