/*
 * Time manipulation routines.
 *
 * @(#)time.h	1.1	(Berkeley) 12/18/87
 */

extern	long	dtol();
extern	char	*ltod();
extern	long	local_to_gmt();
extern	long	gmt_to_local();
