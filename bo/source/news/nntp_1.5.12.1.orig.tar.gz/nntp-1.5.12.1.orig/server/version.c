/*
 * Provide the version number of this release.
 */

char	nntp_version[] = "1.5.12.1 (1 Jan 1995)";
