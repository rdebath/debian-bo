extern int ftp_get(void);
extern int ftp_put(void);
