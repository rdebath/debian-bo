/* This software is Copyright 1995, 1996 by Karl-Johan Johnsson
 *
 * Permission is hereby granted to copy, reproduce, redistribute or otherwise
 * use this software as long as: there is no monetary profit gained
 * specifically from the use or reproduction of this software, it is not
 * sold, rented, traded or otherwise marketed, and this copyright notice is
 * included prominently in any copy made. 
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. ANY USE OF THIS
 * SOFTWARE IS AT THE USERS OWN RISK.
 */
extern void knapp0_callback(Widget, XtPointer, XtPointer);
extern void knapp1_callback(Widget, XtPointer, XtPointer);
extern void knapp2_callback(Widget, XtPointer, XtPointer);
extern void knapp5_callback(Widget, XtPointer, XtPointer);
extern void knapp6_callback(Widget, XtPointer, XtPointer);
extern void knapp7_callback(Widget, XtPointer, XtPointer);
extern void knapp8_callback(Widget, XtPointer, XtPointer);
extern void knapp10_callback(Widget, XtPointer, XtPointer);
extern void knapp11_callback(Widget, XtPointer, XtPointer);
extern void thread_list_sel_callback(Widget, XtPointer, XtPointer);
extern void thread_list_callback(Widget, XtPointer, XtPointer);
extern void arttree_sel_callback(Widget, XtPointer, XtPointer);
extern void group_list_callback(Widget, XtPointer, XtPointer);
extern void group_list_sel_callback(Widget, XtPointer, XtPointer);
extern void group_list_dnd_callback(Widget, XtPointer, XtPointer);
extern void delete_window_callback(Widget, XtPointer, XtPointer);
extern void sash_callback(Widget, XtPointer, XtPointer);
