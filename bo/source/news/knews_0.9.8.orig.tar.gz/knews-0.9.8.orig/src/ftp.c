#include "global.h"

int ftp_get(void)
{
    return True;
}

int ftp_put(void)
{
    return True;
}
