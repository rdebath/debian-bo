/*
 * batch file names
 */
#ifndef BTCHDIR
#define BTCHDIR "out.going/"	/* prefix of relative batch file name */
#endif
#define BTCHPFX BTCHDIR		/* prefix of default batch file name */
#ifndef BTCHSFX
#define BTCHSFX "/togo"		/* suffix of same */
#endif
