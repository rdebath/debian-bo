/* imports from mkdirs.c */
extern boolean mkdirs();
