/* imports from caches.c */
extern statust loadcaches(), synccaches();
