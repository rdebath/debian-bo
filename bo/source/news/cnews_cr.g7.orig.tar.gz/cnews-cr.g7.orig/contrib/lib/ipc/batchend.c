/* called by error.  If really needed, we would get it from batch.c */
void
batchend()
{
}
