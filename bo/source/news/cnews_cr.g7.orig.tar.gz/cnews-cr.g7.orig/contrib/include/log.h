extern char *logstr;
extern void loginit(/* char *s */);
extern void log(/* char *s */);
extern void logtimes(/* char *s */);
extern void log3int(/* char *fmt, int i, int j, int k */);
