extern struct tm *isodate2tm();
extern char *tm2isodate();
extern char *time2isodate();
