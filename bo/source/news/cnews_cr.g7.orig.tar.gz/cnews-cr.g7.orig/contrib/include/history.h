extern void histinit(/* void */);
extern void histclose(/* void */);
extern char *histlook(/* char *msgid */);
extern char *histslash(/* char *s */);
