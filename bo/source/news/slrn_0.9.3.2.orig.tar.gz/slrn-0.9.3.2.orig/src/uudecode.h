extern int slrn_uudecode_file (char *, char *, int, FILE *fp);
#ifndef STANDALONE
extern char *Slrn_Decode_Directory;
#endif
