extern int slrn_init_slang (void);
extern int slrn_eval_slang_file (char *);
extern int Slrn_Use_Slang;
extern char *Slrn_Macro_Dir;
