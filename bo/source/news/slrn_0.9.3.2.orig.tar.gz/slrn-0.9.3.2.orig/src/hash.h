extern unsigned long slrn_compute_hash (unsigned char *, unsigned char *);

#if SLRN_HAS_MSGID_CACHE
extern char *slrn_is_msgid_cached (char *, char *, int);
#endif
