/*
 * $Revision: 1.22 $
 */


/*
**  If you make local modifications to INN, change this line as needed:
*/
#define LOCAL_STRING	""


/*
**  Try to avoid changing these.
*/
#define RELEASE "1"
#define PATCHLEVEL "5.1"
#define DATE "17-Dec-1996"


/*
**  See lib/innvers.c, but the version string should look like this:
**	INN ${RELEASE}.${PATCHLEVEL} ${DATE} (${LOCAL_STRING})
**  for example:
**	INN 1.0 10-Feb-92 (FOO.COM)
*/
