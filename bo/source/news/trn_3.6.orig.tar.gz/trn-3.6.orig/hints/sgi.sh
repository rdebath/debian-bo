d_voidsig=define
d_vfork=undef
d_sigblock=undef
