libswanted=`echo $libswanted | sed -e 's/socket /socket seq inet /'`
