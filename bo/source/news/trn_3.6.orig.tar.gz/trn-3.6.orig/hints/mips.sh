cc=cc
nm_opts='-B'
