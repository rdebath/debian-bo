i_dirent=undef
libswanted=`echo $libswanted | sed 's/ x//'`
