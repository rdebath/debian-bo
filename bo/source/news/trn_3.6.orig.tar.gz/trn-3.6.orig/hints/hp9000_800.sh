libswanted=`echo $libswanted | sed -e 's/malloc //' -e 's/BSD //`
