d_sigblock='undef'
d_getcwd='define'
d_getwd='undef'
libs='-lmalloc -lsocket -lnls -lnsl -lintl'
