/*
 * kncache.h -- Thu Sep 12 17:14:58 MET DST 1996
 */


/*
 * From /usr/src/linux/fs/dcache.c:
 */


#define DCACHE_SIZE 128
#define DCACHE_NAME_LEN	15

struct hash_list {
	struct dir_cache_entry * next;
	struct dir_cache_entry * prev;
};
struct dir_cache_entry {
	struct hash_list h;
	kdev_t dc_dev;
	unsigned long dir;
	unsigned long version;
	unsigned long ino;
	unsigned char name_len;
	char name[DCACHE_NAME_LEN];
	struct dir_cache_entry ** lru_head;
	struct dir_cache_entry * next_lru,  * prev_lru;
};


/*
 * From /usr/src/linux/fs/nfs/dir.c:
 */


struct nfs_lookup_cache_entry {
	kdev_t dev;
	int inode;
	char filename[NFS_MAXNAMLEN + 1];
	struct nfs_fh fhandle;
	struct nfs_fattr fattr;
	int expiration_date;
};

#define HASDEVKNC 1

#define HASNFSKNC 1
#include <linux/nfs.h>
#include <linux/nfs_fs.h>
