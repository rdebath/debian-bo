/*
 * dlsof.h - NEXTSTEP header file for lsof
 */


/*
 * Copyright 1994 Purdue Research Foundation, West Lafayette, Indiana
 * 47907.  All rights reserved.
 *
 * Written by Victor A. Abell
 *
 * This software is not subject to any license of the American Telephone
 * and Telegraph Company or the Regents of the University of California.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Neither the authors nor Purdue University are responsible for any
 *    consequences of the use of this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to the authors and Purdue
 *    University must appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */


/*
 * $Id: dlsof.h,v 1.15 96/03/24 12:44:01 abe Exp $
 */


#if	!defined(LSOF_NEXT_H)
#define	LSOF_NEXT_H	1

#include <c.h>
#include <stdlib.h>
#include <string.h>
#include <mntent.h>
#include <nlist.h>
#include <signal.h>
#include <setjmp.h>

# if	!defined(NCPUS)
#define NCPUS	1
# endif

#include <rpc/rpc.h>
#include <rpc/xdr.h>
#include <nfs/nfs.h>
#include <nfs/nfs_clnt.h>
#include <sys/vnode.h>
#include <sys/wait.h>
#include <nfs/rnode.h>
#include <sys/dir.h>
#include <sys/domain.h>

# if	!defined(KERNEL)
#define KERNEL
# endif

#include <sys/file.h>
#undef  KERNEL
#include <sys/mbuf.h>
#include <ufs/mount.h>
#include <sys/protosw.h>
#include <sys/socket.h>
#include <sys/socketvar.h>
#include <sys/stat.h>
#include <sys/ucred.h>
#include <netinet/in.h>
#include <net/route.h>
#include <net/raw_cb.h>
#include <netinet/in_pcb.h>
#include <sys/un.h>
#include <sys/unpcb.h>

# if	!defined(SHOW_UTT)
#define SHOW_UTT
# endif

#include <sys/user.h>
#define u_comm	uu_comm
#define u_cdir	uu_cdir
#define u_rdir	uu_rdir
#undef	SHOW_UTT
#include <sys/proc.h>
#include <sys/vfs.h>
#include <ufs/inode.h>

typedef	int	pid_t;


/*
 * The following substitution compensates for the snode.h that NeXT does
 * not supply in NEXTSTEP 2.0 and above.  The value of interest is s_realvp.
 */

struct snode {
	struct	snode *s_next;		/* must be first */
	struct	vnode s_vnode;		/* vnode associated with this snode */
	struct	vnode *s_realvp;	/* vnode for the fs entry (if any) */
};


/*
 * Miscellaneous definitions.
 */

#define	COMP_P		const void
#define DEVINCR		1024		/* device table malloc() increment */
#define	KA_T		off_t
#define	KMEM		"/dev/kmem"
#define MALLOC_P	void
#define FREE_P		MALLOC_P
#define MALLOC_S	size_t
#define	PROCDFLT	256	/* default size of local proc table */
#define	PROCMIN		5	/* processes that make a "good" scan */
#define PROCSIZE	sizeof(struct proc)
#define	PROCTRYLM	5	/* times to try to read proc table */
#define QSORT_P		void
#define	READLEN_T	int
#define STRNCPY_L	int
#define	UIDCACHEL	8192
#define U_SIZE		sizeof(struct user)

#  if	!defined(VMUNIX)
#define VMUNIX		"/mach"
#  endif

#define	N_UNIX		VMUNIX


# if	defined(HAS_AFS)
/*
 * AFS definitions
 */

#define	AFSAPATHDEF	"/usr/vice/etc/afs_loadable"
#define	AFSDEV		1		/* AFS "fake" device number */

#  if	defined(HASAOPT)
extern char *AFSApath;			/* alternate AFS name list path
					 * (from -A) */
#  endif	/* defined(HASAOPT) */

extern struct vfs *AFSVfsp;		/* AFS struct vfs kernel pointer */
# endif	/* defined(HAS_AFS) */


/*
 * Local vfs information
 */

struct l_vfs {
	struct vfs *addr;		/* kernel address */
	char *dir;			/* mounted directory */
	char *fsname;			/* file system name */

# if	defined(HASFSINO)
	ino_t fs_ino;			/* file system inode number */
# endif	/* defined(HASFSINO) */

	struct l_vfs *next;
};
extern struct l_vfs *Lvfs;


/*
 * Local mount information
 */

struct mounts {
	dev_t dev;              	/* st_dev */
	char *dir;              	/* directory */
	char *fsname;           	/* file system */
	ino_t inode;			/* st_ino */
	u_short mode;			/* st_mode */
	struct mounts *next;    	/* forward link */
	dev_t rdev;			/* st_rdev */
};


/*
 * Indexes for Nl[]
 */

#define X_AFS_FID	0
#define X_AFS_OPS	1
#define X_AFS_VOL	2
#define X_ALLPROC	3
#define X_FIFO_OPS	4
#define	X_MAXPROC	5
#define	X_NCACHE	6
#define	X_NCSIZE	7
#define X_NFS_OPS	8
#define X_SPEC_OPS	9
#define X_UFS_OPS	10
#define	X_LAST		11


/*
 * Search file information
 */

struct sfile {
	char *aname;			/* file name argument */
	char *name;			/* file name (after readlink()) */
	char *devnm;			/* device name (optional) */
	dev_t dev;			/* device */
	u_short mode;			/* S_IFMT mode bits from stat() */
	int type;			/* file type: 0 = file system
				 	 *	      1 = regular file */
	ino_t i;			/* inode number */
	int f;				/* file found flag */
	struct sfile *next;		/* forward link */
};


/*
 * Miscellaneous external definitions
 */

extern int Kmem;

#endif	/* LSOF_NEXT_H */
