/*
 * dnode.c - NEXTSTEP node functions for lsof
 */


/*
 * Copyright 1994 Purdue Research Foundation, West Lafayette, Indiana
 * 47907.  All rights reserved.
 *
 * Written by Victor A. Abell
 *
 * This software is not subject to any license of the American Telephone
 * and Telegraph Company or the Regents of the University of California.
 *
 * Permission is granted to anyone to use this software for any purpose on
 * any computer system, and to alter it and redistribute it freely, subject
 * to the following restrictions:
 *
 * 1. Neither the authors nor Purdue University are responsible for any
 *    consequences of the use of this software.
 *
 * 2. The origin of this software must not be misrepresented, either by
 *    explicit claim or by omission.  Credit to the authors and Purdue
 *    University must appear in documentation and sources.
 *
 * 3. Altered versions must be plainly marked as such, and must not be
 *    misrepresented as being the original software.
 *
 * 4. This notice may not be removed or altered.
 */

#ifndef lint
static char copyright[] =
"@(#) Copyright 1994 Purdue Research Foundation.\nAll rights reserved.\n";
static char *rcsid = "$Id: dnode.c,v 1.19 96/04/05 09:53:59 abe Exp $";
#endif


#include "lsof.h"


/*
 * process_node() - process vnode
 */

void
process_node(va)
	caddr_t va;			/* vnode kernel space address */
{
	dev_t dev;
	struct inode i;
	int ni = 0;
	struct rnode r;
	struct vnode rv;
	struct snode s;
	char *ty;
	enum vtype type;
	static struct vnode *v = (struct vnode *)NULL;
	struct l_vfs *vfs;

#if	defined(HAS_AFS)
	static int afs = 0;		/* AFS test status: -1 = no AFS
					 *		     0 = not tested
					 *		     1 = AFS present */
	struct afsnode an;
#endif	/* defined(HAS_AFS) */

/*
 * Read the vnode.
 */
	if ( ! va) {
		enter_nm("no vnode address");
		return;
	}
/*
 * Read the vnode.
 */
	if (!v) {

	/*
	 * Allocate space for the vnode or AFS vcache structure.
	 */

#if	defined(HAS_AFS)
		v = alloc_vcache();
#else	/* !defined(HAS_AFS) */
		v = (struct vnode *)malloc(sizeof(struct vnode));
#endif	/* defined(HAS_AFS) */

		if (!v) {
			(void) fprintf(stderr, "%s: can't allocate %s space\n",
				Pn,

#if	defined(HAS_AFS)
				"vcache"
#else	/* !defined(HAS_AFS) */
				"vnode"
#endif	/* defined(HAS_AFS) */

				);
			Exit(1);
		}
	}
	if (readvnode((caddr_t)va, v)) {
		enter_nm(Namech);
		return;
	}

# if	defined(HASNCACHE)
	Lf->na = (unsigned long)va;
# endif	/* defined(HASNCACHE) */

/*
 * Determine the vnode type.
 */
	if ((Nl[X_UFS_OPS].n_value &&
	    (unsigned long)v->v_op == Nl[X_UFS_OPS].n_value)
	||  (Nl[X_SPEC_OPS].n_value &&
	    (unsigned long)v->v_op == Nl[X_SPEC_OPS].n_value))
		Ntype = N_REGLR;
	else if (Nl[X_NFS_OPS].n_value
	&& (unsigned long)v->v_op == Nl[X_NFS_OPS].n_value)
		Ntype = N_NFS;
	else if (Nl[X_FIFO_OPS].n_value
	&& (unsigned long)v->v_op == Nl[X_FIFO_OPS].n_value)
		Ntype = N_FIFO;

#if	defined(HAS_AFS)
	/*
	 * Caution: this AFS test should be the last one.
	 */
	
	else if (Nl[X_AFS_OPS].n_value) {
		if ((unsigned long)v->v_op == Nl[X_AFS_OPS].n_value)
			Ntype = N_AFS;
		else {

unknown_v_op:
			(void) sprintf(Namech,
				"unknown file system type; v_op: %#x",
				v->v_op);
			enter_nm(Namech);
			return;
		}
	} else if (v->v_data || !v->v_vfsp)
		goto unknown_v_op;
	else {
		switch (afs) {
		case -1:
			goto unknown_v_op;
		case 0:
			if (!hasAFS(v)) {
				afs = -1;
				goto unknown_v_op;
			}
			afs = 1;
			Ntype = N_AFS;
			break;
		case 1:
			if (v->v_vfsp == AFSVfsp)
				Ntype = N_AFS;
			else
				goto unknown_v_op;
		}
	}
#else	/* !defined(HAS_AFS) */
	else {
		(void) sprintf(Namech, "unknown file system type; v_op: %#x",
			v->v_op);
		enter_nm(Namech);
		return;
	}
#endif	/* defined(HAS_AFS) */

/*
 * Determine the lock type.
 */
	if (v->v_shlockc || v->v_exlockc) {
		if (v->v_shlockc && v->v_exlockc)
			Lf->lock = 'u';
		else if (v->v_shlockc)
			Lf->lock = 'R';
		else
			Lf->lock = 'W';
	}

/*
 * Establish the local virtual file system structure.
 */
	if ((vfs = readvfs(v->v_vfsp)) == NULL) {
		(void) sprintf(Namech, "can't read vfs for %#x at %#x", va,
			v->v_vfsp);
		enter_nm(Namech);
		return;
	}
/*
 * Read the inode, rnode, snode, or vcache struct.
 */
	switch (Ntype) {

#if	defined(HAS_AFS)
	case N_AFS:
		if (readafsnode(va, v, &an))
			return;
		break;
#endif	/* defined(HAS_AFS) */

	case N_NFS:
		if (!v->v_data || readrnode((caddr_t)v->v_data, &r)) {
			(void) sprintf(Namech,
				"vnode at %#x: can't read rnode (%#x)",
				va, v->v_data);
			enter_nm(Namech);
			return;
		}
		break;
	case N_REGLR:
	default:

	/*
	 * VCHR and VFIFO vnodes point to an snode.  The snode's s_realvp
	 * usually points to a real vnode, which points to an inode.
	 */
		if (v->v_type == VCHR || v->v_type == VFIFO) {
			if (!v->v_data || readsnode(v->v_data, &s)) {
				(void) sprintf(Namech,
					"vnode at %#x: can't read snode(%#x)",
					va, v->v_data);
				enter_nm(Namech);
				return;
			}
			if (s.s_realvp) {
			    if (readvnode((caddr_t)s.s_realvp, &rv)) {
				(void) sprintf(Namech,
				    "snode at %#x: can't read real vnode (%#x)",
				    v->v_data, s.s_realvp);
				enter_nm(Namech);
				return;
			    }
			    if (!rv.v_data
			    ||  readinode((struct inode *)rv.v_data, &i)) {
				(void) sprintf(Namech,
					"snode at %#x: can't read inode (%#x)",
					v->v_data, rv.v_data);
				enter_nm(Namech);
				return;
			    }
			} else
				ni = 1;
			break;
		}
		if (!v->v_data || readinode((struct inode *)v->v_data, &i)) {
			(void) sprintf(Namech,
				"vnode at %#x: can't read inode (%#x)",
				va, v->v_data);
			enter_nm(Namech);
			return;
		}
	}
/*
 * Get device and type for printing.
 */
	switch (Ntype) {

#if	defined(HAS_AFS)
	case N_AFS:
		dev = an.dev;
		break;
#endif	/* defined(HAS_AFS) */

	case N_NFS:
		dev = r.r_attr.va_fsid;
		if (dev & 0x8000)
			dev |= 0xff00;
		break;
	case N_FIFO:
	case N_REGLR:
		dev = (v->v_type == VCHR || ni) ? v->v_rdev : i.i_dev;
	}
	type = v->v_type;
	if (vfs && vfs->dir == NULL) {
		(void) completevfs(vfs, &dev);

#if	defined(HAS_AFS)
		if (vfs->dir && Ntype == N_AFS && !AFSVfsp)
			AFSVfsp = v->v_vfsp;
#endif	/* defined(HAS_AFS) */

	}
/*
 * Obtain the inode number.
 */
	switch(Ntype) {

#if	defined(HAS_AFS)
	case N_AFS:
		if (an.ino_st) {
			Lf->inode = an.inode;
			Lf->inp_ty = 1;
		}
		break;
#endif	/* defined(HAS_AFS) */

	case N_NFS:
		Lf->inode = (unsigned long)r.r_attr.va_nodeid;
		Lf->inp_ty = 1;
		break;
	case N_FIFO:
	case N_REGLR:
		if (!ni) {
			Lf->inode = (unsigned long)i.i_number;
			Lf->inp_ty = 1;
		}
	}
/*
 * Obtain the file size.
 */
	if (Foffset)
		Lf->off_def = 1;
	else {
		switch (Ntype) {

#if	defined(HAS_AFS)
		case N_AFS:
			Lf->sz = an.size;
			Lf->sz_def = 1;
			break;
#endif	/* defined(HAS_AFS) */

		case N_NFS:
			Lf->sz = (unsigned long)r.r_attr.va_size;
			Lf->sz_def = 1;
			break;
		case N_FIFO:
			Lf->off_def = 1;
			break;
		case N_REGLR:
			if (type == VREG || type == VDIR) {
				if (!ni) {
					Lf->sz = (unsigned long)i.i_size;
					Lf->sz_def = 1;
				}
			}
			else if (type == VCHR && !Fsize)
				Lf->off_def = 1;
			break;
		}
	}
/*
 * Record an NFS file selection.
 */
	if (Ntype == N_NFS && Fnfs)
		Lf->sf |= SELNFS;
/*
 * Save the file system names.
 */
	if (vfs) {
		Lf->fsdir = vfs->dir;
		Lf->fsdev = vfs->fsname;

#if	defined(HASFSINO)
		Lf->fs_ino = vfs->fs_ino;
#endif	/* defined(HASFSINO) */

	}
/*
 * Format the vnode type.
 */
	switch (type) {

	case VNON:
		ty ="VNON";
		break;
	case VREG:
	case VDIR:
		ty = (type == VREG) ? "VREG" : "VDIR";
		Lf->dev_def = 1;
		Lf->dev = dev;
		break;
	case VBLK:
		ty = "VBLK";
		break;
	case VCHR:
		Lf->dev = dev;
		Lf->dev_def = Lf->is_chr_dev = 1;
		ty = "VCHR";
		break;
	case VLNK:
		ty = "VLNK";
		break;

#if	defined(VSOCK)
	case VSOCK:
		ty = "SOCK";
		break;
#endif

	case VBAD:
		ty = "VBAD";
		break;
	case VFIFO:
		Lf->dev = dev;
		Lf->dev_def = 1;
		ty = "FIFO";
		break;
	default:
		if (type > 9999)
			(void) sprintf(Lf->type, "*%03d", type % 1000);
		else
			(void) sprintf(Lf->type, "%4d", type);
		(void) strcpy(Namech, "unknown type");
		ty = NULL;
	}
	if (ty)
		(void) strcpy(Lf->type, ty);
/*
 * If this is a VCHR file and it's missing an inode number, try to
 * supply one.
 */
	if (Lf->inp_ty == 0 && type == VCHR && Lf->dev_def)
		find_ch_ino();
/*
 * Test for specified file.
 */
	if (Sfile && is_file_named(NULL, type))
		Lf->sf |= SELNM;
/*
 * Enter name characters.
 */
	if (Namech[0])
		enter_nm(Namech);
}
