/***************************************************************/
/*                                                             */
/*  VERSION.H                                                  */
/*                                                             */
/*  What version of remind do we have?                         */
/*                                                             */
/*  This file is part of REMIND.                               */
/*  Copyright (C) 1992-1997 by David F. Skoll                  */
/*                                                             */
/***************************************************************/

/* $Id: version.h,v 1.5 1997/01/16 04:14:34 dfs Exp $ */
#define VERSION "03.00.16"
