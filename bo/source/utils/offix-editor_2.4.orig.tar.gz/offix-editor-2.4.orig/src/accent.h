#ifndef ACCENTh
#define ACCENTh

void isoAccent(Widget,XEvent*,String*,Cardinal*);

#endif
