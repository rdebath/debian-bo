#include <errno.h>
#ifndef errno
extern int errno;
#endif
