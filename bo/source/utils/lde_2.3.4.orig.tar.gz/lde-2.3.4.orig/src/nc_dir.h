/*
 *  lde/nc_dir.h -- The Linux Disk Editor
 *
 *  Copyright (C) 1994  Scott D. Heavner
 *
 *  $Id: nc_dir.h,v 1.2 1996/10/13 00:41:32 sdh Exp $
 */

int directory_popup(unsigned long bnr, unsigned long inr, unsigned long ipointer);
