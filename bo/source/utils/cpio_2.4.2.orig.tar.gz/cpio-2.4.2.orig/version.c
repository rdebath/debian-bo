/* The version number of cpio and mt.  */
char *version_string = "version 2.4.2\n";
