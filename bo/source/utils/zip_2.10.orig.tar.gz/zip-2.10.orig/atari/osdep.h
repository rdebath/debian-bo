#define FOPR "rb"
#define FOPM "r+b"
#define FOPW "wb"

#define DIRENT
#define NO_TERMIO

#include <sys/types.h>
#include <sys/stat.h>
