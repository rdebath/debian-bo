#:OTHER:
#PACKAGE#	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/#PACKAGE#
