text Apps/Misc #PACKAGE# none "#PACKAGE# Description" /usr/bin/#PACKAGE#
