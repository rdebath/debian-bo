#define VERSION	"2.4.2"
#define DATE	"21 Jan 1996"

/*
 * Version 1.68		        1985		Mark Brukhartz
 * Version 2.3	        	25 Sep 91	comp.sources.misc
 * Version 2.3-dpg-3      	07 Mar 93	Dave Gymer
 * Version 2.3-dpg-4      	14 Mar 93	Andrew Stevens
 * Version 2.3.5 (for Linux)    11 Dec 93       Koen Holtman
 * Version 2.3.6 (for Linux)    31 Dec 93       Koen Holtman
 * Version 2.3.6-dpg-1   "      12 Jan 94       Dave Gymer
 * Version 2.3.7                11 Mar 94       Koen Holtman
 * Version 2.4                  26 Nov 94       Anders Baekgaard, Koen Holtman
 * Version 2.4.1                08 Feb 95       Koen Holtman
 * Version 2.4.2                21 Jan 96       Koen Holtman
 */
