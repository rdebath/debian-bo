#ifndef __LEARN_H
#define __LEARN_H

void learn_keys (void);

#endif
