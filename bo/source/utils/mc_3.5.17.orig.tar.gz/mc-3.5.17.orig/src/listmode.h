#ifndef __LISTMODE_H
#define __LISTMODE_H

char *listmode_edit (char*);

#endif
