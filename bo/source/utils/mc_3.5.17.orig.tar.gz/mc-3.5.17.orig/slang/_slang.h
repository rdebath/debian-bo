extern char *SLtt_Graphics_Char_Pairs;
#define MAX_INPUT_BUFFER_LEN 1024

