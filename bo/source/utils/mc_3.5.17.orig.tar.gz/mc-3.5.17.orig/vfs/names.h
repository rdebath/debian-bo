int finduid (char *name);
void finduname (char *name, int uid);
int findgid (char *name);
void findgname (char *name, int gid);
