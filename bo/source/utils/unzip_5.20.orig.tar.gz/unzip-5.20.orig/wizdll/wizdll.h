#ifndef _WIZDLL_H
#define _WIZDLL_H

#define DLL_MAJOR 1
#define DLL_MINOR 0

#endif /* _WIZDLL_H */

