/*
	version.h	Version number header.
	Copyright (c) 1996 by Christopher S L Heng. All rights reserved.

	$Id: version.h 1.4 1996/06/22 20:53:07 chris Exp $
*/

#if !defined(VERSION_H_INCLUDED)
#define	VERSION_H_INCLUDED

/* macros */
#define	VERSN_MAJOR	1
#define	VERSN_MINOR	0

#define	VERSN_PROGNAME	"tofrodos"

#endif
