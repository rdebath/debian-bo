(-Zl diskapi.c {diskacc.h})
diskint.asm
diskapi.lib
-as -ll
