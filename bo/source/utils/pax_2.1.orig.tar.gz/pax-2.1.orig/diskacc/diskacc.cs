(-Au diskacc.c {diskacc.h})
diskacc.dll
diskacc.def
llibcdll.lib
doscalls.lib
-al -lp -x
