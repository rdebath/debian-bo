(-W1 -DDISKACC
append.c   buffer.c   cpio.c     create.c   extract.c  fileio.c     
link.c     list.c     mem.c      ms_dio.c   namelist.c names.c      
pass.c     pathname.c pax.c      port.c     regexp.c   replace.c    
tar.c      ttyio.c    warn.c     wildmat.c  ms_wild.c  ms_dir.c   ms_dt.c
)
setargv.obj
diskacc.lib
diskapi.lib!
pax.exe
pax.def
-AC -LB -S0x4000
