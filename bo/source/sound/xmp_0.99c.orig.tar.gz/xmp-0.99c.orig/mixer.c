/* mixer.c - software mixer functions
 *
 * $Id$
 *
 * $Log$
 */

#include "xmp.h"


struct pch_info {
    int period;
    int index;
    int sample;
    int volume;
};



