/* Security functions */
void initsecurity(void);

void needroot(void);
void dontneedroot(void);
void neverneedroot(void);

void needgroup(void);
void dontneedgroup(void);
void neverneedgroup(void);
