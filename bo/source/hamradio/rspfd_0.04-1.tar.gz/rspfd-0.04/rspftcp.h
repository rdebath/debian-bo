/*
 * TCP functions 
 */
 
int init_tcp(int port);
int do_tcp(FILE *skt_stream, char *inbuf);
 
