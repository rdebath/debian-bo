/*
** Copyright (C) 1994, Enterprise Integration Technologies Corp.        
** All Rights Reserved.
** Kevin Hughes, kevinh@eit.com 
** 7/14/94
*/

void convtoshortdate();
void splitshortdate();
long getyearsecs();
int convtoyearsecs();
char *getlocaltime();
void gettimezone();
void getthisyear();
