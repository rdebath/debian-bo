#define STANDALONE
#include "init.c"
