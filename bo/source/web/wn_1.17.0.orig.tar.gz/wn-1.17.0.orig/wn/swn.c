#define STANDALONE
#include "wn.c"
