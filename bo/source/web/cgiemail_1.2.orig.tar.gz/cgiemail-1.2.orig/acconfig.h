/* Define if you want to enable use of environment variables.  */
#undef ENABLE_CGIENV
