/*                  /Net/dxcern/userd/timbl/hypertext/WWW/Library/Implementation/HTPlain.html
                                    PLAIN TEXT OBJECT
                                             
   What a small file!
   
 */

#ifndef HTPLAIN_H
#define HTPLAIN_H

#include "HTFormat.h"

#ifndef pyramid
extern HTConverter HTPlainPresent;
#endif

#endif
/*

   End of definition module.  */
