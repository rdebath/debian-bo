#ifndef _TOOLS_H_
#define _TOOLS_H_

extern void *GetPointer(unsigned char **);
extern void PutPointer(unsigned char **, void *);

#endif /* _TOOLS_H_ */
