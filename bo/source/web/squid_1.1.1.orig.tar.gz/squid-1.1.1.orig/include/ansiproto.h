#ifndef _PARAMS
#if HAVE_ANSI_PROTOTYPES
#define _PARAMS(ARGS) ARGS
#else /* Traditional C */
#define _PARAMS(ARGS) ()
#endif /* __STDC__ */
#endif /* _PARAMS */
