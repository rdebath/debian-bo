/* $Id: version.h,v 1.69 1996/12/14 18:53:03 wessels Exp $
 *
 *  SQUID_VERSION - String for version id of this distribution
 */
#ifndef SQUID_VERSION
#define SQUID_VERSION	"1.1.1"
#endif

#ifndef SQUID_RELEASE_TIME
#define SQUID_RELEASE_TIME 850693063
#endif
