
#ifndef LYRCFILE_H
#define LYRCFILE_H

#ifndef LYSTRUCTS_H
#include "LYStructs.h"
#endif /* LYSTRUCTS_H */

extern void read_rc NOPARAMS;
extern int save_rc NOPARAMS;

#endif /* LYRCFILE_H */

