
#ifndef LYCGI_H
#define LYCGI_H

extern void add_lynxcgi_environment PARAMS((CONST char *variable_name));

#endif /* LYGETFILE_H */
