#ifndef _DAVIS_LINE_H_
#define _DAVIS_LINE_H_
extern int most_analyse_line(unsigned char *, unsigned char *, char *, char *);
extern void most_output(unsigned char *, int, unsigned char *, unsigned char);
extern void most_display_line(void);
extern int most_apparant_distance(unsigned char *);
#endif

