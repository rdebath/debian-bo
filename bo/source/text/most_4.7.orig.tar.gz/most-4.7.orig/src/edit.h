extern void most_edit_cmd (void);
