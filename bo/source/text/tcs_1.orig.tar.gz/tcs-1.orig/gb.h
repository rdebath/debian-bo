/*
	gb ranges from a1a1 to f7fe inclusive
	we use a kuten-like mapping the above range to 101-8794
*/
#define		GBMAX	8795

extern long tabgb[GBMAX];	/* runes indexed by gb ordinal */
