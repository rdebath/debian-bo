#define		KUTEN212MAX	7768

extern long tabkuten212[KUTEN212MAX];	/* runes indexed by kuten */
