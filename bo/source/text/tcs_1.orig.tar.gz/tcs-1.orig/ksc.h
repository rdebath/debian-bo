extern long tabksc5601[];	/* runes indexed by kuten */
extern int ksc5601max;		/* # of entries in the table. */
