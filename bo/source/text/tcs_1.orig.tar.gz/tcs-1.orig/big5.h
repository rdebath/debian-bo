#define		BIG5MAX	13973
#define		BIG5FONT 157

extern long tabbig5[BIG5MAX];	/* runes indexed by big5 ordinal */
