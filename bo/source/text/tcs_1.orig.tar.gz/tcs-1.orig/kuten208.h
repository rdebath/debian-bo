#define		KUTEN208MAX	8407

extern long tabkuten208[KUTEN208MAX];	/* runes indexed by kuten */
