char version[] = "Sun Mar 26 02:42:25 EST 1995";
