extern int strcasecmp(
#if NeedFunctionPrototypes
    const char*,
    const char*
#endif
);  

extern int strncasecmp(
#if NeedFunctionPrototypes
    const char*,
    const char*,
    size_t
#endif
);  
