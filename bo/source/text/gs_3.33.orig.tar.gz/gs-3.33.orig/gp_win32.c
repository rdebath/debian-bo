/* Copyright (C) 1992, 1993, 1994 Aladdin Enterprises.  All rights reserved.
  
  This file is part of GNU Ghostscript.
  
  GNU Ghostscript is distributed in the hope that it will be useful, but
  WITHOUT ANY WARRANTY.  No author or distributor accepts responsibility to
  anyone for the consequences of using it or for whether it serves any
  particular purpose or works at all, unless he says so in writing.  Refer
  to the GNU Ghostscript General Public License for full details.
  
*/

/* gp_win32.c */
/* Common platform-specific routines for MS-Windows WIN32 */
/* hacked from gp_msdos.c by Russell Lang */
#include "stdio_.h"
#include "string_.h"		/* for strerror */
#include "dos_.h"
#include "gstypes.h"
#include "gsmemory.h"		/* for gp.h */
#include "gp.h"
#include "windows_.h"

/* ------ Miscellaneous ------ */

/* Get the string corresponding to an OS error number. */
/* This is compiler-, not OS-, specific, but it is ANSI-standard and */
/* all MS-DOS and MS Windows compilers support it. */
const char *
gp_strerror(int errnum)
{	return strerror(errnum);
}

/* ------ Date and time ------ */

/* Read the current date (in days since Jan. 1, 1980) */
/* and time (in milliseconds since midnight). */
void
gp_get_clock(long *pdt)
{
SYSTEMTIME st;
long idate;
static const int mstart[12] =
   { 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 };
	/* This gets UTC, not local time */
	/* We have no way of knowing the time zone correction */
	GetSystemTime(&st);
	/* following calculation is correct until 2100 */
	idate = (st.wYear - 1980) * 365 +	/* days per year */
		(st.wYear - 1980) / 4 + 1 +	/* account for leap years */
		mstart[st.wMonth - 1] +		/* month is 1-origin */
		st.wDay - 1;			/* day of month is 1-origin */
	if ( st.wMonth <= 2 && st.wYear % 4 == 0 ) /* Jan. or Feb. of leap year */
		idate--;
	pdt[0] = idate;	/* # days */
	pdt[1] =
		(st.wHour * 60 + st.wMinute ) * 60000L +
		st.wSecond * 1000 + st.wMilliseconds;
}

/* ------ Console management ------ */

/* Answer whether a given file is the console (input or output). */
/* This is not a standard gp procedure, */
/* but the MS Windows configuration needs it, */
/* and other MS-DOS configurations might need it someday. */
int
gp_file_is_console(FILE *f)
{
#ifdef __DLL__
	if ( f == NULL )
		return 1;
#else
	if ( f == NULL )
		return 0;
#endif
	if (fileno(f) <= 2)
		return 1;
	return 0;
}

/* ------ Screen management ------ */

/* Get the environment variable that specifies the display to use. */
const char *
gp_getenv_display(void)
{	return NULL;
}

/* ------ File names ------ */

/* Define the default scratch file name prefix. */
const char gp_scratch_file_name_prefix[] = "_temp_";

/* Define the name of the null output file. */
const char gp_null_file_name[] = "nul";

/* Define the name that designates the current directory. */
const char gp_current_directory_name[] = ".";
