/* define if ditroff works as expected */
#undef DITROFF_WORKS

/* define if zcat is really gzip */
#undef ZCAT_IS_GZIP
