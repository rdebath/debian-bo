text Apps/Misc sgml-data none "sgml-data Description" /usr/bin/sgml-data
