/*
 * File:	actions.h
 * Purpose:	Declare thins for action functions.
 * Author:	Lars Wirzenius
 * Version:	"@(#)SeX:$Id: actions.h,v 1.1.1.1 1995/12/29 11:56:39 liw Exp $"
 */

#ifndef actions_h
#define actions_h

#include <X11/Intrinsic.h>

int action_add(XtAppContext *);

#endif
