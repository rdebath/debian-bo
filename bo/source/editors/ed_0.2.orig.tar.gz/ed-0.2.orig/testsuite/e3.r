E !echo hello world-
