#define VERSION aXe 6.1.2
#define QVERSION "aXe 6.1.2"
