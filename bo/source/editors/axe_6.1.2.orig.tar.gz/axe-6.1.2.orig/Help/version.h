#define VERSION axinfo 1.0
#define QVERSION "axinfo 1.0"
