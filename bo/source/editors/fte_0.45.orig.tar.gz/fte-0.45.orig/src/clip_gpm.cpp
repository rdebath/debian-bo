/*    clip_gpm.cpp
 *
 *    Copyright (c) 1994-1996, Marko Macek
 *
 *    You may distribute under the terms of either the GNU General Public
 *    License or the Artistic License, as specified in the README file.
 *
 */

#include "fte.h"

int GetPMClip() {
    return 0;
}

int PutPMClip() {
    return 0;
}
