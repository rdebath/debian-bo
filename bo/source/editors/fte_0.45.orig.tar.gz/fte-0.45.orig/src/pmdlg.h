#define IDD_PROMPT      300
#define IDS_PROMPT      301
#define IDE_FIELD       302

#define IDD_FINDREPLACE   201
#define IDD_FIND          202

#define IDL_FIND          211
#define IDL_REPLACE       212

#define IDE_FIND          221
#define IDE_REPLACE       222

#define IDC_IGNORECASE    231
#define IDC_REGEXPS       232
#define IDC_WORDS         233
#define IDC_BLOCK         234
#define IDC_GLOBAL        235
#define IDC_REVERSE       236
#define IDC_ALLOCCURENCES 237
#define IDC_NOPROMPTING   238
#define IDC_JOINLINE      239
#define IDC_DELETELINE    240

#define IDD_FILEDLG       500

