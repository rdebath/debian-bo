#ifndef __FTEVER_H
#define __FTEVER_H

#define PROG_FTE   "fte"
#define PROG_CFTE  "cfte"
#define PROGRAM    PROG_FTE
#define VERSION    "0.45"
#define VERNUM     0x0450L
#define COPYRIGHT  "Copyright (c) 1994-1996 Marko Macek"

#endif
