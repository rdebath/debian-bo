/*
** $Id: parse.h,v 1.1 1996/04/17 14:03:22 martin Exp $
**
** $Log: parse.h,v $
** Revision 1.1  1996/04/17 14:03:22  martin
** Initial revision
**
*/

#ifndef __parse_h

extern void print_entry(char format_p[], char *entry[], int field_c);

#endif /* __parse_h */
