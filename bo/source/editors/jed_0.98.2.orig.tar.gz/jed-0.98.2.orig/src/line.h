/*
 *  Copyright (c) 1992, 1995 John E. Davis  (davis@space.mit.edu)
 *  All Rights Reserved.
 */
extern void swap_lines(void);
extern int split_line(void);
extern void splice_line(void);
