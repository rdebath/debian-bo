extern SLang_Name_Type JedLine_Intrinsics[];
extern void jed_skip_hidden_lines_backward (int *);
extern void jed_skip_hidden_lines_forward (int *);
