extern void use_abbrev_table (char *);
extern void define_abbrev (char *, char *, char *);
extern void create_abbrev_table (char *, char *);
extern int expand_abbrev (unsigned char);
extern int abbrev_table_p (char *);
extern void dump_abbrev_table (char *);
extern void what_abbrev_table (void);
extern int list_abbrev_tables (void);
extern void delete_abbrev_table (char *);


