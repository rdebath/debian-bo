#define	VI_VERSION \
	"Version 1.76 (9/15/96) The CSRG, University of California, Berkeley."
