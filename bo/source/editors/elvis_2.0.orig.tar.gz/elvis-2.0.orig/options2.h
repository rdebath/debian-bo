/* options2.h */

BEGIN_EXTERNC
extern void optsave P_((BUFFER custom));
END_EXTERNC
