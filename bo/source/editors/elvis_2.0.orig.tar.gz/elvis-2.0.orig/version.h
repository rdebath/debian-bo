/* version.h */
/* Copyright 1996 by Steve Kirkendall */


#define VERSION	"2.0"
#define COPY1 "Copyright (c) 1996 by Steve Kirkendall"
#define	COPY2 "Permission is granted to redistribute the source or binaries,"
#define COPY3 "as long as the copyright notice remains intact.  This program"
#define COPY4 "is offered with no warranty, to the extent permitted by law."
