#define p3_width 4
#define p3_height 4
static char p3_bits[] = {
   0x08, 0x04, 0x02, 0x01};
