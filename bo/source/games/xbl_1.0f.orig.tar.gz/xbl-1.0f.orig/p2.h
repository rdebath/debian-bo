#define p2_width 4
#define p2_height 4
static char p2_bits[] = {
   0xfe, 0xfb, 0xfd, 0xf7};
