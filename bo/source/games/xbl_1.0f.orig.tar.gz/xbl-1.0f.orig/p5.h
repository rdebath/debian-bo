#define p5_width 4
#define p5_height 4
static char p5_bits[] = {
   0x01, 0x02, 0x04, 0x08};
