#define p4_width 4
#define p4_height 4
static char p4_bits[] = {
   0x03, 0x06, 0x0c, 0x08};
