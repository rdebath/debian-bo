#define p1_width 4
#define p1_height 4
static char p1_bits[] = {
   0x01, 0x04, 0x02, 0x08};
