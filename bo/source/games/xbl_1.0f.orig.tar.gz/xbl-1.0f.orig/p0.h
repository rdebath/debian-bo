#define p0_width 4
#define p0_height 4
static char p0_bits[] = {
   0x0a, 0x05, 0x0a, 0x05};
