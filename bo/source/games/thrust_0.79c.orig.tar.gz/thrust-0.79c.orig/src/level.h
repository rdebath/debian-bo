
/* Written by Peter Ekberg, peda@lysator.liu.se */

#ifndef LEVEL_H
#define LEVEL_H

#ifdef __STDC__
int matchsliders(void);
int ismajorbutton(int tag);
void releasebana(void);
int readbana(char **ptr);
#endif

#endif /* LEVEL_H */
