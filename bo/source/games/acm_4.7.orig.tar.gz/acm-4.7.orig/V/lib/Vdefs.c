#include <Vlib.h>

VPoint	_VUnitVectorI = { 1.0, 0.0, 0.0 };
VPoint	_VUnitVectorJ = { 0.0, 1.0, 0.0 };
VPoint	_VUnitVectorK = { 0.0, 0.0, 1.0 };

VWorkContext _v_default_work_context;
VWorkContext *_VDefaultWorkContext = &_v_default_work_context;
