/*
 *	xtrojka (c) 1994,1995,1996 Maarten Los
 *
 *	#include "COPYRIGHT"	
 *
 *	created:	12.iii.1996
 *	modified:
 *
 *
 */

#ifndef _options_h_
#define _options_h_

/*
 *	function prototypes
 */
void get_options(int, char**);


#endif /* _options_h_ */
