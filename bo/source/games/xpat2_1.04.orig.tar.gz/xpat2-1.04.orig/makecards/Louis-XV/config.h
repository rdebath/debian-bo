/* configuration for the american cards */

#define NUM_RED_COLORS	 8	/* number not counting background */
#define NUM_BLACK_COLORS 8	/* number not counting background */

#define RED_COLOR	{ 65535L * 4L / 5L, 0L, 0L }	/* red is 80% */
#define BLACK_COLOR	{ 0L, 0L, 0L }
#define WHITE_COLOR	{ 65535L, 65535L, 0xb400L }	/* background is yellow */
