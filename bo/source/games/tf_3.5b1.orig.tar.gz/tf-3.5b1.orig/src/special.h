/*************************************************************************
 *  TinyFugue - programmable mud client
 *  Copyright (C) 1993, 1994 Ken Keys
 *
 *  TinyFugue (aka "tf") is protected under the terms of the GNU
 *  General Public License.  See the file "COPYING" for details.
 ************************************************************************/
/* $Id: special.h,v 33000.2 1994/04/20 00:31:31 hawkeye Exp $ */

#ifndef SPECIAL_H
#define SPECIAL_H

extern void FDECL(special_hook,(Aline *aline));

#endif /* SPECIAL_H */
