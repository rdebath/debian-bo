
// Functions from make.cc
extern	void	MakeLargeRock(int x, int y);
extern	void	MakeSteelRoid(int x, int y);
extern	void	MakeMultiplier(void);
extern	void	MakeBonus(void);
extern	void	MakePrize(void);
extern	void	MakeHoming(void);
extern	void	MakeGravity(void);
extern	void	MakeNova(void);
extern	void	MakeDamagedShip(void);
extern	void	MakeEnemy(void);

