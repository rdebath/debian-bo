// Functions from blit.cc
extern	void	CompositeFrame(void);
extern	void	BlastFrame(void);
extern	void	KillSprite(int which);

