#!/usr/bin/perl
#

while (<>) {
    print $_;
}
