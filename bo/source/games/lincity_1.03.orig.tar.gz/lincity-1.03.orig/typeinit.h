// typeinit.h   part of cim-sity
// Copyright (c) I J Peters 1995-1997.  Please read the file 'COPYRIGHT'.

extern struct TYPE main_types[];
extern char type_string[][MAPPOINT_STATS_W/8];
extern int fire_chance[];
extern char graphic_path[];

