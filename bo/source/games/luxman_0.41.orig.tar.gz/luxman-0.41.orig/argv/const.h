/* const.h.  Generated automatically by configure.  */
/*
 * small test for const availability
 *
 * Copyright 1993 by the Antaire Corporation
 *
 * This file is part of the argv library.
 *
 * $Id: const.h.in,v 1.2 1994/02/18 03:18:53 gray Exp $
 */

/*
 * this is designed to be inserted into argv.h to define const
 * to be const/nothing for ansi/non-ansi systems.
 */
#define const	const
#endif /* ! const : from argv.h.1 */
