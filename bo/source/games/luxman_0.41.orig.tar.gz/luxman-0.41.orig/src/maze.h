#ifndef _maze_h_
#define _maze_h_

#include <gtools/bitmap.h>

struct Maze : public Bitmap {

  Maze( char *filename );
  
};

#endif
