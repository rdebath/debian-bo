#define VERSION "7.1.0 (Apr 1996)"

#define COPYRIGHT "Copyright 1986-1996 Stanley T. Shebs"
