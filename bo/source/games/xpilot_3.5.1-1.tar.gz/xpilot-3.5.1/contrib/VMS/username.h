void getusername(char *uname);

