#include"e0.h"
  
E0::E0() {
 
consfn();
pix(&pixmap,e0_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}

