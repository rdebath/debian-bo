#include"gbonpnt.h"
  
G_BonusPoint::G_BonusPoint() {
 
consfn();
pix(&pixmap,bonuspoint_bits,Colour::BONUSPOINTCOLOUR,Colour::MYBACKGROUND);

};



