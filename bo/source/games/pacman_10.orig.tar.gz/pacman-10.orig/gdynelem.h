#ifndef __gdynelem_h_ 
 #define __gdynelem_h_
 #include"graphele.h"

class DynamicGraphElement : public GraphElement {

public:
  virtual GID_TYPE getgid();	//return the graphical id      

};

#endif

