#ifndef __corner2_h_ 
#define __corner2_h_
#include"corner.h"

class Corner2 : public Corner {
         
public:         
         
Corner2();
           
};

#endif   
