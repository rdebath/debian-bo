#ifndef __gbonus_h_ 
#define __gbonus_h_
 #include"gunmovel.h"

class G_Bonus : public G_UnmoveableElement {
            
public: 


            
};

#endif 
