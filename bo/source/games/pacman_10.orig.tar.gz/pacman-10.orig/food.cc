#include"food.h"
  
Food::Food() {
}

