#ifndef __staticel_h_ 
#define __staticel_h_
#include"element.h"

class StaticElement : public Element {
            
public:            


    
};

#endif
