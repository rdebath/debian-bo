#define XWIN
//#define MSWIN
//#define VTX
#ifdef VTX 
#define UNIX
#endif
#ifdef XWIN
#define UNIX
#endif
#define RAISE
#define XPOSSE
//#define DOUBLE
