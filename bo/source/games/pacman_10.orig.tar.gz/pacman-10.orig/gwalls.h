#ifndef __gwalls_h_ 
#define __gwalls_h_
#include"gstatele.h"

class G_Walls : public StaticGraphElement {

};

#endif   
