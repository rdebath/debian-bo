#ifndef __gblank_h_ 
#define __gblank_h_
#include"gstatele.h"

class G_Blank : public StaticGraphElement {
         
public:         

G_Blank();

};

#endif   
