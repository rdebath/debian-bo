#ifndef __vertwall_h_ 
#define __vertwall_h_
#include"strawall.h"

class VerticalWall : public StraightWall {
         
public:         
         
VerticalWall();

};

#endif   
