#ifndef __gedible_h_ 
 #define __gedible_h_
 #include"gstatele.h"

class G_Edible : public StaticGraphElement {
  
public:  
 
};

#endif 
