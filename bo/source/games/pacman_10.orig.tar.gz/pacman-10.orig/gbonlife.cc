#include"gbonlife.h"
  
G_BonusLife::G_BonusLife() {
 
consfn();
pix(&pixmap,bonuslife_bits,Colour::BONUSLIFECOLOUR,Colour::MYBACKGROUND);

};

