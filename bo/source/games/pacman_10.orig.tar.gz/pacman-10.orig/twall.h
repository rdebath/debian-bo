#ifndef __twall_h_ 
#define __twall_h_
#include"gwalls.h"

class T_Wall : public G_Walls {
         
public:         
         
void draw(void);

};

#endif   
