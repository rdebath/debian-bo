#ifndef __t270_h_ 
#define __t270_h_
#include"twall.h"

class T270 : public T_Wall {
         
public:         
         
T270();

};

#endif   
