#ifndef __e90_h_ 
#define __e90_h_
#include"endwall.h"

class E90 : public EndWall {
         
public:         
         
E90();

};

#endif   
