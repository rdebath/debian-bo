#include"t90.h"
  
T90::T90() {
 
consfn();
pix(&pixmap,t90_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
}


