#ifndef __specwall_h_ 
#define __specwall_h_
#include"staticel.h"

class SpecialWall : public StaticElement {
         
public:         
         
SpecialWall();
typ is_a(void) {return classSpecialWall;}             
};

#endif   
