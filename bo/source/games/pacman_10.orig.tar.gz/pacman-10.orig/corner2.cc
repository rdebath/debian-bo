#include"corner2.h"
  
Corner2::Corner2() {
 
consfn();
pix(&pixmap,corner2_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
};

