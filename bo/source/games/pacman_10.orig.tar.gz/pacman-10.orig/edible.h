#ifndef __edible_h_ 
 #define __edible_h_
 #include"staticel.h"

class Edible : public StaticElement {
  
public:  
 
};

#endif 
