#include"corner1.h"
  
Corner1::Corner1() {
 
consfn();
pix(&pixmap,corner1_bits,Colour::WALLCOLOUR,Colour::MYBACKGROUND);
};

