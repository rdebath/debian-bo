#ifndef __gspecwal_h_ 
#define __gspecwal_h_
#include"gstatele.h"

class G_SpecialWall : public StaticGraphElement {
         
public:         
         
G_SpecialWall();
             
};

#endif   
