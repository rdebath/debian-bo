#ifndef __gbonpnt_h_ 
 #define __gbonpnt_h_ 
 #include"gbonus.h"

class G_BonusPoint : public G_Bonus {
   
public:

G_BonusPoint();
   
};

#endif
