/*
**
**	X11 Jewel By David Cooper and Jose Guterman 05/92
**
*/


typedef unsigned long Pixel;
typedef void (*FCN_PTR) ();

#define FALSE	0
#define TRUE	1
typedef int BOOL;

#define NUM_ROWS	14
#define NUM_COLS	6
#define BLOCK_SIZE	3

#ifndef NULL
#define NULL 0
#endif

