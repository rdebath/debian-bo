/*
**
**	X11 Jewel By David Cooper and Jose Guterman 05/92
**
*/

/* functions provided by hscore */
extern void Init_Draw_High_Scores();
extern void Draw_One_High_Score(/*i*/);
extern void Show_High_Scores();
extern void Wipeout_Last_High_Score();
extern void Move_Down_High_Scores(/*number*/);
extern void Set_State_High_Score();


