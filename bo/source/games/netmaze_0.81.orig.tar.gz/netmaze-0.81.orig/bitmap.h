/*
 * Bitmaps for Mono/Grey-Mode
 */

#include "bitmaps/player0.xbm"
#include "bitmaps/player1.xbm"
#include "bitmaps/player2.xbm"
#include "bitmaps/player3.xbm"
#include "bitmaps/player4.xbm"
#include "bitmaps/player5.xbm"
#include "bitmaps/player6.xbm"
#include "bitmaps/player7.xbm"
#include "bitmaps/player8.xbm"
#include "bitmaps/player9.xbm"
#include "bitmaps/player10.xbm"
#include "bitmaps/player11.xbm"
#include "bitmaps/player12.xbm"
#include "bitmaps/player13.xbm"
#include "bitmaps/player14.xbm"
#include "bitmaps/player15.xbm"
#include "bitmaps/player16.xbm"
#include "bitmaps/player17.xbm"
#include "bitmaps/player18.xbm"
#include "bitmaps/player19.xbm"
#include "bitmaps/player20.xbm"
#include "bitmaps/hwall.xbm"
#include "bitmaps/vwall.xbm"
#include "bitmaps/bgtop.xbm"
#include "bitmaps/bgbottom.xbm"


char *player_bits[] = { player0_bits ,player1_bits ,player2_bits ,player3_bits
                       ,player4_bits ,player5_bits ,player6_bits ,player7_bits
                       ,player8_bits ,player9_bits ,player10_bits
                       ,player11_bits ,player12_bits ,player13_bits
                       ,player14_bits ,player15_bits ,player16_bits
                       ,player17_bits ,player18_bits ,player19_bits
                       ,player20_bits ,NULL };




