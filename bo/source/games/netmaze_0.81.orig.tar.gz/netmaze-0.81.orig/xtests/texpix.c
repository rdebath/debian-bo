#define WRITEPIX ia1 -= XSIZE; *ia1 = pixval1; *ia2 = pixval2; ia2 += XSIZE;
        switch(*jmpt++ + ln)
        {
          case 0x1f: WRITEPIX
          case 0x1e: WRITEPIX
          case 0x1d: WRITEPIX
          case 0x1c: WRITEPIX
          case 0x1b: WRITEPIX
          case 0x1a: WRITEPIX
          case 0x19: WRITEPIX
          case 0x18: WRITEPIX
          case 0x17: WRITEPIX
          case 0x16: WRITEPIX
          case 0x15: WRITEPIX
          case 0x14: WRITEPIX
          case 0x13: WRITEPIX
          case 0x12: WRITEPIX
          case 0x11: WRITEPIX
          case 0x10: WRITEPIX
          case 0xf: WRITEPIX
          case 0xe: WRITEPIX
          case 0xd: WRITEPIX
          case 0xc: WRITEPIX
          case 0xb: WRITEPIX
          case 0xa: WRITEPIX
          case 0x9: WRITEPIX
          case 0x8: WRITEPIX
          case 0x7: WRITEPIX
          case 0x6: WRITEPIX
          case 0x5: WRITEPIX
          case 0x4: WRITEPIX
          case 0x3: WRITEPIX
          case 0x2: WRITEPIX
          case 0x1: WRITEPIX
        }

