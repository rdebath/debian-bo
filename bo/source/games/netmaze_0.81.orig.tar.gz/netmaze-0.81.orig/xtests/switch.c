#define A i++;

void main(int argc,char **argv)
{
  int c = atoi(argv[1]);
  int i=0;

  switch(c)
  {
    case 16:
      A
    case 15:
      A
    case 14:
      A
    case 13:
      A
    case 12:
      A
    case 11:
      A
    case 10:
      A
    case 9:
      A
    case 8:
      A
    case 7:
      A
    case 6:
      A
    case 5:
      A
    case 4:
      A
    case 3:
      A
    case 2:
      A
    case 1:
      A
  }
  printf("%d\n",i); 
}
