/* xabacus: Begun on Mon Jun 24 1991 */

#define RELEASENUM	"1.0"
#define PATCHLEVEL	0

