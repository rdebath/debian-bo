extern drawIntro();
extern lesson1();
extern lesson2();
extern lesson3();
extern drawQuery();
extern drawDemoWindow();

