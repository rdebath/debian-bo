/*
 * This is GNU Shogi.
 * Copyright (c) 1993,1994,1995 Matthias Mutz.
 * GNU Shogi is based on GNU Chess
 * Copyright (c) 1986-1992 Free Software Foundation.
 *
 */
char version[] = "1.2";
char patchlevel[] = "03";

