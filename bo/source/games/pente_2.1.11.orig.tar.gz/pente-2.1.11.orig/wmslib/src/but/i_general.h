/*
 * wmslib/src/but/i_general.h, part of wmslib (Library functions)
 * Copyright (C) 1995 William Shubert.
 * See "configure.h.in" for more copyright information.
 *
 * Includes for auxiliary button code.
 */

#ifndef  _BUT_I_GENERAL_H_
#define  _BUT_I_GENERAL_H_  1


#endif  /* _BUT_I_GENERAL_H_ */
