/*
 * wmslib/src/but/i_win.h, part of wmslib (Library functions)
 * Copyright (C) 1995 William Shubert.
 * See "configure.h.in" for more copyright information.
 *
 * Includes for i_win.c
 */

#ifndef  _BUT_I_WIN_H_
#define  _BUT_I_WIN_H_  1


#endif  /* _BUT_I_WIN_H_ */
