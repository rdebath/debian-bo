/*
 * wmslib/src/but/i_snd.h, part of wmslib (Library functions)
 * Copyright (C) 1995 William Shubert.
 * See "configure.h.in" for more copyright information.
 *
 * Includes for i_snd.c
 */

#ifndef  _BUT_I_SND_H_
#define  _BUT_I_SND_H_  1


#endif  /* _BUT_I_SND_H_ */
