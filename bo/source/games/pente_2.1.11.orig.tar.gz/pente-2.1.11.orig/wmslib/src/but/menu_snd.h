/*
 * wmslib/src/but/menu_snd.h, part of wmslib (Library functions)
 * Copyright (C) 1995 William Shubert.
 * See "configure.h.in" for more copyright information.
 *
 * Includes for menu_snd.c
 */

#ifndef  _BUT_MENU_SND_H_
#define  _BUT_MENU_SND_H_  1

/**********************************************************************
 * Global variables
 **********************************************************************/

extern Snd  butMenu_openSnd, butMenu_closeSnd;

#endif  /* _BUT_MENU_SND_H_ */
