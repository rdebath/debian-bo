/*
 * wmslib/src/but/i_finder.h, part of wmslib (Library functions)
 * Copyright (C) 1995 William Shubert.
 * See "configure.h.in" for more copyright information.
 *
 * Includes for i_finder.c
 */

#ifndef  _BUT_I_FINDER_H_
#define  _BUT_I_FINDER_H_  1


#endif  /* _BUT_I_FINDER_H_ */
