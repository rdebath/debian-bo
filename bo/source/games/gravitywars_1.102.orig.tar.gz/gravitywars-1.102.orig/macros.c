/* GravityWars 1.1,  (C) Sami Niemi -95 */

/* Wow.. A lot of stuff... */


#include "memory.h"

void the_end() {
  ending=TRUE;
}


void explode() {
   sf[0]=(sf[0]&65479)|8;
}







