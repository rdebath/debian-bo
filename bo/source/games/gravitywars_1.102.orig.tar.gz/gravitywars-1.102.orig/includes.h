#include <stdio.h>
#include <vgakeyboard.h>
#include <vgamouse.h>
#include <vgagl.h>
#include <vga.h>
#include <math.h>
#include <stdlib.h>
#include <unistd.h>

#include <sys/kd.h> /* FOR BEEP() */

#include "config.h"


