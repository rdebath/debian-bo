
/*
    xskat - a card game for 1 to 3 players.
    Copyright (C) 1996  Gunter Gerhardt

    This program is free software; you can redistribute it freely.
    Use it at your own risk; there is NO WARRANTY.
*/

#define static
#include "icon.xbm"
#include "bwcards.xbm"
#include "colcards.xbm"
unsigned char colcards_pixs[colcards_width*colcards_height/4];
