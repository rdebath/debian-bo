# define static 
# include "_accident"
# include "accident_mask"

