# define static
# include "out"
# include "out_mask"
