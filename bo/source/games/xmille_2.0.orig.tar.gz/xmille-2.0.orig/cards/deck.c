# define	static
# include	"deck_mask"
# include	"deck_red"
# include	"deck_blue"
#include	"deck_both"
