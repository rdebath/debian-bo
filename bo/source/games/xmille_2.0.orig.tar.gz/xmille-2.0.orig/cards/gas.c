# define static
# include	"_gas"
# include	"gas_mask"
