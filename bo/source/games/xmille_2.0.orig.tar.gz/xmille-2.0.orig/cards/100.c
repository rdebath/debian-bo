# define static
# include	"_100"
