# define static
# include 	"_puncture"
# include	"puncture_mask"
