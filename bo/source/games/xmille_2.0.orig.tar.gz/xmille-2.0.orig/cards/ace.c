# define static
# include	"_ace"
# include	"ace_mask"
