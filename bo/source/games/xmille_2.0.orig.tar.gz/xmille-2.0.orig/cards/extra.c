# define static
# include	"_extra"
# include	"extra_mask"
