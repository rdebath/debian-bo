# define static
# include "_end"
# include "end_mask"
