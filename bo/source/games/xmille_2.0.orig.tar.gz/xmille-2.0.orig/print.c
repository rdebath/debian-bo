# include	"mille.h"

/*
 * @(#)print.c	1.1 (Berkeley) 4/1/82
 */
