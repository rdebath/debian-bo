char version[] = "mount-2.6d";
