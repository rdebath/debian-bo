#define DPKG_VERSION "1.4.0.8" /* This line modified by Makefile */
