/*
 * version.h --- controls the version number printed by the e2fs
 * programs.
 *
 * Copyright 1995, 1996, 1997 by Theodore Ts'o.  This file may be
 * redistributed under the GNU Public License.
 */

#define E2FSPROGS_VERSION "1.10"
#define E2FSPROGS_DATE "24-Apr-97"
