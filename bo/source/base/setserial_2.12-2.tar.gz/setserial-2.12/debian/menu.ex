text Apps/Misc setserial none "setserial Description" /usr/bin/setserial
