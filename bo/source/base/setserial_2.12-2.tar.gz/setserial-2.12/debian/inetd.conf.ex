#:OTHER:
setserial	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/setserial
