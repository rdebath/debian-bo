0 4	* * *	root	setserial_maintenance
