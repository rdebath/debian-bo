/* mawk 1.3 */
#define  PATCHLEVEL	3
#define  PATCH_STRING	".3"
#define  DATE_STRING    "Nov 1996"
#define  MAWK_ID	"@(#)mawk 1.3.3"
