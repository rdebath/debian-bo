#include        <stdlib.h>	/* malloc, free, atoi */
#include        <stdarg.h>
#include        <setjmp.h>
#include        <signal.h>
#include        <stdio.h>
#include        <string.h>
#include        <math.h>
#include        <ctype.h>

#include "gencom.h"
#include "erreurs.h"
#include "genport.h"
#ifdef __cplusplus
#include "mpin.h"
#else
#include "mpansi.h"
#endif



