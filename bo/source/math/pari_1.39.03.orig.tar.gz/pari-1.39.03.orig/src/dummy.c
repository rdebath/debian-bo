#include "genpari.h"

GEN
ploth(entree *ep, GEN a, GEN b, char *ch, long prec)
{
  return gnil;
}

GEN
plothmult(entree *ep, GEN a, GEN b, char *ch, long prec)
{
  return gnil;
}

GEN
ploth2(entree *ep, GEN a, GEN b, char *ch, long prec)
{
  return gnil;
}

GEN
plothraw(GEN listx, GEN listy)
{
  return gnil;
}

GEN
rectdraw(GEN list)
{
  return gnil;
}
