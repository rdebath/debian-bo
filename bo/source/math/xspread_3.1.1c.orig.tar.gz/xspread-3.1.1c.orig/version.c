#include <config.h>

#include <stdio.h>
#include "sc.h"

/*
 * CODE REVISION NUMBER:
 *
 * The part after the first colon, except the last char, appears on the screen.
 *
 * XSpread and SC now just share 'version'
 */

char *version = "XSpread v3.1L(JeffBuhrt), Based on Sc 6.28 ($Revision: 1.2 $)";
