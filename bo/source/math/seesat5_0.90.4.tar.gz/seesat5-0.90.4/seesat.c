#define MAIN
#include "SEESAT.H"
