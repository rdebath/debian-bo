#ifndef lint
static char *RCSid = "$Id: hidden3d.c,v 1.25 1997/03/09 23:50:01 drd Exp $";
#endif
/* HBB: this is from newhide.tgz, changed a bit by me */


/* GNUPLOT - hidden3d.c */
/*
 * Copyright (C) 1986 - 1993, 1996   Thomas Williams, Colin Kelley
 *
 * Permission to use, copy, and distribute this software and its
 * documentation for any purpose with or without fee is hereby granted, 
 * provided that the above copyright notice appear in all copies and 
 * that both that copyright notice and this permission notice appear 
 * in supporting documentation.
 *
 * Permission to modify the software is granted, but not the right to
 * distribute the modified code.  Modifications are to be distributed 
 * as patches to released version.
 *
 * This software is provided "as is" without express or implied warranty.
 *
 *
 * AUTHORS
 *
 *   Original Software:
 *       Gershon Elber and many others.
 *
 * 19 September 1992  Lawrence Crowl  (crowl@cs.orst.edu)
 * Added user-specified bases for log scaling.
 *
 * 'someone'  contributed a complete rewrite of the hidden line
 * stuff, for about beta 173 or so, called 'newhide.tgz'
 *
 * 1995-1996 Hans-Bernhard Br"oker (Broeker@physik.rwth-aachen.de)
 *   Speedup, cleanup and several modification to integrate
 *   'newhide' with 3.6 betas ~188 (start of work) up to 273.
 *   As of beta 290, this is 'officially' in gnuplot.
 *
 * There is a mailing list for gnuplot users. Note, however, that the
 * newsgroup 
 *      comp.graphics.apps.gnuplot 
 * is identical to the mailing list (they
 * both carry the same set of messages). We prefer that you read the
 * messages through that newsgroup, to subscribing to the mailing list.
 * (If you can read that newsgroup, and are already on the mailing list,
 * please send a message to majordomo@dartmouth.edu, asking to be
 * removed from the mailing list.)
 *
 * The address for mailing to list members is
 *         info-gnuplot@dartmouth.edu
 * and for mailing administrative requests is 
 *         majordomo@dartmouth.edu
 * The mailing list for bug reports is 
 *         bug-gnuplot@dartmouth.edu
 * The list of those interested in beta-test versions is
 *         info-gnuplot-beta@dartmouth.edu
 */

#include <stdio.h>
#include <math.h>
#include <assert.h>

#ifdef __TURBOC__
#include <stdlib.h>		/* for qsort */
#endif

#include "plot.h"
#include "setshow.h"

/* TODO (HBB's notes, just in case you're interested):
 * + fix all the problems I annotated by a 'FIXME' comment
 * + Find out which value EPSILON should have, and why
 * + Ask gnuplot-beta for a suitable way of concentrating
 *   all those 'VERYSMALL', 'EPSILON', and other numbers
 *   into one, consistent scheme, possibly based on
 *   <float.h>. E.g., I'd say that for most applications,
 *   the best 'epsilon' is either DBL_EPS or its square root.
 * + redo all the profiling, esp. to find out if TEST_GRIDCHECK=1
 *   actually gains some speed, and if it is worth the memory
 *   spent to store the bit masks
 *   -> seems not improve speed at all, at least for my standard
 *   test case (mandd.gpl) it even slows it down by ~ 10%
 * + Evaluate the speed/memory comparison for storing vertex
 *   indices instead of (double) floating point constants
 *   to store {x|y}{min|max}
 * + remove those of my comments that are now pointless
 * + indent all that code
 * + try to really understand that 'hl_buffer' stuff...
 * + get rid of hardcoded things like sizeof(short)==4,
 *   those 0x7fff terms and all that.
 * + restructure the hl_buffer storing method to make it more efficient
 * + Try to cut the speed decrease of this code rel. to the old hidden
 *   hidden line removal. (For 'mandd.gpl', it costs an overall
 *   factor of 9 compared with my older versions of gnuplot!)
 */

/* HBB: if this module is compiled with TEST_GRIDCHECK=1 defined,
 * it will store the information about {x|y}{min|max} in an
 * other (additional!) form: a bit mask, with each bit representing
 * one horizontal or vertical strip of the screen. The bits
 * for  strips a polygon spans are set to one. This allows to
 * test for xy_overlap simply by comparing bit patterns.
 */
#ifndef TEST_GRIDCHECK
#define TEST_GRIDCHECK 0
#endif

/* HBB 961124; If you don't want the color-distinction between the
 * 'top' and 'bottom' sides of the surface, like I do, then just compile
 * with -DBELOW_TYPE_ADD=0. */
#ifndef BELOW_TYPE_ADD
#define BELOW_TYPE_ADD 1
#endif

/* HBB 961127: defining FOUR_TRIANGLES=1 will separate each quadrangle
 * of data points into *four* triangles, by introducing an additional
 * point at the mean of the four corners. Status: experimental 
 */
#ifndef FOUR_TRIANGLES
#define FOUR_TRIANGLES 0
#endif

/* HBB 961201: defining SENTINEL=1 will use a sentinel polygon way
 * behind the view volume to flag the end of the linked list plist
 * (linked via ->next pointers), instead of next==-1. This is a slight
 * bit faster because some tests become superfluous. Status: not yet
 * fully working, still produces endless loops sometimes.  */
#ifndef SENTINEL
#define SENTINEL 0
#endif 

/* HBB 961212: defining STYLE_POINTER=1 will cause only the pointer
 * to each plot's lp_style structure to be saved with each of its
 * polygons, saving considerable amounts of space.  */
#ifndef STYLE_POINTER
#define STYLE_POINTER 1 /* Have this enabled by default (!) */
#endif

/* HBB 961212: this #define lets you choose if the diagonals that
 * divide each original quadrangle in two triangles will be drawn
 * visible or not: do draw them, define it to be 7L, otherwise let be
 * 3L */
#ifndef TRIANGLE_LINES_TO_DRAW
#define TRIANGLE_LINES_TO_DRAW 7L
#endif

/* HBB 970131: with HANDLE_UNDEFINED=1, let's try to handle UNDEFINED
 * data points in the input we're given by the rest of gnuplot. We do
 * that by marking these points by giving them z=-2 (which normally
 * never happens), and then refusing to build any polygon if one of
 * its vertices has this mark. Thus, there's now a hole in the
 * generated surface. */

/* drd : 2 means undefined only. 1 means outrange treated as undefined */
#ifndef HANDLE_UNDEFINED
#define HANDLE_UNDEFINED 2 /* let's enable this for the time of coding */
#endif

/* And the functions to map from user 3D space into normalized -1..1 */
#define map_x3d(x) ((x-x_min3d)*xscale3d-1.0)
#define map_y3d(y) ((y-y_min3d)*yscale3d-1.0)
#define map_z3d(z) ((z-base_z)*zscale3d-1.0)

extern int suppressMove;
extern int xright, xleft, ybot, ytop;
extern int xmiddle, ymiddle, xscaler, yscaler;
extern double min_array[], max_array[];
extern int auto_array[], log_array[];
extern double base_array[], log_base_array[];
extern double xscale3d, yscale3d, zscale3d;

/* for convenience while converting to use these arrays */
#define x_min3d min_array[FIRST_X_AXIS]
#define x_max3d max_array[FIRST_X_AXIS]
#define y_min3d min_array[FIRST_Y_AXIS]
#define y_max3d max_array[FIRST_Y_AXIS]
#define z_min3d min_array[FIRST_Z_AXIS]
#define z_max3d max_array[FIRST_Z_AXIS]
#define min3d_z min_array[FIRST_Z_AXIS]
#define max3d_z max_array[FIRST_Z_AXIS]

extern double base_z;
extern int hidden_no_update, hidden_active;
extern int hidden_line_type_above, hidden_line_type_below;

extern double trans_mat[4][4];


#ifdef ANSI_C
/* ANSI preprocessor concatenation */
# define CONCAT(x,y) x##y
# define CONCAT3(x,y,z) x##y##z
#else
/* K&R preprocessor concatenation */
# define CONCAT(x,y) x/**/y
# define CONCAT3(x,y,z) x/**/y/**/z
#endif

/* Bitmap of the screen.  The array for each x value is malloc-ed as needed */
/* HBB 961111: started parametrisation of type t_pnt, to prepare change from
 * short to normal ints in **pnt. The other changes aren't always annotated,
 * so watch out! */
typedef unsigned short int t_pnt;
#define PNT_BITS (CHAR_BIT*sizeof(t_pnt))
#define PNT_MAX USHRT_MAX /* caution! ANSI-dependant ! ? */
typedef t_pnt *tp_pnt;
static tp_pnt *pnt;

/* Testroutine for the bitmap */
/* HBB 961110: fixed slight problem indicated by lclint: 
 * calling IS_UNSET with pnt==0 (possible?) */
/* HBB 961111: changed for new t_pnt, let compiler take care of optimisation
 * `%' -> `&' */
/* HBB 961124: switched semantics: as this was *always* called as !IS_SET(),
 * it's better to check for *unset* bits right away: */
#define IS_UNSET(X,Y) ((!pnt || pnt[X]==0) ? 1 : !(((pnt[X])[(Y)/PNT_BITS] >> ((Y)%PNT_BITS)) & 0x01))

/* Amount of space we need for one vertical row of bitmap, 
   and byte offset of first used element */
static unsigned long y_malloc;

/* These numbers are chosen as dividers into the bitmap. */
static int xfact, yfact;
#define XREDUCE(X) ((X)/xfact)
#define YREDUCE(Y) ((Y)/yfact)

/* These variables are only used for drawing the individual boxes that
   make up the 3d figure.  After each box is drawn, the information is copied
   to the bitmap: 
   xmin_hl, ymin_hl are used to keep track of the range of x values. 
   The arrays ymin_hl, ymax_hl are used to keep track of the minimum and 
   maximum y values used for each X value. */

/* HBB 961124: new macro, to avoid a wordsize-depence */
#define HLBUF_XLIM_MAX UINT_MAX /* caution! ANSI-only !? */
static unsigned int xmin_hl, xmax_hl;

/* HBB: parametrise type of hl_buffer elements, to allow easier changing: */
typedef short int t_hlbuf_ylim;
#define HLBUF_YLIM_MAX SHRT_MAX /* caution! ANSI-only !? */
static t_hlbuf_ylim *ymin_hl, *ymax_hl;

/* hl_buffer is a buffer which is needed to draw polygons with very small 
   angles correct:
   One polygon is splitted during the sorting algorithmus into several 
   polygons. Before drawing a part of a polygon, I save in this buffer 
   all lines of the polygon, which will not yet be drawn.
   If then the actual part draws a virtual line (a invisible line, which
   splits the polygon into 2 parts), it draws the line visible in those 
   points, which are set in the buffer.
   The geometry of the buffer:
   hl_buffer[i] stands for the i'th column of the bitmap.
   Each column is splitted into pairs of points (a,b).
   Each pair describes a cross of one line with the column. */
struct Cross
  {
    int a, b;
    struct Cross *next;
  };
static struct Cross **hl_buffer;


struct Vertex
  {
    coordval x, y, z;
    int style;
  };

struct Polygon
  {
    int n;                      /* amount of vertices */
    long *vertex;              /* The vertices (indices on vlist) */
    long line;			/* i'th bit shows, if the i'th line should be drawn */
    coordval zmax;		/* the maximum z-value of the polygon */
#if STYLE_POINTER
    struct lp_style_type *lp;	/* pointer to l/p properties */
#else
    struct lp_style_type lp;    /* line and point properties */
#endif
    int style;			/* The style of the lines */
    long next;			/* the next polygon (index on plist) */
    /* HBB 961201: additional link, should speed up draw()'s q-loop */
    long next_frag;		/* next fragment of same polygon... */
    int id;			/* Which polygons belong together? */
    int tested;			/* To determine a loop during the sorting algorithm */
#if TEST_GRIDCHECK
    unsigned int xextent, yextent;
#endif
    coordval xmin, xmax, ymin, ymax, zmin;
  };

typedef enum {			/* result type for polygon_plane_intersection */
  infront, inside, behind, intersects
} t_poly_plane_intersect;

static struct Vertex *vlist;          /* The vertices */
static struct Polygon *plist;          /* The polygons */
static long nvert, npoly;                      /* amount of vertices and polygons */
static long pfree, vert_free;              /* index on the first free entries */
static long pfirst;                    /* Index on the first polygon */
#if SENTINEL
static long Sentinel; 			/* Index of the Sentinel polygon */
#else
#define Sentinel (-1)			/* use Index -1 as Pseudo-Sentinel */
#endif

#define EXTEND_PLIST() \
    plist = (struct Polygon*) ralloc(plist, \
      (unsigned long)sizeof(struct Polygon)*(npoly+=10L), "hidden plist")

#define CHECK_PLIST() if (pfree >= npoly) EXTEND_PLIST()
#define CHECK_PLIST_EXTRA(extra) if (pfree >= npoly) { EXTEND_PLIST() ; extra; }

#define CHECK_PLIST_2() if (pfree+1 >= npoly) EXTEND_PLIST()


/* precision of calculations in normalized space: */
#define EPSILON 1e-10 /* HBB: was 1.0E-5 */
#define SIGNOF(X)  ( ((X)<-EPSILON) ? -1: ((X)>EPSILON) )

/* Some inexact relations: == , > , >= */
#define EQ(X,Y)  (fabs( (X) - (Y) ) < EPSILON)      /* X == Y */
#define GR(X,Y)  ((X) > (Y) + EPSILON)      /* X >  Y */
#define GE(X,Y)  ((X) >=(Y) - EPSILON)      /* X >= Y */

/* Test, if two vertices are near each other */
#define V_EQUAL(a,b) ( GE(0.0, fabs((a)->x - (b)->x) + \
   fabs((a)->y - (b)->y) + fabs((a)->z - (b)->z)) )

#define SETBIT(a,i,set) a= (set) ?  (a) | (1L<<(i)) : (a) & ~(1L<<(i))
#define GETBIT(a,i) (((a)>>(i))&1L)

#define UINT_BITS (CHAR_BIT*sizeof(unsigned int))
#define USHRT_BITS (CHAR_BIT*sizeof(unsigned short))

GP_INLINE static void print_polygon __PROTO((struct Polygon * p,
                                         const char *pname));


/* HBB: new routine, to help debug 'Logic errors', mainly */
GP_INLINE static void
print_polygon(p, pname)
struct Polygon * p;
const char *pname;
{
  struct Vertex *v;
  int i;

  fprintf(stderr, "%s:(ind %d) n:%d, id:%d, next:%ld, tested:%d\n", pname, (int)(p-plist), p->n, p->id, p->next, p->tested);
  fprintf(stderr,"zmin:%g, zmax:%g\n", p->zmin, p->zmax);
  for (i=0; i<p->n; i++, v++) {
    v = vlist + p->vertex[i];
    fprintf(stderr,"%ld ->(%g, %g, %g)\n", p->vertex[i], v->x, v->y, v->z);
  }
}

/* HBB: new macro. Gets Minimum C value of polygon, C is x, y, or z: */
#define GET_MIN(p, C, min) do { \
  int i; \
  long *v=p->vertex; \
                       \
  min = vlist[*v++].C; \
  for (i=1; i< p->n; i++, v++) \
    if (vlist[*v].C) < min) \
      min = vlist[*v].C; \
} while (0)

/* HBB: new macro. Gets Maximum C value of polygon, C is x, y, or z: */
#define GET_MAX(p, C, max) do { \
  int i; \
  long *v=p->vertex; \
                      \
  max = vlist[*v++].C; \
  for (i=1; i< p->n; i++, v++) \
    if (vlist[*v].C > max) \
      max = vlist[*v].C; \
} while (0)

/* forward references */

static void map3d_xyz __PROTO((double x, double y, double z, struct Vertex *v));
static int reduce_polygon __PROTO((int *n, long **v, long *line, int nmin));
#if STYLE_POINTER
static void build_polygon __PROTO((struct Polygon *p, int n,
  long *v, long line, int style, struct lp_style_type *lp,
  long next, long next_frag, int id, int tested));
#else
static void build_polygon __PROTO((struct Polygon *p, int n,
  long *v, long line, int style, struct lp_style_type lp,
  long next, long next_frag, int id, int tested));
#endif
static void init_polygons __PROTO((struct surface_points *plots, int pcount));
static int  compare_by_zmax __PROTO((const void *p1, const void *p2));
static void sort_by_zmax __PROTO((void));
static int obscured __PROTO((struct Polygon *p));
GP_INLINE static int xy_overlap __PROTO((struct Polygon *a, struct Polygon *b));
static void get_plane __PROTO((struct Polygon *p, double *a, double *b,
                           double *c, double *d));
static t_poly_plane_intersect polygon_plane_intersection __PROTO((struct Polygon *p, double a,
							      double b, double c, double  d));
static int intersect __PROTO((struct Vertex *v1, struct Vertex *v2,
                          struct Vertex *v3, struct Vertex *v4));
static int v_intersect __PROTO((struct Vertex *v1, struct Vertex *v2,
                            struct Vertex *v3, struct Vertex *v4));
static int intersect_polygon __PROTO((struct Vertex *v1, struct Vertex *v2,
                                  struct Polygon *p));
static int full_xy_overlap __PROTO((struct Polygon *a, struct Polygon *b));
static long build_new_vertex __PROTO((long V1, long V2, double w));
static long split_polygon_by_plane __PROTO((long P, double a, double b, double c,
                                        double d, TBOOLEAN f));
static int in_front __PROTO((long Last, long Test));
GP_INLINE static TBOOLEAN hl_buffer_set __PROTO((int xv, int yv));
GP_INLINE static void update_hl_buffer_column __PROTO((int xv, int ya, int yv));
static void draw_clip_line_buffer __PROTO((int x1, int y1, int x2, int y2));
static void draw_clip_line_update __PROTO((int x1, int y1, int x2, int y2,
                                       int virtual));
GP_INLINE static void clip_vector_h __PROTO((int x, int y));
GP_INLINE static void clip_vector_virtual __PROTO((int x, int y));
GP_INLINE static void clip_vector_buffer __PROTO((int x, int y));
static void draw __PROTO((struct Polygon *p));


/* Initialize the necessary steps for hidden line removal and
   initialize global variables. */
void 
init_hidden_line_removal ()
{
  int i;

  /*  We want to keep the bitmap size less than 2048x2048, so we choose
   *  integer dividers for the x and y coordinates to keep the x and y
   *  ranges less than 2048.  In practice, the x and y sizes for the bitmap
   *  will be somewhere between 1024 and 2048, except in cases where the
   *  coordinates ranges for the device are already less than 1024.
   *  We do this mainly to control the size of the bitmap, but it also
   *  speeds up the computation.  We maintain separate dividers for
   *  x and y.
   */
  xfact = (xright - xleft) / 1024;
  yfact = (ytop - ybot) / 1024;
  if (xfact == 0)
    xfact = 1;
  if (yfact == 0)
    yfact = 1;
  if (pnt == 0)
    {
      i = XREDUCE (xright) - XREDUCE (xleft) + 1;
      pnt = (tp_pnt *) alloc (
        (unsigned long) (i * sizeof (tp_pnt)), "hidden pnt");
      while (--i>=0)
        pnt[i] = (tp_pnt) 0;
    }
}

/* Reset the hidden line data to a fresh start.                              */
void 
reset_hidden_line_removal ()
{
  int i;
  if (pnt)
    {
      for (i = 0; i <= XREDUCE (xright) - XREDUCE (xleft); i++)
	{
	  if (pnt[i])
	    {
	      free (pnt[i]);
	      pnt[i] = 0;
	    };
	};
    };
}


/* Terminates the hidden line removal process.                  */
/* Free any memory allocated by init_hidden_line_removal above. */
void 
term_hidden_line_removal ()
{
  if (pnt)
    {
      int j;
      for (j = 0; j <= XREDUCE (xright) - XREDUCE (xleft); j++)
	{
	  if (pnt[j])
	    {
	      free (pnt[j]);
	      pnt[j] = 0;
	    };
	};
      free (pnt);
      pnt = 0;
    };
  if (ymin_hl)
    free (ymin_hl), ymin_hl = 0;
  if (ymax_hl)
    free (ymax_hl), ymax_hl = 0;
}


/* Maps from normalized space to terminal coordinates */
#define TERMCOORD(v,x,y) x = ((int)((v)->x * xscaler)) + xmiddle, \
			 y = ((int)((v)->y * yscaler)) + ymiddle;


static void
map3d_xyz (x, y, z, v)
     double x, y, z;		/* user coordinates */
     struct Vertex *v;         /* the point in normalized space */
{
  int i, j;
  double V[4], Res[4],		/* Homogeneous coords. vectors. */
    w = trans_mat[3][3];
  /* Normalize object space to -1..1 */
  V[0] = map_x3d (x);
  V[1] = map_y3d (y);
  V[2] = map_z3d (z);
  V[3] = 1.0;
  Res[0]=0; /*HBB 961110: lclint wanted this... Why? */
  for (i = 0; i < 3; i++)
    {
      Res[i] = trans_mat[3][i];	/* Initiate it with the weight factor. */
      for (j = 0; j < 3; j++)
	Res[i] += V[j] * trans_mat[j][i];
    }
  for (i = 0; i < 3; i++)
    w += V[i] * trans_mat[i][3];
  if (w == 0)
    w = 1.0e-5;
  v->x = Res[0] / w;
  v->y = Res[1] / w;
  v->z = Res[2] / w;
}


/* remove unnecessary Vertices from a polygon: */
static int 
reduce_polygon (n, v, line, nmin)
     int *n;			/* number of vertices */
     long **v;			/* the vertices */
     long *line;		/* the information, which line should be drawn */
     int nmin;			/* if the number reduces under nmin, forget polygon */
     /* Return value 1: the reduced polygon has still more or equal 
        vertices than nmin.
        Return value 0: the polygon was trivial; memory is given free */
{
  int less, i;
  long *w = *v;
  for (less = 0, i = 0; i < *n - 1; i++)
    {
      if (V_EQUAL (vlist + w[i], vlist + w[i + 1]) &&
	  (!GETBIT (*line, i) || GETBIT (*line, i + 1) ||
	   ((i > 0) ? GETBIT (*line, i - 1) : GETBIT (*line, *n - 1))))
	less++;
      else if (less)
	{
	  w[i - less] = w[i];
	  SETBIT (*line, i - less, GETBIT (*line, i));
	}
    }
  if (i - less > 0 &&
      V_EQUAL (vlist + w[i], vlist + w[0]) &&
      (!GETBIT (*line, i) || GETBIT (*line, i - 1) || GETBIT (*line, 0)))
    less++;
  else if (less)
    {
      w[i - less] = w[i];
      SETBIT (*line, i - less, GETBIT (*line, i));
    }
  *n -= less;
  if (*n < nmin)
    {
      free (w);
      return 0;
    }
  if (less)
    {
      w = (long *) ralloc (w, (unsigned long) sizeof (long) * (*n), "hidden red_poly");
      *v = w;
      for (; less > 0; less--)
	SETBIT (*line, *n + less - 1, 0);
    }
  return 1;
}

/* Write polygon in plist */
/*
 * HBB: changed this to precalculate {x|y}{min|max}
 */
static void
build_polygon (p, n, v, line, style, lp, next, next_frag, id, tested)
     struct Polygon *p;               /* this should point at a free entry in plist */
     int n;			/* number of vertices */
     long *v;			/* array of indices on the vertices (in vlist) */
     long line;			/* information, which line should be drawn */
     int style;			/* color of the lines */
#if STYLE_POINTER
     struct lp_style_type *lp;	/* pointer to line/point properties */
#else
     struct lp_style_type lp;   /* line and point properties */
#endif
     long next;			/* next polygon in the list */
     long next_frag;		/* next fragment of same polygon */
     int id;			/* Which polygons belong together? */
     int tested;		/* Is polygon already on the right place of list? */
{
  int i;
  struct Vertex vert;

  if (p >= plist+npoly)
  	fprintf(stderr, "uh oh !\n");

  CHECK_POINTER(plist, p);
  
  p->n = n;
  p->vertex = v;
  p->line = line;
  p->lp = lp;           /* line and point properties */
  p->style = style;
  CHECK_POINTER(vlist, (vlist + v[0]));
  vert=vlist[v[0]];
  p->xmin = p->xmax = vert.x;
  p->ymin = p->ymax = vert.y;
  p->zmin = p->zmax = vert.z;
  for (i = 1; i < n; i++)
    {
      CHECK_POINTER(vlist, (vlist + v[i]));
      vert=vlist[v[i]];
      if (vert.x < p->xmin)
        p->xmin=vert.x;
      else if (vert.x > p->xmax)
        p->xmax=vert.x;
      if (vert.y < p->ymin)
        p->ymin=vert.y;
      else if (vert.y > p->ymax)
        p->ymax=vert.y;
      if (vert.z < p->zmin)
        p->zmin=vert.z;
      else if (vert.z > p->zmax)
        p->zmax=vert.z;
    }

#if TEST_GRIDCHECK
/* FIXME: this should probably use a table of bit-patterns instead...*/
  p->xextent = (~ (~0U << (unsigned int)((p->xmax+1.0)/2.0*UINT_BITS+1.0)))
               & (~0U << (unsigned int)((p->xmin+1.0)/2.0*UINT_BITS));
  p->yextent = (~ (~0U << (unsigned int)((p->ymax+1.0)/2.0*UINT_BITS+1.0)))
               & (~0U << (unsigned int)((p->ymin+1.0)/2.0*UINT_BITS));
#endif

  p->next = next;
  p->next_frag = next_frag; /* HBB 961201: link fragments, to speed up draw() q-loop */
  p->id = id;
  p->tested = tested;
}


/* get the amount of curves in a plot */
#define GETNCRV(NCRV) do {\
   if(this_plot->plot_type==FUNC3D)        \
     for(icrvs=this_plot->iso_crvs,NCRV=0; \
	 icrvs;icrvs=icrvs->next,NCRV++);  \
   else if(this_plot->plot_type == DATA3D) \
        NCRV = this_plot->num_iso_read;    \
    else {                                 \
    	graph_error("Plot type is neither function nor data"); \
    	return; /* stops a gcc -Wunitialised warning */        \
    } \
} while (0)

/* Do we see the top or bottom of the polygon, or is it 'on edge'? */
#define GET_SIDE(vlst,csign) do { \
  double c = vlist[vlst[0]].x * (vlist[vlst[1]].y - vlist[vlst[2]].y) + \
    vlist[vlst[1]].x * (vlist[vlst[2]].y - vlist[vlst[0]].y) + \
    vlist[vlst[2]].x * (vlist[vlst[0]].y - vlist[vlst[1]].y); \
  csign = SIGNOF (c); \
} while (0)

/* HBB 970131: new function, to allow handling of undefined datapoints
 * by leaving out the corresponding polygons from the list.
 * Return Value: 1 if polygon was built, 0 otherwise */
static int maybe_build_polygon __PROTO((struct Polygon *p, int n,
  long *v, long line, int style, struct lp_style_type *lp,
  long next, long next_frag, int id, int tested));

static int
maybe_build_polygon (p, n, v, line, style, lp,
		     next, next_frag, id, tested)
struct Polygon *p;
struct lp_style_type *lp;
int n, style, id, tested;
long *v, line, next, next_frag;
{
#if HANDLE_UNDEFINED
  int i;

  assert(v);

  for (i=0; i<n ; i++)
    if (vlist[v[i]].z == -2.0)
      return 0;			/* *don't* build the polygon! */
#endif /* HANDLE_UNDEFINED */
  build_polygon (p, n, v, line, style, lp, next, next_frag, id, tested );
  return 1;
}

static void
init_polygons (plots, pcount)
     struct surface_points *plots;
     int pcount;
     /* Initialize vlist, plist */
{
  long int i;
  struct surface_points *this_plot;
  int surface;
  long int ncrv, ncrv1;
  struct iso_curve *icrvs;
  int row_offset;
  int id;
  int n1, n2;			/* number of vertices of a Polygon */
  long *v1, *v2;		/* the Vertices */
  long line1, line2;		/* which  lines should be drawn */
  int above=-1, below, style1, style2;     /* the line color */
#if STYLE_POINTER
  struct lp_style_type *lp;	/* pointer to line and point properties */
#else
  struct lp_style_type lp;      /* line and point properties */
#endif  
  int c1, c2;			/* do we see the front or the back */
  TBOOLEAN border1, border2;		/* is it at the border of the surface */


  /* allocate memory for polylist and nodelist */
  nvert = npoly = 0;
  for (this_plot = plots, surface = 0;
       surface < pcount;
       this_plot = this_plot->next_sp, surface++)
    {
      GETNCRV (ncrv);
      switch (this_plot->plot_style)
	{
	case LINESPOINTS:
	case STEPS:		/* handle as LINES */
        case FSTEPS:
	case HISTEPS:
	case LINES:
#if FOUR_TRIANGLES
	  nvert += ncrv * (2 * this_plot->iso_crvs->p_count - 1);
#else
	  nvert += ncrv * (this_plot->iso_crvs->p_count);
#endif
	  npoly += 2 * (ncrv - 1) * (this_plot->iso_crvs->p_count - 1);
	  break;
	case DOTS:
	case XERRORBARS:	/* handle as POINTSTYLE */
	case YERRORBARS:
        case XYERRORBARS:
        case BOXXYERROR:
        case BOXERROR:
        case CANDLESTICKS:      /* HBB: these as well */
        case FINANCEBARS:
        case VECTOR:
        case POINTSTYLE:
	  nvert += ncrv * (this_plot->iso_crvs->p_count);
	  npoly += (ncrv - 1) * (this_plot->iso_crvs->p_count - 1);
	  break;
	case BOXES:		/* handle as IMPULSES */
	case IMPULSES:
	  nvert += 2 * ncrv * (this_plot->iso_crvs->p_count);
	  npoly += (ncrv - 1) * (this_plot->iso_crvs->p_count - 1);
	  break;
	}
    };
#if SENTINEL /* HBB 961201: reserve additional space for the sentinel polygon: */
  nvert++;
  npoly++;
#endif
  vlist = (struct Vertex *)
    alloc ((unsigned long) sizeof (struct Vertex) * nvert, "hidden vlist");
  plist = (struct Polygon *)
    alloc ((unsigned long) sizeof (struct Polygon) * npoly, "hidden plist");

  /* initialize vlist: */
  for (vert_free = 0, this_plot = plots, surface = 0;
       surface < pcount;
       this_plot = this_plot->next_sp, surface++)
    {
      switch (this_plot->plot_style)
	{
	case LINESPOINTS:
	case BOXERROR:		/* handle as POINTSTYLE */
        case BOXXYERROR:
        case XERRORBARS:
	case YERRORBARS:
        case XYERRORBARS:
        case CANDLESTICKS:      /* HBB: these as well */
        case FINANCEBARS:
        case VECTOR:
	case POINTSTYLE:
	  above = this_plot->lp_properties.p_type;
	  break;
	case STEPS:		/* handle as LINES */
        case FSTEPS:
	case HISTEPS:
	case LINES:
	case DOTS:
	case BOXES:		/* handle as IMPULSES */
	case IMPULSES:
	  above = -1;
	  break;
	}
      GETNCRV (ncrv1);
      for (ncrv = 0, icrvs = this_plot->iso_crvs;
	   ncrv < ncrv1 && icrvs;
	   ncrv++, icrvs = icrvs->next)
	{
	  struct coordinate GPHUGE *points = icrvs->points;
	  for (i = 0; i < icrvs->p_count; i++)
	    {
#if HANDLE_UNDEFINED
		/* assume OUTRANGE=1, UNDEFINED=2
		 * HANDLE_UNDEFINED=2 for ignore undefined points only
		 * HANDLE_UNDEFINED=1 for ignore outrange too
		 */
	      if (points[i].type >= HANDLE_UNDEFINED) {
		/* mark this vertex as a bad one */
		vlist[vert_free++].z = -2.0;
		continue;
	      }
#endif /* HANDLE_UNDEFINED */
	      map3d_xyz (points[i].x, points[i].y, points[i].z, vlist + vert_free);
	      vlist[vert_free++].style = above;
	      if (this_plot->plot_style == IMPULSES ||
		  this_plot->plot_style == BOXES)
		{
		  map3d_xyz (points[i].x, points[i].y, z_min3d, vlist + vert_free);
		  vlist[vert_free++].style = above;
		}
#if FOUR_TRIANGLES
	      if (this_plot->plot_style == LINES && /* FIXME: handle other styles as well! */
		  i < icrvs->p_count - 1) 
		vert_free++;	/* keep one entry free for quad-center */
#endif
	    }
	}
    }

  /* initialize plist: */
  id = 0;
  for (pfree = vert_free = 0, this_plot = plots, surface = 0;
       surface < pcount;
       this_plot = this_plot->next_sp, surface++)
    {
      row_offset = this_plot->iso_crvs->p_count;
#if STYLE_POINTER
      lp = &(this_plot->lp_properties);
#else
      /* HBB: problem found by lclint: lp has undefined fields, bad!
       * try remedy: assign the *whole* lp_properties struct to lp */
      lp = this_plot->lp_properties;
#endif
      above = this_plot->lp_properties.l_type;
      below = this_plot->lp_properties.l_type + BELOW_TYPE_ADD;
      GETNCRV (ncrv1);
      for (ncrv = 0, icrvs = this_plot->iso_crvs;
	   ncrv < ncrv1 && icrvs;
	   ncrv++, icrvs = icrvs->next)
	for (i = 0; i < icrvs->p_count; i++)
	  switch (this_plot->plot_style)
	    {
	    case LINESPOINTS:
	    case STEPS:	/* handle as LINES */
            case FSTEPS:
	    case HISTEPS:
	    case LINES:
	      if (i < icrvs->p_count - 1 && ncrv < ncrv1 - 1)
		{
#if FOUR_TRIANGLES
		  long *v3, *v4;
		  int n3, n4;
		  long line3, line4;
		  int c3, c4, style3, style4;
		  TBOOLEAN border3, border4, inc_id=FALSE;
		  
		  /* Build medium vertex: */
		  vlist[vert_free+1].x = 
		    (vlist[vert_free].x + vlist[vert_free+2*row_offset-1].x +
		     vlist[vert_free+2].x + vlist[vert_free+2*row_offset+1].x)/4;
		  vlist[vert_free+1].y =
		    (vlist[vert_free].y + vlist[vert_free+2*row_offset-1].y +
		     vlist[vert_free+2].y + vlist[vert_free+2*row_offset+1].y)/4;
		  vlist[vert_free+1].z =
		    (vlist[vert_free].z + vlist[vert_free+2*row_offset-1].z +
		     vlist[vert_free+2].z + vlist[vert_free+2*row_offset+1].z)/4;
		  vlist[vert_free+1].style = above;

		  n1 = 3;
		  v1 = (long *) alloc ((unsigned long) sizeof (long) * n1, "hidden v1 for line");
		  v1[0] = vert_free + 2;
		  v1[1] = vert_free;
		  v1[2] = vert_free + 1;
                  line1 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v1,c1);
		  style1 = (c1 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border1 = (i == 0);

/* !!FIXME!! special casing (see the older code) still needs to be
 * implemented! */
		  if ((c1 || border1) &&
		      reduce_polygon (&n1, &v1, &line1, 3))
		    {
		      CHECK_PLIST();
		      build_polygon (plist + pfree++, n1, v1, line1, style1,
				     lp, -1L, -1L, id++, 0);
		      inc_id = TRUE;
		    }		      

		  n2 = 3;
		  v2 = (long *) alloc ((unsigned long) sizeof (long) * n2, "hidden v2 for line");
		  v2[0] = vert_free ;
		  v2[1] = vert_free + 2*row_offset - 1;
		  v2[2] = vert_free + 1;
                  line2 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v2,c2);
		  style2 = (c2 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border2 = (ncrv == 0);
		  
		  if ((c2 || border2) &&
		      reduce_polygon (&n2, &v2, &line2, 3))
		    {
		      CHECK_PLIST();
		      build_polygon (plist + pfree++, n2, v2, line2, style2,
				     lp, -1L, -1L, id++, 0);
		      inc_id = TRUE;
		    }		      

		  n3 = 3;
		  v3 = (long *) alloc ((unsigned long) sizeof (long) * n3, "hidden v3 for line");
		  v3[0] = vert_free + 2*row_offset - 1;
		  v3[1] = vert_free + 2*row_offset + 1;
		  v3[2] = vert_free + 1;
                  line3 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v3,c3);
		  style3 = (c3 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border3 = (i >= icrvs->p_count - 2);

		  if ((c3 || border3) &&
		      reduce_polygon (&n3, &v3, &line3, 3))
		    {
		      CHECK_PLIST();
		      build_polygon (plist + pfree++, n3, v3, line3, style3,
				     lp, -1L, -1L, id++, 0);
		      inc_id = TRUE;
		    }		      

		  n4 = 3;
		  v4 = (long *) alloc ((unsigned long) sizeof (long) * n4, "hidden v4 for line");
		  v4[0] = vert_free + 2*row_offset + 1;
		  v4[1] = vert_free;
		  v4[2] = vert_free + 1;
                  line4 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v4,c4);
		  style4 = (c4 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border4 = (ncrv >= ncrv1 - 2);

		  if ((c4 || border4) &&
		      reduce_polygon (&n4, &v4, &line4, 3))
		    {
		      CHECK_PLIST();
		      build_polygon (plist + pfree++, n4, v4, line4, style4,
				     lp, -1L, -1L, id++, 0);
		      inc_id = TRUE;
		    }
		  /* if (inc_id)
		    id++; */
		  vert_free++;
#else  /* FOUR_TRIANGLES */
		  n1 = 3;
		  v1 = (long *) alloc ((unsigned long) sizeof (long) * n1, "hidden v1 for line");
		  v1[0] = vert_free + row_offset;
		  v1[1] = vert_free;
		  v1[2] = vert_free + 1;
		  line1 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v1,c1);
		  style1 = (c1 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border1 = (i == 0 || ncrv == 0);
		  n2 = 3;
		  v2 = (long *) alloc ((unsigned long) sizeof (long) * n2, "hidden v2 for line");
		  /* HBB 961124: switched order, for clarity: */
		  v2[0] = vert_free + 1;
		  v2[1] = vert_free + row_offset + 1;
		  v2[2] = vert_free + row_offset;
		  line2 = TRIANGLE_LINES_TO_DRAW;
		  GET_SIDE(v2,c2);
		  /* HBB 961124: changed according to order change above */
		  style2 = (c2 >= 0) ? above : below;
		  /* Is this polygon at the border of the surface? */
		  border2 = (i >= icrvs->p_count - 2 || ncrv >= ncrv1 - 2);

		  if ((c1 || border1) &&
		      reduce_polygon (&n1, &v1, &line1, 3))
		    {
		      if ((c2 || border2) &&
			  reduce_polygon (&n2, &v2, &line2, 3))
			{
			  CHECK_PLIST_2();
			  /* HBB 961201: link these two fragments */
#ifdef HANDLE_UNDEFINED
/* These two will need special handling, to ensure the links from one
 * to the other are only set up when *both* polygons are valid */
			  {
			    int r1, r2; /* results */

			    r1 = maybe_build_polygon (plist + pfree, n1, v1,
						      line1, style1, lp, -1L,
						      -1L, id, 0);
			    r2 = maybe_build_polygon (plist + pfree+r1, n2, v2,
						      line2, style2, lp, -1L,
						      -1L, id++, 0);
			    if (r1 && r2) {
			      plist[pfree].next_frag=pfree+1;
			      plist[pfree+1].next_frag=pfree;
			    }
			    pfree += r1 + r2;
			  }
#else
			  maybe_build_polygon (plist + pfree, n1, v1,
					       line1, style1, lp, -1L,
					       pfree+1, id, 0);
			  maybe_build_polygon (plist + pfree+1, n2, v2,
					       line2, style2, lp, -1L,
					       pfree, id++, 0);
			  pfree+=2;
#endif
			}
		      else
			{
			  if (c2 || border2)
			    SETBIT (line1, n1 - 1, 1);
			    CHECK_PLIST();
			  pfree += maybe_build_polygon (plist + pfree, n1, v1, line1, style1,
					 lp, -1L, -1L, id++, 0);
			}
		    }
		  else
		    {
		      if (c1 || border1)
			SETBIT (line2, n2 - 1, 1);
		      if ((c2 || border2 || c1 || border1) &&
			  reduce_polygon (&n2, &v2, &line2, 2))
			  {
			  	CHECK_PLIST();
			pfree += maybe_build_polygon (plist + pfree, n2, v2, line2, style2,
					 lp, -1L, -1L, id++, 0);
			  }
		    }
#endif /* FOUR_TRIANGLES */
		}
	      vert_free++;
	      break;
	    case DOTS:
	      v1 = (long *) alloc ((unsigned long) sizeof (long) * 1, "hidden v1 for dots");
	      v1[0] = vert_free++;
	      CHECK_PLIST();
	      pfree += maybe_build_polygon (plist + pfree, 1, v1, 1L, above, lp, -1L, -1L, id++, 0);
	      break;
	    case BOXERROR:	/* handle as POINTSTYLE */
            case BOXXYERROR:
	    case XERRORBARS:	/* handle as POINTSTYLE */
	    case YERRORBARS:
            case XYERRORBARS:
	    case CANDLESTICKS:      /* HBB: these as well */
            case FINANCEBARS:
	    case POINTSTYLE:
            case VECTOR:
	      v1 = (long *) alloc ((unsigned long) sizeof (long) * 1, "hidden v1 for point");
	      v1[0] = vert_free++;
	      CHECK_PLIST();
	      pfree += maybe_build_polygon (plist + pfree, 1, v1, 0L, above, lp, -1L, -1L, id++, 0);
	      break;
	    case BOXES:	/* handle as IMPULSES */
	    case IMPULSES:
	      n1 = 2;
	      v1 = (long *) alloc ((unsigned long) sizeof (long) * n1, "hidden v1 for impulse");
	      v1[0] = vert_free++;
	      v1[1] = vert_free++;
	      line1 = 2L;
              (void)reduce_polygon (&n1, &v1, &line1, 1);
	      CHECK_PLIST();
	      pfree += maybe_build_polygon (plist + pfree, n1, v1, line1, above, lp, -1L, -1L, id++, 0);
	      break;
	    }
    }
#if SENTINEL /* HBB 961201: add sentinel, may speed up in_front and draw loops */
  vlist[vert_free].x = 1e3;
  vlist[vert_free].y = 1e3;
  vlist[vert_free].z = 1e3;	/* put this vertex *way* behind the view volume */
  vlist[vert_free].style = 0;
  v1 = (long *) alloc ((unsigned long) sizeof (long) * 1, "hidden sentinel vertex");
  v1[0] = vert_free++;
  CHECK_PLIST();
  pfree += maybe_build_polygon (plist + (Sentinel = pfree), 1, v1, 0L, above, lp, -1L, -1L, id++, 0);
#endif
}

static int 
compare_by_zmax (p1, p2)
     const void *p1, *p2;
{
  return (SIGNOF (plist[*(const long *)p2].zmax - plist[*(const long *)p1].zmax));
}

static void 
sort_by_zmax ()
     /* and build the list (return_value = start of list) */
{
  long *sortarray, i;
  struct Polygon *this;
  sortarray = (long *) alloc ((unsigned long) sizeof (long) * pfree, "hidden sortarray");
  for (i = 0; i < pfree; i++)
    sortarray[i] = i;
  qsort (sortarray, (size_t) pfree, sizeof (long), compare_by_zmax);
  this = plist + sortarray[0];
  for (i = 1; i < pfree; i++)
    {
      this->next = sortarray[i];
      this = plist + sortarray[i];
    }
  this->next = -1L;
  pfirst = sortarray[0];
  free (sortarray);
}


/* HBB: try if converting this code to unsigned int (from signed shorts)
 *  fixes any of the remaining bugs. In the same motion, remove
 *  hardcoded sizeof(short)=2 (09.10.1996) */

#define LASTBITS (USHRT_BITS -1) /* ????? */
static int 
obscured (p)
     /* is p obscured by already drawn polygons? (only a simple minimax-test) */
     struct Polygon *p;
{
  int l_xmin, l_xmax, l_ymin, l_ymax; /* HBB 961110: avoid shadowing external names */
  t_pnt mask1, mask2;
  long indx1, indx2, k, m;
  tp_pnt cpnt;
  /* build the minimax-box */
  l_xmin = (p->xmin * xscaler) + xmiddle;
  l_xmax = (p->xmax * xscaler) + xmiddle;
  l_ymin = (p->ymin * yscaler) + ymiddle;
  l_ymax = (p->ymax * yscaler) + ymiddle;
  if (l_xmin < xleft)
    l_xmin = xleft;
  if (l_xmax > xright)
    l_xmax = xright;
  if (l_ymin < ybot)
    l_ymin = ybot;
  if (l_ymax > ytop)
    l_ymax = ytop;
  if (l_xmin > l_xmax || l_ymin > l_ymax)
    return 1;			/* not viewable */
  l_ymin = YREDUCE (l_ymin) - YREDUCE(ybot);
  l_ymax = YREDUCE (l_ymax) - YREDUCE(ybot);
  l_xmin = XREDUCE (l_xmin) - XREDUCE(xleft);
  l_xmax = XREDUCE (l_xmax) - XREDUCE(xleft);
  /* Now check bitmap */
  indx1 = l_ymin / PNT_BITS;
  indx2 = l_ymax / PNT_BITS;
  mask1 = PNT_MAX << (((unsigned)l_ymin) % PNT_BITS);
  mask2 = PNT_MAX >> ((~((unsigned)l_ymax)) % PNT_BITS);
  /* HBB: lclint wanted this: */
  assert(pnt != 0);
  for (m = l_xmin; m <= l_xmax; m++)
    {
      if (pnt[m] == 0)
	return 0;		/* not obscured */
      cpnt = pnt[m] + indx1;
      if (indx1 == indx2)
        {
          if (~(*cpnt) & mask1 & mask2)
	    return 0;
	}
      else
	{
	  if (~(*cpnt++) & mask1)
	    return 0;
          for (k=indx1+1; k<indx2; k++)
            if ((*cpnt++) != PNT_MAX)
              return 0;
          if (~(*cpnt++) & mask2)
	    return 0;
	}
    }
  return 1;
}


void draw_line_hidden(x1, y1, x2, y2)
  unsigned int x1, y1, x2, y2;
{
  register struct termentry *t = term;
  TBOOLEAN flag;
  register int xv, yv, errx, erry, err;
  register unsigned int xvr, yvr;
  int unsigned xve, yve;
  register int dy, nstep=0, dyr;
  int i;

  if (x1 > x2){
    xvr = x2;
    yvr = y2;
    xve = x1;
    yve = y1;
  } else {
    xvr = x1;
    yvr = y1;
    xve = x2;
    yve = y2;
  };
  errx = XREDUCE(xve) - XREDUCE(xvr);
  erry = YREDUCE(yve) - YREDUCE(yvr);
  dy = (erry > 0 ? 1 : -1);
  dyr = dy*yfact;
  switch (dy){
  case 1:
    nstep = errx + erry;
    errx = -errx;
    break;
  case -1:
    nstep = errx - erry;
    errx = -errx;
    erry = -erry;
    break;
  };
  err = errx + erry;
  errx <<= 1;
  erry <<= 1;
  xv = XREDUCE(xvr) - XREDUCE(xleft);
  yv = YREDUCE(yvr) - YREDUCE(ybot);
  (*t->move)(xvr,yvr);
  flag = !IS_UNSET(xv,yv);
  if(!hidden_no_update){ /* Check first point */
    assert(ymax_hl!=0);
    assert(ymin_hl!=0);
    if (xv < xmin_hl) xmin_hl = xv;
    if (xv > xmax_hl) xmax_hl = xv;
    if (yv > ymax_hl[xv]) ymax_hl[xv] = yv;
    if (yv < ymin_hl[xv]) ymin_hl[xv] = yv;
  };
  for (i=0;i<nstep;i++){
    if (err < 0){
      xv ++;
      xvr += xfact;
      err += erry;
    } else {
      yv += dy;
      yvr += dyr;
      err += errx;
    };
    if( IS_UNSET(xv,yv)){
      if (flag)
	{
	  (*t->move)(xvr,yvr);
	  flag = FALSE;
	};
    } else {
      if (!flag)
	{
	  (*t->vector)(xvr,yvr);
	  flag = TRUE;
	};
    };
    if(!hidden_no_update){
      /* HBB 961110: lclint wanted these: */
      assert(ymax_hl!=0);
      assert(ymin_hl!=0);
      if (xv < xmin_hl) xmin_hl = xv;
      if (xv > xmax_hl) xmax_hl = xv;
      if (yv > ymax_hl[xv]) ymax_hl[xv] = yv;
      if (yv < ymin_hl[xv]) ymin_hl[xv] = yv;
    };
  };
  if (!flag)
    (*t->vector)(xve, yve);
  return;
}

GP_INLINE static int
xy_overlap (a, b)
     /* Do a and b overlap in x or y (minimax test) */
     struct Polygon *a, *b;
{
#if TEST_GRIDCHECK
  /* First, check by comparing the extent bit patterns: */
  if (! ((a->xextent & b->xextent) && (a->yextent & b->yextent)) )
    return 0;
#endif
  return  ((int)( GE(b->xmax, a->xmin) && GE(a->xmax, b->xmin)
                  && GE(b->ymax, a->ymin) && GE(a->ymax, b->ymin)));
}


static void
get_plane (p, a, b, c, d)
     struct Polygon *p;
     double *a, *b, *c, *d;
{
  int i;
  struct Vertex *v1, *v2;
  double x, y, z, s;
  if (p->n == 1)
    {
      *a = 0.0;
      *b = 0.0;
      *c = 1.0;
      *d = -vlist[p->vertex[0]].z;
      return;
    }
  v1 = vlist + p->vertex[p->n - 1];
  v2 = vlist + p->vertex[0];
  *a = (v1->y - v2->y) * (v1->z + v2->z);
  *b = (v1->z - v2->z) * (v1->x + v2->x);
  *c = (v1->x - v2->x) * (v1->y + v2->y);
  for (i = 0; i < p->n - 1; i++)
    {
      v1 = vlist + p->vertex[i];
      v2 = vlist + p->vertex[i + 1];
      *a += (v1->y - v2->y) * (v1->z + v2->z);
      *b += (v1->z - v2->z) * (v1->x + v2->x);
      *c += (v1->x - v2->x) * (v1->y + v2->y);
    }
  s = sqrt( *a* *a + *b * *b + *c * *c);
  if (GE (0.0, s))
    {                           /* => s==0 => the vertices are in one line */
      v1 = vlist + p->vertex[0];
      for (i = 1; i < p->n; i++)
	{
          v2 = vlist + p->vertex[i];
	  if (!V_EQUAL (v1, v2))
	    break;
	}
      /* (x,y,z) is l.u. from <v1, v2> */
      x = v1->x;
      y = v1->y;
      z = v1->z;
      if (EQ (y, v2->y))
	y += 1.0;
      else
	x += 1.0;
      /* build a vector that is orthogonal to the line of the polygon */
      *a = v1->y * (v2->z - z) + v2->y * (z - v1->z) + y * (v1->z - v2->z);
      *b = v1->z * (v2->x - x) + v2->z * (x - v1->x) + z * (v1->x - v2->x);
      *c = v1->x * (v2->y - y) + v2->x * (y - v1->y) + x * (v1->y - v2->y);
      s = sqrt(*a * *a + *b * *b + *c * *c);
    }
  if (*c < 0.0) /* ensure that normalized c is > 0 */
    s *= -1.0;			/* The exact relation, because c can be very small */
  *a /= s;
  *b /= s;
  *c /= s;
  *d = -*a * v1->x - *b * v1->y - *c * v1->z;
  return;
}


static t_poly_plane_intersect
polygon_plane_intersection(p, a, b, c, d)
     struct Polygon *p;
     double a, b, c, d;
{
  int i, sign, max_sign, min_sign;
  struct Vertex *v;

  CHECK_POINTER(plist,p);
  
  v = vlist + p->vertex[0];
  max_sign = min_sign = SIGNOF (a * v->x + b * v->y + c * v->z + d);
  for (i=1; i<p->n; i++) {
          v = vlist + p->vertex[i];
    sign=SIGNOF (a * v->x + b * v->y + c * v->z + d);
    if (sign > max_sign)
      max_sign=sign;
    else if (sign < min_sign)
      min_sign=sign;
	}

  /* Yes, this is a bit tricky, but it's simpler for the computer... */
  if (min_sign==-1) {
    if (max_sign==1)
      return (intersects);
    else
      return behind;
  } else {
    if ((max_sign==0) && (min_sign==0))
      return (inside);
    else
      return infront;
    }
}


/* full xy-overlap test (support routines first) */

/* What do negative return values mean?
   It is allowed, that the 2 polygons touch themselves in one point.
   There are 2 possibilities of this case:
   (A) A vertex of the one polygon is on an edge of the other
   (B) The two polygons have a vertex together.
   In case (A) the algorithm finds 2 edges, wich touches an edge of the
   other polygon. In case (B) the algorithm finds four pairs of edges.
   I handle both cases with negative return values:
   Case (A) returns -2, and case (B) returns -1.
   So I can say, if the sum of negative return values goes greater than 4
   (absolutly), there must be more than one touch point. So the 
   polygons must overlap. */

/* some variables, for keeping track of minima and maxima across
 * all these routines */

static double m1x, M1x, m1y, M1y, m2x, M2x, m2y, M2y;

#define MINIMAX  (GE(M2x,m1x) && GE(M1x,m2x) && GE(M2y,m1y) && GE(M1y,m2y))


/* Does the edge [v1,v2] intersect edge [v3, v4] ?
 * This is for non-vertical [v1,v2]
 */
static int 
intersect (v1, v2, v3, v4)
     struct Vertex *v1, *v2, *v3, *v4;
{
  double m1, m2, t1, t2, x, y, minx, maxx;

  m1 = (v2->y - v1->y) / (v2->x - v1->x);
  t1 = v1->y - m1 * v1->x;

  /* if [v3,v4] vertical: */
  if (EQ (v3->x, v4->x))
    {
      y = v3->x * m1 + t1;
      if (GR (m2x, m1x) && GR (M1x, m2x))
	{
	  if (GR (y, m2y) && GR (M2y, y))
	    return 1;
	  if (EQ (y, m2y) || EQ (y, M2y))
	    return -2;
	  return 0;
	}
      /* m2x==m1x || m2x==M1x */
      if (GR (y, m2y) && GR (M2y, y))
	return -2;
      if (EQ (y, m2y) || EQ (y, M2y))
	return -1;
      return 0;
    }

  /* [v3,v4] not vertical */
  m2 = (v4->y - v3->y) / (v4->x - v3->x);
  t2 = v3->y - m2 * v3->x;
  if (!SIGNOF (m1 - m2))  /* if edges are parallel: */
    {
      x = m1 * v3->x + t1 - v3->y;
      if (!EQ (m1 * v3->x + t1 - v3->y, 0.0))
	return 0;
      if (GR (M2x, m1x) && GR (M1x, m2x))
	return 1;
      return -1;                /* the edges have a common vertex */
    }
  x = (t2 - t1) / (m1 - m2);
  minx = GPMAX (m1x, m2x);
  maxx = GPMIN (M1x, M2x);
  if (GR (x, minx) && GR (maxx, x))
    return 1;
  if (GR (minx, x) || GR (x, maxx))
    return 0;
  if ((EQ (x, m1x) || EQ (x, M1x)) && (EQ (x, m1x) || EQ (x, M1x)))
    return -1;
  return -2;
}

/* Does the edge [v1,v2] intersect edge [v3, v4] ?
 * This is for vertical [v1,v2]
 */
static int 
v_intersect (v1, v2, v3, v4)
     struct Vertex *v1, *v2, *v3, *v4;
{
  double y;

  /* if [v3,v4] is vertical, too: */
  /* already known: rectangles do overlap, because MINIMAX was true */
  if (EQ (v3->x, v4->x))
    return (GR (M2y, m1y) && GR (M1y, m2y)) ? 1 : -1;

  /*  [v3,v4] not vertical */
  y = v3->y + (v1->x - v3->x) * (v4->y - v3->y) / (v4->x - v3->x);
  if (GR (m1x, m2x) && GR (M2x, m1x))
    {
      if (GR (y, m1y) && GR (M1y, y))
	return 1;
      if (EQ (y, m1y) || EQ (y, M1y))
	return -2;
      return 0;
    }
  /* m1x==m2x || m1x==M2x */
  if (GR (y, m1y) && GR (M1y, y))
    return -2;
  if (EQ (y, m1y) || EQ (y, M1y))
    return -1;
  return 0;
}

#define UPD_MINMAX(v1,v2,npar) do {    \
  if (v1->x< v2->x)                 \
    CONCAT3(m,npar,x) =v1->x, CONCAT3(M,npar,x) =v2->x;   \
  else                              \
    CONCAT3(m,npar,x) =v2->x, CONCAT3(M,npar,x) =v1->x;   \
  if (v1->y< v2->y)                 \
    CONCAT3(m,npar,y)=v1->y, CONCAT3(M,npar,y)=v2->y;   \
  else                              \
    CONCAT3(m,npar,y)=v2->y, CONCAT3(M,npar,y)=v1->y;   \
} while (0)

/* does the edge [v1,v2] intersect polygon p? */
static int 
intersect_polygon (v1, v2, p)
     struct Vertex *v1, *v2;
     struct Polygon *p;
{
  struct Vertex *v3, *v4;
  int i, s, t = 0;
  int (*which_intersect) __PROTO((struct Vertex *v1, struct Vertex *v2,
			      struct Vertex *v3, struct Vertex *v4))
    = intersect;

  /* Is [v1,v2] vertical? If, use v_intersect() */
  if (EQ (v1->x, v2->x))
    which_intersect=v_intersect;

  UPD_MINMAX(v1,v2,1);

  /* test first edge of polygon p */
  v3 = vlist + p->vertex[p->n - 1];
  v4 = vlist + p->vertex[0];
  UPD_MINMAX(v3,v4,2);


    if (MINIMAX)
      {
        s = which_intersect (v1, v2, v3, v4);
        if (s == 1 || (s < 0 && (t += s) < -4))
          return 1;
      }
    /* and the other edges... */
    for (i = 0; i < p->n - 1; i++)
      {
        v3 = vlist + p->vertex[i];
        v4 = vlist + p->vertex[i + 1];
        UPD_MINMAX(v3,v4,2);
        if (!MINIMAX)
          continue;
        s = which_intersect (v1, v2, v3, v4);
        if (s == 1 || (s < 0 && (t += s) < -4))
          return 1;
      }
    return t;
  }

/* OK, now here comes the 'real' polygon intersection routine:
 * Do a and b overlap in x or y (full test):
 * Do edges intersect, do the polygons touch in two points,
 * or is a vertex of one polygon inside the other polygon? */

static int 
full_xy_overlap (a, b)
     struct Polygon *a, *b;
{
  struct Vertex *v1, *v2, v;
  int i, s, t = 0;

  if (a->n < 2 || b->n < 2)
    return 0;
  v1 = vlist + a->vertex[a->n - 1];
  v2 = vlist + a->vertex[0];
  s = intersect_polygon (v1, v2, b);
  if (s == 1 || (s < 0 && (t += s) < -4))
    return 1;
  for (i = 0; i < a->n - 1; i++)
    {
      v1 = vlist + a->vertex[i];
      v2 = vlist + a->vertex[i + 1];
      s = intersect_polygon (v1, v2, b);
      if (s == 1 || (s < 0 && (t += s) < -4))
	return 1;
    }
  /* No edges intersect. Is one polygon inside the other? */
  /* The  inner polygon has the greater minx */
  if (a->xmin < b->xmin)
    {
      struct Polygon *temp = a;
      a = b;
      b = temp;
    }
  /* Now, a is the inner polygon */
  for (i = 0; i < a->n; i++)
    {
      v1 = vlist + a->vertex[i];
      /* HBB: lclint seems to have found a problem here: v wasn't
       * fully defined when passed to intersect_polygon() */
      v = *v1;
      v.x = -1.1;
      s = intersect_polygon (v1, &v, b);
      if (s == 0)
	return 0;		/* a is outside polygon b */
      v.x = 1.1;
      if (s == 1)
	{
	  s = intersect_polygon (v1, &v, b);
	  if (s == 0)
	    return 0;
	  if (s == 1)
	    return 1;
	}
      else if (intersect_polygon (v1, &v, b) == 0)
	return 0;
    }
  print_polygon(a, "a");
  print_polygon(b, "b");
  graph_error ("Logic Error in full_xy_overlap");
  return -1; /* HBB: shut up gcc -Wall */
}


/* Helper routine for split_polygon_by_plane */
static long
build_new_vertex (V1, V2, w)
     long V1, V2;               /* the vertices, between which a new vertex is demanded */
     double w;			/* information about where between V1 and V2 it should be */
{
  long V;
  struct Vertex *v, *v1, *v2;
  if (EQ (w, 0.0))
    return V1;
  if (EQ (w, 1.0))
    return V2;
  /* We need a new Vertex */
  if (vert_free == nvert) /* Extend vlist, if necessary */
    vlist = (struct Vertex*) ralloc(vlist,
      (unsigned long)sizeof(struct Vertex)*(nvert+=10L), "hidden vlist");
  V = vert_free++;
  v = vlist + V;
  v1 = vlist + V1;
  v2 = vlist + V2;
  v->x = (v2->x - v1->x) * w + v1->x;
  v->y = (v2->y - v1->y) * w + v1->y;
  v->z = (v2->z - v1->z) * w + v1->z;
  v->style = -1;
  return V;
}


/* Splits polygon p by the plane represented by its equation
 * coeffecients a to d.
 * return-value: part of the polygon, that is in front/back of plane
 * (Distinction necessary to ensure the ordering of polygons in
 * the plist stays intact)
 * Caution: plist and vlist can change their location!!!
 * If a point is in plane, it comes to the behind - part
 * (HBB: that may well have changed, as I cut at the 'in plane'
 * mechanisms heavily)
 */

static long 
split_polygon_by_plane (P, a, b, c, d, f)
     long P;			/* Polygon as index on plist */
     double a, b, c, d;
     TBOOLEAN f;			/* return value = Front(1) or Back(0) */
{
  int i, j;
  struct Polygon *p = plist + P;
  struct Vertex *v;
  int snew, stest;
  int in_plane;			/* what is about points in plane? */
  int cross1, cross2;           /* first vertices, after p crossed the plane */
  double a1=0.0, b1, a2=0.0, b2;        /* parameters of the crosses */
  long Front;			/* the new Polygon */
  int n1, n2;
  long *v1, *v2;
  long line1, line2;
  long next_frag_temp;
      

  CHECK_POINTER(plist, p);
  
  in_plane = (EQ (c, 0.0) && f) ? 1 : -1;
  /* first vertex */
  v = vlist + p->vertex[0];

  CHECK_POINTER(vlist, v);
  
  b1 = a * v->x + b * v->y + c * v->z + d;
  stest = SIGNOF (b1);

  /* find first vertex that is on the other side of the plane */
  for (cross1 = 1, snew = stest; snew == stest && cross1 < p->n; cross1++)
    {
      a1 = b1;
      v = vlist + p->vertex[cross1];
      CHECK_POINTER(vlist,v);
      b1 = a * v->x + b * v->y + c * v->z + d;
      snew = SIGNOF (b1);
    }
  if (snew == stest)
/*HBB: this is possibly not an error in split_polygon, it's
 * just not possible to split this polygon by this plane. I.e.,
 * the error is in the caller!
 */
    {
      fprintf(stderr, "split_poly failed, polygon nr. %ld\n", P);
      return (-1); /* return 'unsplittable' */
    }
  cross1--; /* now, it's the last one on 'this' side */
  /* first vertex that is on the first side again */
  for (b2 = b1, cross2 = cross1 + 1;
       snew != stest && cross2 < p->n; cross2++)
    {
      a2 = b2;
      v = vlist + p->vertex[cross2];
      CHECK_POINTER(vlist,v);
      b2 = a * v->x + b * v->y + c * v->z + d;
      snew = SIGNOF (b2);
    }
  if (snew != stest)
    {				/* only p->vertex[0] is on 'this' side */
      a2 = b2;
      v = vlist + p->vertex[0];
      CHECK_POINTER(vlist,v);
      b2 = a * v->x + b * v->y + c * v->z + d;
    }
  else
    cross2--; /* now it's the last one on 'the other' side */

  /* We need two new polygons instead of the old one: */
  n1 = p->n - cross2 + cross1 + 2;
  n2 = cross2 - cross1 + 2;
  v1 = (long *) alloc ((unsigned long) sizeof (long) * n1, "hidden v1 for two new poly");
  v2 = (long *) alloc ((unsigned long) sizeof (long) * n2, "hidden v2 for two new poly");
  line1 = line2 = 0L;
  v1[0] = v2[n2 - 1] =
    build_new_vertex (p->vertex[cross2 - 1],
                  p->vertex[(cross2 < p->n) ? cross2 : 0], a2 / (a2 - b2));
  v2[0] = v1[n1 - 1] =
    build_new_vertex (p->vertex[cross1 - 1], p->vertex[cross1], a1 / (a1 - b1));
  if (p->line & (1 << (cross1 - 1)))
    {
      line1 |= 1L << (n1 - 2);
      line2 |= 1L;
    }
  if (p->line & (1L << (cross2 - 1)))
    {
      line1 |= 1L;
      line2 |= 1L << (n2 - 2);
    }
  for (i = cross2, j = 1; i < p->n;)
    {
      if (p->line & (1L << i))
	line1 |= 1L << j;
      v1[j++] = p->vertex[i++];
    }
  for (i = 0; i < cross1 - 1;)
    {
      if (p->line & (1L << i))
	line1 |= 1L << j;
      v1[j++] = p->vertex[i++];
    }
  v1[j++] = p->vertex[i++];
  for (j = 1; i < cross2 - 1;)
    {
      if (p->line & (1L << i))
	line2 |= 1L << j;
      v2[j++] = p->vertex[i++];
    }
  v2[j++] = p->vertex[i];
  free (p->vertex);
  p->vertex = 0;
  if (!reduce_polygon (&n1, &v1, &line1, 1) ||
      !reduce_polygon (&n2, &v2, &line2, 1))
    graph_error ("Logic Error 2 in split_polygon");

  /* Build the 2 new polygons : we are reusing one + making one new */
  CHECK_PLIST_EXTRA(p=plist+P);
  Front = pfree++;

  if ((next_frag_temp = p->next_frag) <0) 
    next_frag_temp = P; /* First split of this polygon at all */
      
  /* HBB 961110: lclint sayd == shouldn't be used on Boolean's */
  if ((f && (stest < 0)) || ((! f) && !(stest<0)))
	{
      build_polygon (plist + P, n1, v1, line1, p->style, p->lp, p->next, Front, p->id, p->tested);
      build_polygon (plist + Front, n2, v2, line2, p->style, p->lp, Sentinel, next_frag_temp, p->id, -1);
	}
      else
	{
      build_polygon (plist + P, n2, v2, line2, p->style, p->lp, p->next, Front, p->id, p->tested);
      build_polygon (plist + Front, n1, v1, line1, p->style, p->lp, Sentinel, next_frag_temp, p->id, -1);
    }
  return Front;
}

/* HBB: these pieces of code are found repeatedly in in_front(), so
 * I put them into macros
 * Note: can't use the 'do {...} while (0)' method for
 * these: 'continue' wouldn't work any more.
 */
#define PUT_P_IN_FRONT_TEST(new_tested) {\
  plist[Plast].next = p->next; \
  p->next = Test; \
  p->tested = new_tested; \
  if (Insert >= 0) \
    plist[Insert].next = P; \
  else \
    pfirst = P; \
  Insert = P; \
  P = Plast; \
  p = plist + P; \
  continue; \
}

#define SPLIT_TEST_BY_P {\
  long Back = split_polygon_by_plane (Test, pa, pb, pc, pd, 0); \
  if (Back >0) { \
    p = plist + P; \
    test = plist + Test;  /* plist can change */ \
    plist[Back].next = p->next; \
    p->next = Back; \
    P = Back; \
    p = plist + P; \
    zmin = test->zmin;  /* the new z-value */ \
  } else { \
    fprintf(stderr, "Failed to split test (%ld) by p (%ld)\n", Test, P); \
    graph_error("Error in hidden line removal: couldn't split..."); \
  } \
  continue; \
}

#define SPLIT_P_BY_TEST {\
  long Front = split_polygon_by_plane (P, ta, tb, tc, td, 1);\
  if (Front >0) {\
    p = plist + P;\
    test = plist + Test;	/* plist can change */\
    plist[Front].next = Test;\
    if (Insert >= 0)\
      plist[Insert].next = Front;\
    else\
      pfirst = Front;\
    Insert = Front;\
  } else {\
    fprintf(stderr, "Failed to split p (%ld) by test(%ld), relations are %d, %d\n",\
	    P, Test, p_rel_tplane, t_rel_pplane);\
    print_polygon(test, "test");\
    print_polygon(p, "p");\
    fprintf(stderr, "\n");\
  }\
  continue; /* FIXME: should we continue nevertheless? */\
}


/* Is Test in front of the other polygons?
 * If not, polygons which are in front of test come between
 * Last and Test (I.e. to the 'front' of the plist)
 */
static int 
in_front (Last, Test)
     long Last, Test;
{
  struct Polygon *test = plist + Test, *p;
  long Insert, P, Plast;
  double zmin,			/* minimum z-value of Test */
    ta, tb, tc, td,		/* the plane of Test      */
    pa, pb, pc, pd;		/* the plane of a polygon */
  int loop = 0;

  CHECK_POINTER(plist,test);
  
  if (test->tested == -2)
    loop = 1;
  test->tested = 1;
  Insert = Last;
  /* minimal z-value of Test */
  zmin = test->zmin;
  /* The plane of the polygon Test */
  get_plane (test, &ta, &tb, &tc, &td);
  /* Compare Test with the following polygons, which overlap in z value */
  for (Plast = Test, p=test;
#if SENTINEL /* HBB 961201: sentineled version: */
       ((p=plist+(P=p->next))->zmax > zmin) || p->tested;
#else 
       ((P=p->next) >= 0) && (((p=plist+P)->zmax > zmin) || p->tested);
#endif
       Plast = P)
    {
      t_poly_plane_intersect p_rel_tplane, t_rel_pplane;

    	CHECK_POINTER(plist,p);
      if (!xy_overlap (test, p))
	continue;
      if (p->zmax <= zmin)
	continue;
#if 0 /* HBB 970220: this was causing the bug reported by F.Fredericksen... */
      if (p->id == test->id)
        continue;
#endif
      p_rel_tplane=polygon_plane_intersection(p, ta, tb, tc, td);
      if ((p_rel_tplane==behind) || (p_rel_tplane==inside))
	continue;
      get_plane (p, &pa, &pb, &pc, &pd);
      t_rel_pplane=polygon_plane_intersection(test, pa, pb, pc, pd);
      if ((t_rel_pplane==infront) || (t_rel_pplane==inside))
	continue;
      if (!full_xy_overlap (test, p))
	continue;

      /* p obscures test (at least, this *might* be happening */
      if (loop)
	{
	  /* if P isn't interesting for the loop, put P in front of Test */
          if ((p->tested != 1) ||
	      (p_rel_tplane==infront) ||
	      (t_rel_pplane==infront))
            PUT_P_IN_FRONT_TEST(-1); /* -1: p moved, but not yet tested */
	  /* else, split test */
          if (t_rel_pplane==intersects)
            SPLIT_TEST_BY_P;
	  if (p_rel_tplane==intersects)
	    SPLIT_P_BY_TEST;
          /* HBB: if we ever come through here, something went severely wrong */
          fprintf(stderr, "Failed: polygon %ld vs. %ld, relations are %d, %d\n", P, Test, p_rel_tplane, t_rel_pplane);
          print_polygon(test, "test");
          print_polygon(p, "p");
          fprintf(stderr, "\n");
          graph_error("Couldn't resolve a polygon overlapping pb. Go tell HBB...");
	}
      /* No loop: if it makes sense, put P in front of Test */
      if ((p->tested != 1) &&
          ((t_rel_pplane==behind) || (p_rel_tplane==infront)))
        PUT_P_IN_FRONT_TEST(-1); /* -1: p moved, but not yet tested */
      /* If possible, split P */
      if ((p->tested != 1) || (p_rel_tplane==intersects))
	SPLIT_P_BY_TEST;
      /* if possible, split Test */
      if (t_rel_pplane==intersects)
        SPLIT_TEST_BY_P;
      /* else, we have a loop: mark P as loop and put it in front of Test */
      PUT_P_IN_FRONT_TEST(-2); /* -2: p is in a loop */
    }
  return (int)(Insert == Last);
}


/* Drawing the polygons */

GP_INLINE static TBOOLEAN
hl_buffer_set (xv, yv)
     int xv, yv;
{
  struct Cross *c;
  /*HBB 961110: lclint wanted this: */
  assert (hl_buffer !=0);
  for (c = hl_buffer[xv]; c != NULL; c = c->next)
    if (c->a <= yv && c->b >= yv) {
      return TRUE;
    }
  return FALSE; 
}

/* HBB 961201: new var's, to speed up free()ing hl_buffer later */
static int hl_buff_xmin, hl_buff_xmax;

/* HBB 961124: new routine. All this occured twice in
 * draw_clip_line_buffer */
/* Store a line crossing the x interval around xv between y=ya and
 * y=yb in the hl_buffer */
GP_INLINE static void
update_hl_buffer_column(xv, ya, yb) 
     int xv, ya, yb;
{
  struct Cross **cross, *cross2;

  /* First, ensure that ya <= yb */
  if (ya > yb)
	    {
      int y_temp = yb;
	      yb = ya;
      ya = y_temp;
	    }
  /* loop over all previous crossings at this x-value */
	  for (cross = hl_buffer + xv; 1; cross = &(*cross)->next)
	    {
	      if (*cross == NULL)
	{ /* first or new highest crossing at this x-value */
		  *cross = (struct Cross *) alloc ((unsigned long) sizeof (struct Cross), "hidden cross");
		  (*cross)->a = ya;
		  (*cross)->b = yb;
		  (*cross)->next = NULL;
	  /* HBB 961201: keep track of x-range of hl_buffer, to speedup free()ing it */
	  if (xv < hl_buff_xmin)
	    hl_buff_xmin = xv;
	  if (xv > hl_buff_xmax)
	    hl_buff_xmax = xv;
		  break;
		}
	      if (yb < (*cross)->a - 1)
	{ /* crossing below 'cross', create new entry before 'cross' */
		  cross2 = *cross;
		  *cross = (struct Cross *) alloc ((unsigned long) sizeof (struct Cross), "hidden cross2");
		  (*cross)->a = ya;
		  (*cross)->b = yb;
		  (*cross)->next = cross2;
		  break;
		}
	      else if (ya <= (*cross)->b + 1)
	{ /* crossing overlaps or covers 'cross' */
		  if (ya < (*cross)->a)
		    (*cross)->a = ya;
		  if (yb > (*cross)->b)
		    {
		      if ((*cross)->next && (*cross)->next->a <= yb)
		{ /* crossing spans all the way up to 'cross->next' so
		   * unite them */
			  cross2 = (*cross)->next;
			  (*cross)->b = cross2->b;
			  (*cross)->next = cross2->next;
			  free (cross2);
			}
		      else
			(*cross)->b = yb;
		    }
		  break;
		}
	    }
  return;
	}


static void
draw_clip_line_buffer (x1, y1, x2, y2)
     int x1, y1, x2, y2;
     /* Draw a line in the hl_buffer */
	{
  register int xv, yv, errx, erry, err;
  register int dy, nstep;
  register int ya;
  int i;

  if (!clip_line (&x1, &y1, &x2, &y2)) {
    /*printf("dcl_buffer: clipped away!\n");*/
    return;
    }
  if (x1 > x2)
    {
      errx = XREDUCE (x1) - XREDUCE (x2);
      erry = YREDUCE (y1) - YREDUCE (y2);
      xv = XREDUCE (x2) - XREDUCE (xleft);
      yv = YREDUCE (y2) - YREDUCE (ybot);
    }
  else
	{
      errx = XREDUCE (x2) - XREDUCE (x1);
      erry = YREDUCE (y2) - YREDUCE (y1);
      xv = XREDUCE (x1) - XREDUCE (xleft);
      yv = YREDUCE (y1) - YREDUCE (ybot);
    };
  if (erry > 0)
    dy = 1;
  else
	{
      dy = -1;
      erry = -erry;
	}
  nstep = errx + erry;
  err = -errx + erry;
  errx <<= 1;
  erry <<= 1;
  ya = yv;

  for (i = 0; i < nstep; i++)
	    {
      if (err < 0)
		{
	  update_hl_buffer_column(xv, ya, yv);
	  xv++;
	  ya = yv;
	  err += erry;
		}
	      else
	{
	  yv += dy;
	  err -= errx;
	}
    }
  (void)update_hl_buffer_column(xv, ya, yv);
  return;
}


/* HBB 961124: improve similarity of this routine with
 * draw_clip_line_buffer ()*/
/* HBB 961124: changed from 'virtual' to 'do_draw', for clarity (this
 * also affects the routines calling this one, so beware! */
/* HBB 961124: introduced checking code, to search for the 'holes in
 * the surface' bug */
/* Draw a line into the bitmap (**cpnt), and optionally also to the
 * terminal */
static void
draw_clip_line_update (x1, y1, x2, y2, do_draw)
     int x1, y1, x2, y2;
     TBOOLEAN do_draw; 
{
  /* HBB 961110: made flag a boolean variable, which needs some other changes below as well */
  TBOOLEAN flag;
  register struct termentry *t = term;
  register int xv, yv, errx, erry, err;
  register int xvr, yvr;
  int xve, yve;
  register int dy, nstep=0, dyr;
  int i;
  if (!clip_line (&x1, &y1, &x2, &y2)) {
    /*printf("dcl_update: clipped away!\n");*/
    return;
  }
  if (x1 > x2)
    {
      xvr = x2;
      yvr = y2;
      xve = x1;
      yve = y1;
    }
  else
    {
      xvr = x1;
      yvr = y1;
      xve = x2;
      yve = y2;
    }
  errx = XREDUCE (xve) - XREDUCE (xvr);
  erry = YREDUCE (yve) - YREDUCE (yvr);
  if (erry > 0)
    dy = 1;
  else
    {
      dy = -1;
      erry = -erry;
    }
  dyr = dy * yfact;
  nstep = errx + erry;
  err = -errx + erry; 
  errx <<= 1;
  erry <<= 1;
  xv = XREDUCE (xvr) - XREDUCE (xleft);
  yv = YREDUCE (yvr) - YREDUCE (ybot);
  (*t->move) ((unsigned int)xvr, (unsigned int)yvr);

  flag = !((IS_UNSET (xv, yv) && (do_draw || hl_buffer_set (xv, yv))));

  /* HBB 961110: lclint wanted these: */
  assert (ymin_hl !=0);
  assert (ymax_hl !=0);
  /* Check first point in hl-buffer */
  if (xv < xmin_hl) xmin_hl = xv;
  if (xv > xmax_hl) xmax_hl = xv;
  if (yv < ymin_hl[xv]) ymin_hl[xv] = yv;
  if (yv > ymax_hl[xv]) ymax_hl[xv] = yv;
  for (i = 0; i < nstep; i++)
    {
      if (err < 0)
	{
	  xv++;
	  xvr += xfact;
	  err += erry;
	}
      else
	{
	  yv += dy;
	  yvr += dyr;
	  err -= errx; 
	}
      if (IS_UNSET (xv, yv) && (do_draw || hl_buffer_set (xv, yv)))
	{
	  if (flag)
	    {
	      (*t->move) ((unsigned int)xvr, (unsigned int)yvr);
	      flag = FALSE;
	    }
	}
      else
	{
	  if (!flag)
	    {
	      (*t->vector) ((unsigned int)xvr, (unsigned int)yvr);
	      flag = TRUE;
	    };
	};
      if (xv < xmin_hl) xmin_hl = xv;
      if (xv > xmax_hl) xmax_hl = xv;
      if (yv < ymin_hl[xv]) ymin_hl[xv] = yv;
      if (yv > ymax_hl[xv]) ymax_hl[xv] = yv;
    };
  if (!flag) 
    (*t->vector) ((unsigned int)xve, (unsigned int)yve);
  return;
}

#define DRAW_VERTEX(v, x, y) do { \
   if ((v)->style>=0 &&                                            \
       !clip_point(x,y)  &&                                        \
       IS_UNSET(XREDUCE(x)-XREDUCE(xleft),YREDUCE(y)-YREDUCE(ybot))) \
     (*t->point)(x,y, v->style);                                   \
   (v)->style=-1;                                                  \
} while (0)

/* Two routine to emulate move/vector sequence using line drawing routine. */
static unsigned int move_pos_x, move_pos_y;

void clip_move(x,y)
unsigned int x,y;
{
    move_pos_x = x;
    move_pos_y = y;
}

void clip_vector(x,y)
unsigned int x,y;
{
    draw_clip_line(move_pos_x,move_pos_y, x, y);
    move_pos_x = x;
    move_pos_y = y;
}

GP_INLINE static void clip_vector_h(x,y)
int x,y;
     /* Draw a line on terminal and update bitmap */
{
  draw_clip_line_update(move_pos_x,move_pos_y, x, y, TRUE);
   move_pos_x = x;
   move_pos_y = y;
}
           

GP_INLINE static void clip_vector_virtual(x,y)
     int x,y;
     /* update bitmap, do not really draw the line */
{
  draw_clip_line_update(move_pos_x,move_pos_y, x, y, FALSE);
  move_pos_x = x;    
  move_pos_y = y;
}

GP_INLINE static void clip_vector_buffer(x,y)
     /* draw a line in the hl_buffer */
     int x,y;
{
  draw_clip_line_buffer(move_pos_x,move_pos_y, x, y);
  move_pos_x = x;    
  move_pos_y = y;
}

static void
draw (p)
     struct Polygon *p;
{
  struct Vertex *v;
  struct Polygon *q;
  long Q;
  coordval zmin;
  struct Cross *cross1, *cross2;
  int i;
  int x, y;			/* point in terminal coordinates */
  register struct termentry *t = term;
  t_pnt mask1, mask2;
  long int indx1, indx2, k;
  tp_pnt cpnt;

  xmin_hl = HLBUF_XLIM_MAX;	/* HBB 961124: parametrized this value */
  xmax_hl = 0;

  /* HBB 961201: store initial values for range of hl_buffer: */
  hl_buff_xmin = XREDUCE(xright) - XREDUCE(xleft);  
  hl_buff_xmax = 0;
  
  /* minimal z-value of p */
  zmin = p->zmin;
  /* Write the lines of all polygons with the same id as p in the hl_buffer */
  for (q=p;
       /* HBB 961201: use next_frag pointers to loop over fragments: */
       (Q=q->next_frag) >= 0 && (q=plist+Q) != p;
       )
    {
      if (q->id != p->id)
	continue;

      /* update zmin from new part of polygon */
      if (q->zmin < zmin)
        zmin = q->zmin;

      /* draw the lines of q into hl_buffer: */
      v = vlist + q->vertex[0];
      TERMCOORD (v, x, y);
      clip_move (x, y);
      for (i = 1; i < q->n; i++)
	{
          v = vlist + q->vertex[i];
	  TERMCOORD (v, x, y);
          if (q->line & (1L << (i - 1)))
	    clip_vector_buffer (x, y);
	  else
	    clip_move (x, y);
	}
      if (q->line & (1L << (i - 1)))
	{
          v = vlist + q->vertex[0];
	  TERMCOORD (v, x, y);
	  clip_vector_buffer (x, y);
	}
    }

  /* draw the lines of p */
#if STYLE_POINTER
  {
    struct lp_style_type lp = *(p->lp);

    lp.l_type = p->style;
    term_apply_lp_properties(&(lp));
  }
#else
  p->lp.l_type = p->style;
  term_apply_lp_properties(&(p->lp));
#endif

  /*print_polygon (p, "drawing"); */ /* HBB 961127: debugging FOUR_TRIANGLES */
  v = vlist + p->vertex[0];
  TERMCOORD (v, x, y);
  clip_move (x, y);
  DRAW_VERTEX (v, x, y);
  for (i = 1; i < p->n; i++)
    {
      v = vlist + p->vertex[i];
      TERMCOORD (v, x, y);
      if (p->line & (1L << (i - 1)))
	clip_vector_h (x, y);
      else
	clip_vector_virtual (x, y);
      DRAW_VERTEX (v, x, y);
    }
  TERMCOORD (vlist + p->vertex[0], x, y);
  if (p->line & (1L << (i - 1)))
    clip_vector_h (x, y);
  else
    clip_vector_virtual (x, y);


  /* reset the hl_buffer */
  /*HBB 961110: lclint wanted this: */
  assert (hl_buffer);
#if 0
  for (i = XREDUCE (xright) - XREDUCE (xleft); i >= 0; i--)
#else /* HBB 961201: use stored range, to speed this up: */
  for (i = hl_buff_xmin ; i<=hl_buff_xmax ; i++)
#endif
    {
      if (hl_buffer[i] == NULL)
	continue;
      for (cross1 = hl_buffer[i]; cross1 != NULL; cross1 = cross2)
	{
	  cross2 = cross1->next;
	  free (cross1);
	}
      hl_buffer[i] = NULL;
    }

  /* now mark the area as being filled in the bitmap. */
  if (xmin_hl < 0 || xmax_hl > XREDUCE (xright) - XREDUCE (xleft))
    graph_error ("Logic error #3 in hidden line");
  /* HBB 961110: lclint wanted these: */
  assert (ymin_hl !=0);
  assert (ymax_hl !=0);
  assert (pnt !=0); 
  if (xmin_hl < xmax_hl)
    for (i = xmin_hl; i <= xmax_hl; i++)
      {
        if (ymin_hl[i] == HLBUF_YLIM_MAX)
          graph_error ("Logic error #2 in hidden line");
	if (pnt[i] == 0)
	  {
            pnt[i] = (t_pnt *) alloc ((unsigned long)y_malloc, "hidden ymalloc");
            memset (pnt[i], 0, (size_t)y_malloc);
	  };
	if (ymin_hl[i] < 0 || ymax_hl[i] > YREDUCE (ytop) - YREDUCE (ybot))
          graph_error ("Logic error #1 in hidden line");
	/* this shift is wordsize dependent */
        indx1 = ymin_hl[i] / PNT_BITS;
        indx2 = ymax_hl[i] / PNT_BITS;
        mask1 = PNT_MAX << (((unsigned) ymin_hl[i]) % PNT_BITS);
        mask2 = PNT_MAX >> ((~((unsigned) ymax_hl[i])) % PNT_BITS);
	cpnt = pnt[i] + indx1;
	if (indx1 == indx2)
	  *cpnt |= (mask1 & mask2);
	else
	  {
	    *cpnt++ |= mask1;
            for (k=indx1+1; k<indx2; k++)
              *cpnt++ = PNT_MAX;
	    *cpnt |= mask2;
	  };
        ymin_hl[i] = HLBUF_YLIM_MAX;
	ymax_hl[i] = 0;
      };
}


void 
plot3d_hidden (plots, pcount)
     struct surface_points *plots;
     int pcount;
{
  long Last, This;
  long i;

  /* Initialize global variables */
  y_malloc = (2 + (YREDUCE (ytop) >> 4) - (YREDUCE (ybot) >> 4)) * sizeof (t_pnt);
  /* ymin_hl, ymax_hl: */
  i = sizeof (t_hlbuf_ylim) * (XREDUCE (xright) - XREDUCE (xleft) + 1);
  ymin_hl = (t_hlbuf_ylim *) alloc ((unsigned long) i, "hidden ymin_hl");
  ymax_hl = (t_hlbuf_ylim *) alloc ((unsigned long) i, "hidden ymax_hl");
  for (i = (XREDUCE (xright) - XREDUCE (xleft)); i >= 0; i--)
    {
      ymin_hl[i] = HLBUF_YLIM_MAX;
      ymax_hl[i] = 0;
    }
  /* hl_buffer: */
  i = sizeof (void *) * (XREDUCE (xright) - XREDUCE (xleft) + 1);
  hl_buffer = (struct Cross **) alloc (
      (unsigned long)(i*sizeof(struct Cross *)), "hidden hl_buffer");
  while (--i>=0)
    hl_buffer[i] = (struct Cross *) 0;

  init_polygons (plots, pcount);
  sort_by_zmax ();

  /* sort the polygons and draw them in one loop */
  Last = -1L;
  This = pfirst;
  /* Search first polygon, that can be drawn */
  while (Last == -1L && This >= 0L)
    {
      This = pfirst;
      if (obscured (plist + This))
	{
	  Last = This;
	  continue;
	}
      if (plist[This].tested != 1 && !in_front (Last, This))
	continue;
      draw (plist + This);
      Last = This;
    }
  /* Draw the other polygons */
#if SENTINEL
  for (This = plist[Last].next; This >= 0L && This != Sentinel; This = plist[Last].next)
#else
  for (This = plist[Last].next; This >= 0L; This = plist[Last].next)
#endif
    {
      if (obscured (plist + This))
	{
	  Last = This;
	  continue;
	}
      if (plist[This].tested != 1 && !in_front (Last, This))
	continue;
      draw (plist + This);
      Last = This;
    }

  /* Free memory */
  if (plist)
    {
      for (This = 0L; This < pfree; This++)
        free (plist[This].vertex);
      free (plist);
      plist = 0;
    }
  if (vlist)
    {
      free (vlist);
      vlist = 0;
    }
  if (ymin_hl)
    {
      free (ymin_hl);
      ymin_hl = 0;
    }
  if (ymax_hl)
    {
      free (ymax_hl);
      ymax_hl = 0;
    }
  if (hl_buffer)
    {
      free (hl_buffer);
      hl_buffer = 0;
    }
}
