extern void sc_help (void);
