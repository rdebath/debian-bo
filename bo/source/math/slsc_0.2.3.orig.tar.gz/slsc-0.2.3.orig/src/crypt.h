extern void creadfile (char *, int);
extern int cwritefile (char *, int, int, int, int);

