#include "machine.h"
#ifndef NO_GWM_LOG
#include "spy.c"
#endif /* !NO_GWM_LOG */
