void StartButtonInit(int height);
void StartButtonUpdate(char *title, int state);
void StartButtonDraw(int force);
int  MouseInStartButton(int x, int y);
