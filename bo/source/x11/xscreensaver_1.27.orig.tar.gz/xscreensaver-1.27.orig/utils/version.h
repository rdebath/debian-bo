static char *screensaver_id =
	"@(#)xscreensaver 1.27, by Jamie Zawinski (jwz@netscape.com)";
