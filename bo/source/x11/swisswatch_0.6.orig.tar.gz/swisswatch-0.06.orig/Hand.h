#ifndef _Hand_h_
#define _Hand_h_

typedef struct _HandClassRec	*HandWidgetClass;
typedef struct _HandRec	*HandWidget;

extern WidgetClass handWidgetClass;

#endif /* not _Hand_h_ */
