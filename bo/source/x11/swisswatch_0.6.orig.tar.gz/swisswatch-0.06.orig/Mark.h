#ifndef _Mark_h_
#define _Mark_h_

typedef struct _MarkClassRec	*MarkWidgetClass;
typedef struct _MarkRec	*MarkWidget;

extern WidgetClass markWidgetClass;

#endif /* not _Mark_h_ */
