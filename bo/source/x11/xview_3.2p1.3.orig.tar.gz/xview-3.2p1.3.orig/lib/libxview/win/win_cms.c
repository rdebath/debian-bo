#ifndef lint
#ifdef sccs
static char     sccsid[] = "@(#)win_cms.c 20.14 93/06/28";
#endif
#endif

/*
 * Copyright (c) 1983, 1987 by Sun Microsystems, Inc.
 */
