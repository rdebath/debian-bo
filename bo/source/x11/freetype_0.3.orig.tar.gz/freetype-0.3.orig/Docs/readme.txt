This is the Documentation directory.   Please  throw  every  bit  of
explanation, on any part of the engine, here..

All that is there will probably be condensed before any release..

                                                             - David
