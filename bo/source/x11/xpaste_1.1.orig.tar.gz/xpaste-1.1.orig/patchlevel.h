#ifndef lint
static char patchlevel[] = "xpaste Version 1.1 $Id: patchlevel.h,v 1.1 1995/01/04 17:28:33 jdd Exp $";
#endif
