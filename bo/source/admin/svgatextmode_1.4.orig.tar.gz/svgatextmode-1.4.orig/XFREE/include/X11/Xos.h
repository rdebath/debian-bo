/*
 * Just a dummy to get things compiling
 * without having to have X11 around.
 *
 * courtesy of David Mosberger-Tang <davidm@cs.arizona.edu>
 */
