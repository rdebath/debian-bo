#ifndef H_MESSAGES
#define H_MESSAGES

/* all the rest of what was here moved to rpmlib.h */

void rpmMessage(int level, char * format, ...);

#endif
