#ifndef H_TREAD
#define H_TREAD

int timedRead(int fd, void * bufptr, int length);

#endif
