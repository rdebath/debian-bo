#ifndef HAVE_INET_ATON

int inet_aton(const char *cp, struct in_addr *inp);

#endif
