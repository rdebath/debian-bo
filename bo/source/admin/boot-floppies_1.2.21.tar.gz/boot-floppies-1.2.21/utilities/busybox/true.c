#include "internal.h"

const char	true_usage[] = "true\n"
"\n\t"
"\treturn \"true\" status for use by shell programs.\n";

extern int
true_main(struct FileInfo * i, int argc, char * * argv)
{
	return 0;
}
