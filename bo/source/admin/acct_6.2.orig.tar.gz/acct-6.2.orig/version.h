/* version.h
 *
 * some defines to give version numbers to all of these programs. */

#define RELEASE_MAJOR 6
#define RELEASE_MINOR 2
