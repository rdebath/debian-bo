/* uid_hash.h
 *
 * protos & c.
 */

char *uid_name (int);
