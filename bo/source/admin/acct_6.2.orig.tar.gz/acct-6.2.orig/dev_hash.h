/* dev_hash.h
 *
 * protos for functions that lookup device names */

char *devname (long dev_num);
