0 4	* * *	root	dialdcost_maintenance
