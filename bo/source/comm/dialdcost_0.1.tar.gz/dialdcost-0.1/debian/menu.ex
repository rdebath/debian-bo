text Apps/Misc dialdcost none "dialdcost Description" /usr/bin/dialdcost
