#:OTHER:
dialdcost	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/dialdcost
