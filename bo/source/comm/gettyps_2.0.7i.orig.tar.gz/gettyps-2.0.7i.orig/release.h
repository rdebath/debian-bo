/*
**	$Id: release.h,v 2.1 95/11/02 21:42:46 mike Rel $
**
**	Getty release/date
*/


/* these are used by the man pages, too
 */
#define	RELEASE		"2.0.7h"	/* release number */
#define	DATE		"11-02-95"	/* release date */


/* end of release.h */
