/*
 * patchlevel.h		Defines the version strings
 *			in one central place.
 *
 * Version:		1.75 08-Jan-1996 MvS
 *
 */
#define SCCS_ID "@(#)Minicom V1.75 1996"
#define ST_VERSION "1.75 1996"
#define CR_VERSION "\nWelcome to minicom 1.75\r\n"
