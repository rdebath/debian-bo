double timing(int reset);
