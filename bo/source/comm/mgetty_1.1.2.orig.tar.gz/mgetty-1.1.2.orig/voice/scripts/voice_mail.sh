#!/bin/sh

cat << EOF

Subject: mvm-b4
Date: Sun, 16 Feb 1997 22:46:50 +0100
Sender: schaefer@alphanet.ch

[...]

There were almost no changes since the last upload (early november 96)
because:

   1. I have little time currently
   2. My voice modem is not working properly and I have no time to
      send it for repairs since it is quite used for X.75 which still
      works correctly.

PS: I would like that in the next vgetty release, the voice_script.sh
    NOT be included, but instead a pointer to
       ftp.imp.ch:/alphanet/files/mvm/

[...]

EOF
