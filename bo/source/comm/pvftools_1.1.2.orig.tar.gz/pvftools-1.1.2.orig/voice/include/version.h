char *version_h = "$Revision: 1.8 $";
char *vgetty_version = "experimental test release 0.7.1 / 20Feb97";
