
#include "includes.h"


void int(int argc, char *argv[]) {
				/* Nothing yet. */
}
