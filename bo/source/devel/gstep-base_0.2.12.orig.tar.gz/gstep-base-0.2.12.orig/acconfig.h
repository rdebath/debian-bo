/* Macros that may be defined by the aclocal.m4 extentions to `configure' 
   for GNUstep Base Library. */

#undef SYS_AUTOLOAD
#undef CON_AUTOLOAD

#undef NeXT_cc
#undef NeXT_runtime

#undef VSPRINTF_RETURNS_LENGTH
