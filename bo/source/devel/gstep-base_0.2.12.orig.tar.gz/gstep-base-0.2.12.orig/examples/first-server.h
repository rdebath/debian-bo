
#ifndef _first_server_h
#define _first_server_h

#include <Foundation/NSObject.h>

@interface FirstServer : NSObject

- sayHiTo: (char *)name;

@end

#endif /* _first_server_h */
