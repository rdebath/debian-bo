typedef union {
	id obj;
} YYSTYPE;
#define	QUOTED	258
#define	LABEL	259
#define	SEMICOLEN	260
#define	EQUALS	261
#define	ERROR	262


extern YYSTYPE sflval;
