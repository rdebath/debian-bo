typedef union {
        id obj;
} YYSTYPE;
#define	NSSTRING	258
#define	NSDATA	259
#define	ERROR	260


extern YYSTYPE pllval;
