/* Getting callbacks from array structures.
 * Copyright (C) 1995, 1996  Free Software Foundation, Inc.
 * 
 * Author: Albin L. Jones <Albin.L.Jones@Dartmouth.EDU>
 * Created: Mon Dec 11 02:44:09 EST 1995
 * Updated: Mon Mar 11 00:55:40 EST 1996
 * Serial: 96.03.11.02
 * 
 * This file is part of the GNUstep Base Library.
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Library General Public
 * License as published by the Free Software Foundation; either
 * version 2 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Library General Public License for more details.
 * 
 * You should have received a copy of the GNU Library General Public
 * License along with this library; if not, write to the Free
 * Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA. */ 

/**** Included Headers *******************************************************/

#include <gnustep/base/o_cbs.h>
#include <gnustep/base/o_array.h>

/**** Type, Constant, and Macro Definitions **********************************/

#define __array__ 1

/**** Function Implementations ***********************************************/

#ifdef __map__

/** Callbacks **/

/* Returns the callbacks associated with YY's keys. */
o_callbacks_t
o_array_key_callbacks(o_array_t * yy)
{
  return yy->key_callbacks;
}

/* Returns the ``bogus'' marker associated with YY's keys. */
const void *
o_array_not_a_key_marker(o_array_t *yy)
{
  return (yy->key_callbacks).not_an_item_marker;
}

/* Returns the callbacks associated with YY's values. */
o_callbacks_t
o_array_value_callbacks(o_array_t *yy)
{
  return yy->value_callbacks;
}

/* Returns the ``bogus'' marker associated with YY's values. */
const void *
o_array_not_a_value_marker(o_array_t *yy)
{
  return (yy->value_callbacks).not_an_item_marker;
}

#else /* !__map__ */

/** Callbacks **/

/* Returns the callbacks associated with YY's elements. */
o_callbacks_t
o_array_element_callbacks(o_array_t *yy)
{
  return yy->callbacks;
}

/* Returns the ``bogus'' marker associated with YY's elements. */
const void *
o_array_not_an_element_marker(o_array_t *yy)
{
  return (yy->callbacks).not_an_item_marker;
}

#endif /* __map__ */

