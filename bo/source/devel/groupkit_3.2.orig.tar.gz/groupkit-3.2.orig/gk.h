#include <tcl.h>

extern int Tgk_Init  _ANSI_ARGS_((Tcl_Interp *interp));
