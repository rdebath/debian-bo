/* Define if you have MIT Kerberos version 4 available.  */
#undef HAVE_KERBEROS

/* Define if you want CVS to be able to be a remote repository client.  */
#undef CLIENT_SUPPORT

/* Define if you want CVS to be able to serve repositories to remote
   clients.  */
#undef SERVER_SUPPORT

/* Define if you want to use the password authenticated server.  */
#undef AUTH_SERVER_SUPPORT

/* Define if you want encryption support.  */
#undef ENCRYPTION
