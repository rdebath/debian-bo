/* dist-3.0 - 18 Aug 1993 */

#define VERSION 3.0
#define PATCHLEVEL 70
