integer x,y,qwet,fgd,djr,kfy,g,jg,gk,j,sdhf,asg,agsd,ags,h,y,tsrh,sth,ruk,il,y,jd,sht,wht,wth,the,juyk,yt,tliu,rj,htw,grs,w,th,wht,hwte,erj,kut,uky,ilt,y,er,ht,wth,eht,ey,ejy,ej,e,uke,ly,liu,oy,g,t,asg,sdf,bc,ghf,rth,sbc,sdh,sh,sbc,sdf,sfhd,wrh
x=1; y=2
# sfadjlk;lkdfasjklfsjklfsdjlkfjklfdsjkl;fdsjkljklsdfjkl;dsfdfjklsjklsdfjklfsdjl;kk;sdfjkl;fsdjkl;dfsjkldsfjkl;dfsjkl;fdsjklfdsjkl;jhdsthjk;shtmk.xbgmkbvmkld;fsdjklsgjklgjkl;gsjkl;gjl;kjkl;gjkl;fgl;jkjkl
%#define ABC def
if((x==y) && x >=0)print *,'it works...'
if((x==y) && _
x <=0) _
	print *,'it works...'
if(x == y)
	write(6,600)
else if(x > y)
	write(6,601)
else
	write(6,602)
# check underscores in names
call abc_def(x,y)

x=1
while(x < 10){
	if(y != 2) break
	if(y != 2) next
	write(6,603)x
	x=x+1
	}
repeat {
	x=x-1
	if(x < 0){
		break
		}
	}
until(x == 0)
for(x=0; x < 10; x=x+1)
	write(6,604)x
600 format('Wrong, x != y')
601 format('Also wrong, x < y')
602 format('Ok!')
603 format('x = ',i2)
604 format('x = ',i2)
end
