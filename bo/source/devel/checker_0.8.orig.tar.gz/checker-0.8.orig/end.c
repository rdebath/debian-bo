/* Very very simple code to delimit the Checker code.  */
void checker_text_end (void);

int checker_data_end;
void
checker_text_end (void)
{
  return;
}
