$literal '#define M_NO_MEM "nothingness segment"'

$header "static char *short_right_name[]"
M_2_NO_RIGHT		"--"
M_2_RO_RIGHT		" R"
M_2_WO_RIGHT		" W"
M_2_RW_RIGHT		"RW"

$header "static char *right_name[]"
M_IE_RIGHT_NAME		"*internal error*"
M_RO_RIGHT_NAME		"Reading"
M_WO_RIGHT_NAME		"Writing"
M_RW_RIGHT_NAME		"Modifying"
