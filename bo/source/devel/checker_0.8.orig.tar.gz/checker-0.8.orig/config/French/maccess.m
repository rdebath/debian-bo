$literal '#define M_NO_MEM "segment n�ant"'

$header "static char *short_right_name[]"
M_2_NO_RIGHT		"--"
M_2_RO_RIGHT		" L"
M_2_WO_RIGHT		" E"
M_2_RW_RIGHT		"LE"

$header "static char *right_name[]"
M_IE_RIGHT_NAME		"*erreur interne*"
M_RO_RIGHT_NAME		"lecture"
M_WO_RIGHT_NAME		"�criture"
M_RW_RIGHT_NAME		"modification"
