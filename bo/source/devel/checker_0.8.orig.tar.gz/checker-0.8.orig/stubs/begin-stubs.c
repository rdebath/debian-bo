/* Very very simple code to delimit the Checker code.  */

int checker_data_stubs_begin;
void checker_text_stubs_begin (void)
{
  return;
}
