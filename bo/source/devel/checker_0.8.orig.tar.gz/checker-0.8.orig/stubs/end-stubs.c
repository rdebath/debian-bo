/* Very very simple code to delimit the Checker code.  */

int checker_data_stubs_end;
void checker_text_stubs_end (void)
{
  return;
}
