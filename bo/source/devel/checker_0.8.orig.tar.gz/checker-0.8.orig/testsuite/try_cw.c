main()
{
 float x = 12.25;
 int i;
 
 printf("x=%f\n", x);
 i = (int)x;
 printf("i=%d\n", i);
}
 