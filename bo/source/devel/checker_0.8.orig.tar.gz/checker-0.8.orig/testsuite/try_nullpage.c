main()
{
 char *p=(char*)0;
 printf("Lecture de 4 octets en 0: 0x%x\n", *p);
}
