char *string="Hello!";

void dummy(int a)
{
 return;
}

main()
{
 int a;
 a=strlen(string);
 dummy(a);
}
 
