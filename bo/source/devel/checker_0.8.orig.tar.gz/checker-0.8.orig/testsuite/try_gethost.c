main()
{
 gethostbyname("test");
 gethostbyname("localhost");
}
