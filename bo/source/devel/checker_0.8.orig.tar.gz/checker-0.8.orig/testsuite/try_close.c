main()
{
 printf("Hello...\n");
 close(253);
}