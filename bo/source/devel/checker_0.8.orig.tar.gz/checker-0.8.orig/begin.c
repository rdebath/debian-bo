/* Very very simple code to delimit the Checker code.  */
void checker_text_begin (void);

int checker_data_begin;
void
checker_text_begin (void)
{
  return;
}
