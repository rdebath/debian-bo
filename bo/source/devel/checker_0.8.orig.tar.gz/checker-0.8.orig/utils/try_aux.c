typedef void (*__sighandler_t)(int);

int foo0(int argc, char *argv[])
{
}

void (*hello(int a))(int)
{
}

int bar (enum {ab, bc, cd} a, char *b)
{
}

int foo (__sighandler_t a)
{
}

int old (a, b, c)
  char *c;
{
}

int foo1 (int a, int b, long c);
/* int foo1 (int, int, long); 
int foo1 (int a, int b, long c)
{
}
