#!/bin/sh
exec gcc -B/usr/local/lib/checker/ -checker $*