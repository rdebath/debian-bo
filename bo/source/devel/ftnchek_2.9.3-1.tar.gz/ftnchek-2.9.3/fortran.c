
/*  A Bison parser, made from fortran.y with Bison version GNU Bison version 1.22
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	tok_identifier	258
#define	tok_array_identifier	259
#define	tok_label	260
#define	tok_integer_const	261
#define	tok_real_const	262
#define	tok_dp_const	263
#define	tok_quad_const	264
#define	tok_complex_const	265
#define	tok_dcomplex_const	266
#define	tok_logical_const	267
#define	tok_string	268
#define	tok_hollerith	269
#define	tok_edit_descriptor	270
#define	tok_letter	271
#define	tok_relop	272
#define	tok_AND	273
#define	tok_OR	274
#define	tok_EQV	275
#define	tok_NEQV	276
#define	tok_NOT	277
#define	tok_power	278
#define	tok_concat	279
#define	tok_ACCEPT	280
#define	tok_ASSIGN	281
#define	tok_BACKSPACE	282
#define	tok_BLOCK	283
#define	tok_BLOCKDATA	284
#define	tok_BYTE	285
#define	tok_CALL	286
#define	tok_CHARACTER	287
#define	tok_CLOSE	288
#define	tok_COMMON	289
#define	tok_COMPLEX	290
#define	tok_CONTINUE	291
#define	tok_DATA	292
#define	tok_DIMENSION	293
#define	tok_DO	294
#define	tok_DOUBLE	295
#define	tok_DOUBLECOMPLEX	296
#define	tok_DOUBLEPRECISION	297
#define	tok_DOWHILE	298
#define	tok_ELSE	299
#define	tok_ELSEIF	300
#define	tok_END	301
#define	tok_ENDDO	302
#define	tok_ENDFILE	303
#define	tok_ENDIF	304
#define	tok_ENTRY	305
#define	tok_EQUIVALENCE	306
#define	tok_EXTERNAL	307
#define	tok_FILE	308
#define	tok_FORMAT	309
#define	tok_FUNCTION	310
#define	tok_GO	311
#define	tok_GOTO	312
#define	tok_IF	313
#define	tok_IMPLICIT	314
#define	tok_INCLUDE	315
#define	tok_INQUIRE	316
#define	tok_INTEGER	317
#define	tok_INTRINSIC	318
#define	tok_LOGICAL	319
#define	tok_NAMELIST	320
#define	tok_NONE	321
#define	tok_OPEN	322
#define	tok_PARAMETER	323
#define	tok_PAUSE	324
#define	tok_POINTER	325
#define	tok_PRECISION	326
#define	tok_PRINT	327
#define	tok_PROGRAM	328
#define	tok_READ	329
#define	tok_REAL	330
#define	tok_RETURN	331
#define	tok_REWIND	332
#define	tok_SAVE	333
#define	tok_STOP	334
#define	tok_SUBROUTINE	335
#define	tok_THEN	336
#define	tok_TO	337
#define	tok_TYPE	338
#define	tok_WHILE	339
#define	tok_WRITE	340
#define	tok_illegal	341
#define	tok_empty	342
#define	EOS	127
#define	REDUCE	343

#line 9 "fortran.y"


/*
  fortran.c:

    Copyright (C) 1992 by Robert K. Moniot.
    This program is free software.  Permission is granted to
    modify it and/or redistribute it.  There is no warranty
    for this program.


	    This grammar is ANSI standard-conforming, except for:
		-- complex constant and a few other ambiguities needing
		   significant lookahead cannot be split across lines.

	    Extensions supported:
	        -- Case insensitive.
	 	-- Hollerith constants.
		-- Variable names may be longer than 6 characters.  Also
		   allows underscores and dollar signs in names.
		-- DO ... ENDDO and DO WHILE loop forms allowed.
		-- NAMELIST supported.
		-- TYPE and ACCEPT I/O statements allowed.
		-- Tabs are permitted in input, and (except in character data)
		   expand into blanks up to the next column equal to 1 mod 8.
		-- Type declarations INTEGER*2, REAL*8, etc. are allowed.
		-- IMPLICIT NONE allowed.
	 */

/*  Author: R. Moniot
 *  Date:   August 1988
 *  Last revision: July 1993
 */

#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include "ftnchek.h"
#include "symtab.h"

	/* The following section is for use with bison-derived
	   parser.  Define alloca to be malloc for those cases
	   not covered by the cases covered there.  The ifdefs
	   are those in the skeleton parser with includes removed */
#ifdef AIXC	/* IBM RS/6000 xlc compiler does it this way */
#pragma alloca
#endif
#ifndef alloca
#ifdef __GNUC__
#else /* Not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__)
#else /* Not sparc */
#ifdef MSDOS
#endif /* MSDOS */
#endif /* Not sparc.  */
#endif /* Not GNU C.  */
#define alloca malloc
#endif /* alloca now defined.  */

#ifndef YYDEBUG	/* If not declared otherwise... */
int yydebug;	/* declare yydebug to satisfy extern in ftnchek.c */
#ifdef DEVELOPMENT
#define YYDEBUG 1		/* For development it is handy */
#else
#define YYDEBUG 0
#endif
#endif

#ifdef DEVELOPMENT
#define DEBUG_PARSER
#endif

PRIVATE int current_datatype,	/* set when parse type_name or type_stmt */
    current_size_is_adjustable, /* set in CHARACTER declarations */
    current_size_is_expression, /* set in CHARACTER declarations */
    control_item_count;	/* count of items in control_info_list */
int io_internal_file,	/* Flag for catching misuse of internal files */
    io_list_directed,	/* Flag for use in processing io control lists */
    io_warning_given;		/* to prevent multiple warnings */
			/* Flag shared with forlex for lexing hints */
int stmt_sequence_no;   /* set when parsing, reset to 0 at end_stmt */

PRIVATE long current_typesize;	/* for type*len declarations: value of len */
PRIVATE char *current_len_text;	/* for type*len declarations: text of len */

PRIVATE Token save_token;	/* Holds token shared by productions */

extern unsigned prev_stmt_line_num; /* shared with advance */

unsigned true_prev_stmt_line_num;	/* shared with symtab.c */

PRIVATE int
    current_module_hash = -1,	/* hashtable index of current module name */
    current_module_type,
    executable_stmt=FALSE,
    prev_stmt_class=0,		 /* flags for lexer */
    prev_goto=FALSE,
    goto_flag=FALSE;	/* if unconditional GOTO was encountered */

int 
    complex_const_allowed=FALSE, /* for help in lookahead for these */
    in_assignment_stmt=FALSE,
    inside_format=FALSE,	/* when inside parens of FORMAT  */
    integer_context=FALSE;	/* says integers-only are to follow */

				/* Defns of private functions */

PROTO(PRIVATE Token * add_tree_node,( Token *node, Token *left, Token *right ));
PROTO(PRIVATE Token * append_token,( Token *tlist, Token *t ));
PROTO(PRIVATE void check_stmt_sequence,( Token *t, int seq_num ));
PROTO(PRIVATE void do_binexpr,( Token *l_expr, Token *op, Token *r_expr,
			Token *result ));
PROTO(PRIVATE int do_bounds_type,( Token *t1, Token *t2, Token *t3 ));
PROTO(PRIVATE void do_unexpr,( Token *op, Token *expr, Token *result ));
PROTO(PRIVATE Token * empty_token,( Token *t ));
PROTO(PRIVATE void END_processing,( Token *t ));
PROTO(PRIVATE void init_io_ctrl_list,( void ));
#ifdef DEBUG_PARSER
PROTO(PRIVATE void print_exprlist,( char *s, Token *t ));
PROTO(PRIVATE void print_comlist,( char *s, Token *t ));
#endif

		/* Uses of Token fields for nonterminals: */
/* NOTE: As of Aug 1994 these are undergoing revision to separate the
         use of class, subclass fields */
/*
  1. dim_bound_lists: dimensioning info for arrays:
       token.class = no. of dimensions,  --> TOK_dims
       token.subclass = no. of elements  --> TOK_elts
  2. expressions
       token.value.integer = hash index (of identifier)
       token.class = type_byte = storage_class << 4 + datatype  --> TOK_type
       token.subclass = flags: CONST_EXPR, LVALUE_EXPR, etc.    --> TOK_flags
  3. common variable lists
       token.subclass = flag: COMMA_FLAG used to handle extra/missing commas
								--> TOK_flags
  4. substring_interval
       token.class = start index  --> TOK_start
       token.subclass = end index --> TOK_end
*/



#ifndef YYLTYPE
typedef
  struct yyltype
    {
      int timestamp;
      int first_line;
      int first_column;
      int last_line;
      int last_column;
      char *text;
   }
  yyltype;

#define YYLTYPE yyltype
#endif

#ifndef YYSTYPE
#define YYSTYPE int
#endif
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		819
#define	YYFLAG		-32768
#define	YYNTBASE	103

#define YYTRANSLATE(x) ((unsigned)(x) <= 343 ? yytranslate[x] : 342)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,    99,     2,     2,     2,    91,
    90,    93,   100,    92,    96,    98,    95,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    94,     2,   101,
    97,   102,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,    88,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    71,    72,    73,    74,    75,
    76,    77,    78,    79,    80,    81,    82,    83,    84,    85,
    86,    87,    89
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     3,     5,     8,    10,    12,    14,    16,    18,
    21,    23,    25,    27,    29,    31,    34,    36,    38,    40,
    42,    44,    47,    50,    54,    56,    58,    60,    62,    64,
    66,    68,    70,    72,    74,    76,    78,    80,    82,    84,
    86,    88,    90,    92,    94,    96,    98,   100,   102,   104,
   106,   108,   110,   112,   114,   116,   118,   120,   122,   124,
   126,   128,   130,   132,   134,   136,   138,   140,   142,   144,
   146,   148,   150,   152,   153,   158,   162,   169,   171,   175,
   182,   186,   193,   196,   198,   200,   202,   204,   206,   208,
   212,   219,   221,   222,   224,   226,   230,   232,   234,   237,
   241,   244,   246,   250,   252,   256,   261,   263,   267,   269,
   273,   275,   279,   280,   285,   289,   295,   299,   303,   305,
   307,   309,   314,   317,   320,   324,   328,   333,   335,   338,
   341,   345,   348,   350,   352,   355,   357,   360,   362,   364,
   368,   370,   373,   376,   380,   382,   385,   387,   390,   394,
   398,   402,   407,   409,   413,   415,   417,   419,   421,   423,
   426,   428,   431,   433,   435,   437,   441,   443,   447,   449,
   451,   453,   457,   459,   463,   465,   469,   471,   475,   479,
   481,   482,   487,   488,   494,   496,   500,   502,   506,   510,
   512,   516,   522,   526,   528,   532,   533,   538,   542,   544,
   548,   552,   554,   558,   562,   564,   568,   574,   576,   578,
   580,   583,   587,   589,   593,   595,   599,   603,   605,   608,
   612,   613,   614,   621,   623,   627,   629,   631,   633,   637,
   639,   643,   645,   647,   649,   651,   653,   657,   659,   661,
   669,   673,   679,   680,   681,   688,   690,   692,   694,   696,
   703,   708,   715,   723,   727,   734,   742,   744,   747,   750,
   755,   766,   769,   773,   774,   780,   783,   784,   785,   794,
   797,   800,   804,   810,   811,   819,   820,   827,   831,   836,
   839,   843,   849,   853,   856,   859,   863,   867,   868,   870,
   872,   874,   875,   879,   880,   885,   886,   892,   898,   905,
   913,   917,   923,   925,   929,   935,   939,   940,   941,   949,
   953,   954,   955,   963,   965,   969,   973,   975,   977,   981,
   985,   989,   991,   993,   997,   999,  1001,  1009,  1010,  1017,
  1018,  1025,  1026,  1033,  1037,  1043,  1045,  1049,  1055,  1057,
  1060,  1064,  1070,  1072,  1074,  1076,  1078,  1080,  1081,  1088,
  1089,  1091,  1093,  1096,  1098,  1100,  1102,  1106,  1108,  1110,
  1112,  1114,  1116,  1118,  1120,  1122,  1124,  1126,  1128,  1130,
  1132,  1135,  1138,  1139,  1140,  1146,  1151,  1152,  1154,  1156,
  1160,  1162,  1163,  1167,  1168,  1174,  1175,  1182,  1185,  1187,
  1191,  1193,  1197,  1200,  1204,  1209,  1211,  1212,  1214,  1216,
  1220,  1222,  1224,  1226,  1230,  1234,  1236,  1240,  1242,  1246,
  1248,  1251,  1253,  1257,  1259,  1262,  1265,  1269,  1273,  1275,
  1279,  1283,  1285,  1289,  1291,  1295,  1297,  1299,  1301,  1303,
  1305,  1309,  1311,  1313,  1315,  1317,  1319,  1321,  1323,  1325,
  1327,  1329,  1331,  1333,  1335,  1337,  1342,  1347,  1349,  1353,
  1355,  1358,  1361,  1364,  1367,  1370,  1374,  1379,  1384,  1390,
  1392,  1394,  1396,  1398,  1400,  1402,  1404,  1406,  1409,  1412,
  1414,  1416,  1418,  1420,  1421
};

static const short yyrhs[] = {   104,
     0,     0,   105,     0,   104,   105,     0,   106,     0,   112,
     0,    88,     0,   107,     0,   110,     0,     5,   108,     0,
   108,     0,   109,     0,   113,     0,   116,     0,   119,     0,
     1,    88,     0,   122,     0,   125,     0,   131,     0,   137,
     0,   111,     0,     5,   111,     0,    46,    88,     0,    60,
    13,    88,     0,   114,     0,   183,     0,   175,     0,   199,
     0,   115,     0,   124,     0,   279,     0,   139,     0,   144,
     0,   151,     0,   158,     0,   164,     0,   187,     0,   189,
     0,   196,     0,   191,     0,   117,     0,   118,     0,   219,
     0,   221,     0,   224,     0,   241,     0,   303,     0,   214,
     0,   218,     0,   220,     0,   240,     0,   242,     0,   249,
     0,   251,     0,   244,     0,   252,     0,   255,     0,   275,
     0,   271,     0,   273,     0,   265,     0,   267,     0,   269,
     0,   296,     0,   120,     0,   121,     0,   225,     0,   226,
     0,   234,     0,   239,     0,   229,     0,   232,     0,   233,
     0,     0,    73,   123,   337,    88,     0,    50,   337,    88,
     0,    50,   337,    91,   134,    90,    88,     0,   126,     0,
   127,   337,    88,     0,   127,   337,    91,   134,    90,    88,
     0,   128,   337,    88,     0,   128,   337,    91,   134,    90,
    88,     0,   130,   129,     0,   129,     0,    55,     0,   165,
     0,   168,     0,   169,     0,   132,     0,   133,   337,    88,
     0,   133,   337,    91,   134,    90,    88,     0,    80,     0,
     0,   135,     0,   136,     0,   135,    92,   136,     0,   337,
     0,    93,     0,   138,    88,     0,   138,   337,    88,     0,
    28,    37,     0,    29,     0,    38,   140,    88,     0,   141,
     0,   140,    92,   141,     0,   337,    91,   142,    90,     0,
   143,     0,   142,    92,   143,     0,   325,     0,   325,    94,
   325,     0,    93,     0,   325,    94,    93,     0,     0,    51,
   145,   146,    88,     0,    91,   147,    90,     0,   146,    92,
    91,   147,    90,     0,   148,    92,   148,     0,   147,    92,
   148,     0,   337,     0,   149,     0,   150,     0,   337,    91,
   328,    90,     0,   337,   332,     0,   149,   332,     0,    34,
   155,    88,     0,    34,   152,    88,     0,    34,   155,   152,
    88,     0,   153,     0,   152,   153,     0,   154,   155,     0,
    95,   337,    95,     0,    95,    95,     0,    24,     0,   156,
     0,   155,   156,     0,   157,     0,   157,    92,     0,   337,
     0,   141,     0,    65,   159,    88,     0,   160,     0,   159,
   160,     0,   161,   162,     0,    95,   337,    95,     0,   163,
     0,   162,   163,     0,   337,     0,   337,    92,     0,   165,
   170,    88,     0,   168,   172,    88,     0,   169,   172,    88,
     0,   169,    92,   172,    88,     0,   166,     0,   166,    93,
   339,     0,   167,     0,    62,     0,    75,     0,    35,     0,
    64,     0,    40,    71,     0,    42,     0,    40,    35,     0,
    41,     0,    30,     0,    32,     0,   168,    93,   182,     0,
   171,     0,   170,    92,   171,     0,   337,     0,   141,     0,
   173,     0,   172,    92,   173,     0,   337,     0,   337,    93,
   182,     0,   141,     0,   141,    93,   182,     0,    59,     0,
   174,   176,    88,     0,   174,    66,    88,     0,   178,     0,
     0,   176,    92,   177,   178,     0,     0,   130,    91,   179,
   180,    90,     0,   181,     0,   180,    92,   181,     0,    16,
     0,    16,    96,    16,     0,    91,    93,    90,     0,   339,
     0,    91,   324,    90,     0,    68,    91,   184,    90,    88,
     0,    68,   184,    88,     0,   185,     0,   184,    92,   185,
     0,     0,   337,   186,    97,   308,     0,    52,   188,    88,
     0,   337,     0,   188,    92,   337,     0,    63,   190,    88,
     0,   337,     0,   190,    92,   337,     0,    70,   192,    88,
     0,   193,     0,   192,    92,   193,     0,    91,   194,    92,
   195,    90,     0,   337,     0,   337,     0,   141,     0,    78,
    88,     0,    78,   197,    88,     0,   198,     0,   197,    92,
   198,     0,   337,     0,    95,   337,    95,     0,    37,   200,
    88,     0,   201,     0,   200,   201,     0,   200,    92,   201,
     0,     0,     0,   204,    95,   202,   206,   203,    95,     0,
   205,     0,   204,    92,   205,     0,   217,     0,   212,     0,
   207,     0,   206,    92,   207,     0,   209,     0,   208,    93,
   209,     0,   339,     0,   337,     0,   338,     0,   337,     0,
   211,     0,   210,    92,   211,     0,   326,     0,   212,     0,
    91,   210,    92,   337,    97,   213,    90,     0,   324,    92,
   324,     0,   324,    92,   324,    92,   324,     0,     0,     0,
   217,    97,   215,   309,   216,    88,     0,   334,     0,   326,
     0,   331,     0,   292,     0,    26,   340,   341,    82,   334,
    88,     0,   222,   340,   341,    88,     0,   222,    91,   223,
    90,   322,    88,     0,   222,    91,   223,    90,    92,   322,
    88,     0,   222,   337,    88,     0,   222,   337,    91,   223,
    90,    88,     0,   222,   337,    92,    91,   223,    90,    88,
     0,    57,     0,    56,    82,     0,   340,   341,     0,   223,
    92,   340,   341,     0,   227,   340,   341,    92,   340,   341,
    92,   340,   341,    88,     0,   227,   116,     0,   227,    81,
    88,     0,     0,    58,    91,   228,   309,    90,     0,    44,
   226,     0,     0,     0,    45,    91,   230,   309,    90,   231,
    81,    88,     0,    44,    88,     0,    49,    88,     0,    46,
    58,    88,     0,   237,   334,    97,   238,    88,     0,     0,
   237,    84,    91,   235,   309,    90,    88,     0,     0,    43,
    91,   236,   309,    90,    88,     0,    39,   340,   341,     0,
    39,   340,   341,    92,     0,    39,   340,     0,   323,    92,
   323,     0,   323,    92,   323,    92,   323,     0,    46,    39,
    88,     0,    47,    88,     0,    36,    88,     0,    79,   243,
    88,     0,    69,   243,    88,     0,     0,     6,     0,   337,
     0,    13,     0,     0,   247,   245,    88,     0,     0,   247,
   262,   246,    88,     0,     0,    85,   248,    91,   258,    90,
     0,   250,    91,   258,    90,    88,     0,   250,    91,   258,
    90,   262,    88,     0,   250,    91,   258,    90,    92,   262,
    88,     0,   250,   278,    88,     0,   250,   278,    92,   262,
    88,     0,    74,     0,    25,   278,    88,     0,    25,   278,
    92,   262,    88,     0,    72,   278,    88,     0,     0,     0,
    72,   278,    92,   253,   262,   254,    88,     0,    83,   278,
    88,     0,     0,     0,    83,   278,    92,   256,   262,   257,
    88,     0,   259,     0,   258,    92,   259,     0,   337,    97,
   277,     0,   277,     0,   277,     0,   337,    97,   277,     0,
   260,    92,   261,     0,   337,    97,   277,     0,   337,     0,
   263,     0,   262,    92,   263,     0,   309,     0,   264,     0,
    91,   262,    92,   334,    97,   238,    90,     0,     0,    67,
   266,    91,   260,    90,    88,     0,     0,    33,   268,    91,
   258,    90,    88,     0,     0,    61,   270,    91,   258,    90,
    88,     0,   272,   277,    88,     0,   272,    91,   258,    90,
    88,     0,    27,     0,   274,   277,    88,     0,   274,    91,
   258,    90,    88,     0,    48,     0,    46,    53,     0,   276,
   277,    88,     0,   276,    91,   258,    90,    88,     0,    77,
     0,   309,     0,    93,     0,   318,     0,    93,     0,     0,
    54,   280,    91,   281,    90,    88,     0,     0,   282,     0,
   283,     0,   282,   283,     0,   284,     0,   285,     0,   286,
     0,    91,   282,    90,     0,    15,     0,    13,     0,    14,
     0,   288,     0,   289,     0,    92,     0,    95,     0,    24,
     0,    94,     0,    98,     0,   287,     0,    99,     0,     6,
     0,    96,     6,     0,   100,     6,     0,     0,     0,   101,
   290,   322,   291,   102,     0,   335,    91,   293,    90,     0,
     0,   294,     0,   295,     0,   294,    92,   295,     0,   334,
     0,     0,   300,   297,    88,     0,     0,   300,    91,    90,
   298,    88,     0,     0,   300,    91,   301,    90,   299,    88,
     0,    31,   337,     0,   302,     0,   301,    92,   302,     0,
   309,     0,    93,   340,   341,     0,    76,    88,     0,    76,
   322,    88,     0,   305,    91,   306,    90,     0,   335,     0,
     0,   307,     0,   309,     0,   307,    92,   309,     0,   309,
     0,   310,     0,   311,     0,   309,    20,   311,     0,   309,
    21,   311,     0,   312,     0,   311,    19,   312,     0,   313,
     0,   312,    18,   313,     0,   314,     0,    22,   314,     0,
   315,     0,   314,    17,   314,     0,   316,     0,    96,   316,
     0,   100,   316,     0,   315,   100,   316,     0,   315,    96,
   316,     0,   317,     0,   316,    95,   317,     0,   316,    93,
   317,     0,   318,     0,   318,    23,   317,     0,   319,     0,
   318,    24,   319,     0,   334,     0,   327,     0,   304,     0,
   330,     0,   320,     0,    91,   309,    90,     0,   321,     0,
    13,     0,    14,     0,    12,     0,     6,     0,     7,     0,
     8,     0,     9,     0,    10,     0,    11,     0,   315,     0,
   315,     0,   315,     0,   315,     0,   336,    91,   328,    90,
     0,   336,    91,   328,    90,     0,   329,     0,   328,    92,
   329,     0,   309,     0,   305,   332,     0,   304,   332,     0,
   327,   332,     0,   335,   332,     0,   326,   332,     0,    91,
    94,    90,     0,    91,   333,    94,    90,     0,    91,    94,
   333,    90,     0,    91,   333,    94,   333,    90,     0,   315,
     0,   335,     0,   336,     0,     3,     0,     4,     0,     3,
     0,     4,     0,   321,     0,    96,   321,     0,   100,   321,
     0,    12,     0,    13,     0,    14,     0,     6,     0,     0,
     6,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   257,   258,   261,   262,   266,   293,   294,   302,   303,   306,
   314,   325,   330,   334,   347,   353,   367,   371,   375,   379,
   385,   386,   389,   392,   411,   417,   426,   430,   436,   442,
   446,   449,   450,   451,   452,   453,   454,   455,   456,   457,
   462,   467,   473,   474,   475,   476,   477,   480,   481,   482,
   483,   484,   485,   486,   487,   488,   489,   490,   491,   492,
   493,   494,   495,   496,   499,   504,   510,   512,   513,   525,
   537,   538,   539,   543,   544,   561,   566,   578,   582,   598,
   614,   630,   648,   651,   654,   660,   661,   662,   669,   673,
   684,   702,   708,   712,   715,   719,   725,   730,   742,   759,
   772,   776,   783,   786,   787,   791,   797,   804,   812,   820,
   832,   837,   846,   847,   850,   851,   854,   858,   865,   869,
   873,   879,   883,   884,   888,   902,   910,   928,   932,   940,
   953,   958,   962,   968,   973,   986,   991,   998,  1003,  1016,
  1028,  1029,  1035,  1042,  1048,  1052,  1065,  1071,  1080,  1081,
  1082,  1083,  1086,  1092,  1113,  1116,  1121,  1126,  1131,  1138,
  1144,  1150,  1159,  1168,  1178,  1189,  1206,  1207,  1210,  1217,
  1226,  1227,  1230,  1239,  1251,  1260,  1276,  1279,  1291,  1306,
  1307,  1309,  1313,  1314,  1317,  1318,  1321,  1336,  1360,  1370,
  1376,  1393,  1394,  1401,  1402,  1405,  1406,  1416,  1419,  1423,
  1430,  1433,  1437,  1444,  1451,  1452,  1455,  1458,  1465,  1472,
  1480,  1484,  1487,  1488,  1491,  1495,  1503,  1506,  1507,  1508,
  1511,  1514,  1515,  1518,  1519,  1522,  1526,  1529,  1530,  1533,
  1534,  1537,  1538,  1544,  1545,  1552,  1553,  1556,  1560,  1563,
  1570,  1571,  1576,  1578,  1592,  1600,  1601,  1602,  1603,  1609,
  1617,  1621,  1622,  1626,  1630,  1634,  1640,  1644,  1650,  1651,
  1655,  1668,  1678,  1687,  1687,  1700,  1701,  1701,  1710,  1714,
  1718,  1719,  1730,  1760,  1761,  1769,  1770,  1780,  1781,  1782,
  1789,  1793,  1799,  1800,  1804,  1808,  1812,  1815,  1816,  1817,
  1821,  1825,  1827,  1827,  1829,  1831,  1832,  1840,  1841,  1842,
  1843,  1844,  1846,  1849,  1854,  1862,  1863,  1865,  1866,  1868,
  1873,  1875,  1876,  1883,  1887,  1909,  1913,  1953,  1961,  1966,
  1972,  1976,  1983,  1984,  1987,  1997,  2001,  2014,  2015,  2019,
  2020,  2024,  2025,  2029,  2036,  2038,  2042,  2049,  2051,  2052,
  2056,  2063,  2065,  2073,  2074,  2078,  2084,  2088,  2088,  2095,
  2096,  2100,  2101,  2104,  2105,  2106,  2109,  2110,  2113,  2114,
  2115,  2116,  2119,  2120,  2121,  2122,  2123,  2124,  2131,  2134,
  2135,  2136,  2140,  2141,  2142,  2150,  2164,  2168,  2171,  2175,
  2182,  2186,  2192,  2192,  2198,  2198,  2207,  2209,  2215,  2220,
  2226,  2233,  2241,  2245,  2252,  2280,  2290,  2296,  2299,  2304,
  2312,  2341,  2356,  2358,  2363,  2370,  2372,  2379,  2381,  2388,
  2390,  2396,  2398,  2406,  2408,  2412,  2416,  2421,  2428,  2430,
  2440,  2447,  2449,  2456,  2458,  2465,  2467,  2469,  2471,  2473,
  2482,  2505,  2507,  2512,  2521,  2528,  2533,  2538,  2543,  2552,
  2557,  2565,  2579,  2599,  2623,  2649,  2665,  2681,  2685,  2691,
  2705,  2720,  2728,  2737,  2741,  2750,  2764,  2774,  2784,  2796,
  2817,  2818,  2821,  2828,  2837,  2838,  2842,  2843,  2844,  2845,
  2846,  2847,  2853,  2870,  2877
};

static const char * const yytname[] = {   "$","error","$illegal.","tok_identifier",
"tok_array_identifier","tok_label","tok_integer_const","tok_real_const","tok_dp_const",
"tok_quad_const","tok_complex_const","tok_dcomplex_const","tok_logical_const",
"tok_string","tok_hollerith","tok_edit_descriptor","tok_letter","tok_relop",
"tok_AND","tok_OR","tok_EQV","tok_NEQV","tok_NOT","tok_power","tok_concat","tok_ACCEPT",
"tok_ASSIGN","tok_BACKSPACE","tok_BLOCK","tok_BLOCKDATA","tok_BYTE","tok_CALL",
"tok_CHARACTER","tok_CLOSE","tok_COMMON","tok_COMPLEX","tok_CONTINUE","tok_DATA",
"tok_DIMENSION","tok_DO","tok_DOUBLE","tok_DOUBLECOMPLEX","tok_DOUBLEPRECISION",
"tok_DOWHILE","tok_ELSE","tok_ELSEIF","tok_END","tok_ENDDO","tok_ENDFILE","tok_ENDIF",
"tok_ENTRY","tok_EQUIVALENCE","tok_EXTERNAL","tok_FILE","tok_FORMAT","tok_FUNCTION",
"tok_GO","tok_GOTO","tok_IF","tok_IMPLICIT","tok_INCLUDE","tok_INQUIRE","tok_INTEGER",
"tok_INTRINSIC","tok_LOGICAL","tok_NAMELIST","tok_NONE","tok_OPEN","tok_PARAMETER",
"tok_PAUSE","tok_POINTER","tok_PRECISION","tok_PRINT","tok_PROGRAM","tok_READ",
"tok_REAL","tok_RETURN","tok_REWIND","tok_SAVE","tok_STOP","tok_SUBROUTINE",
"tok_THEN","tok_TO","tok_TYPE","tok_WHILE","tok_WRITE","tok_illegal","tok_empty",
"EOS","REDUCE","')'","'('","','","'*'","':'","'/'","'-'","'='","'.'","'$'","'+'",
"'<'","'>'","prog_body","stmt_list","stmt_list_item","ordinary_stmt","stmt",
"unlabeled_stmt","subprogram_header","end_stmt","unlabeled_end_stmt","include_stmt",
"specification_stmt","anywhere_stmt","specif_stmt","executable_stmt","transfer_stmt",
"nontransfer_stmt","restricted_stmt","restricted_nontransfer_stmt","else_or_endif_stmt",
"prog_stmt","@1","entry_stmt","function_stmt","unlabeled_function_stmt","typed_function_handle",
"plain_function_handle","function_keyword","type_name","subroutine_stmt","unlabeled_subroutine_stmt",
"subroutine_handle","dummy_argument_list","non_empty_arg_list","dummy_argument",
"block_data_stmt","block_data_handle","dimension_stmt","array_declarator_list",
"array_declarator","dim_bound_list","dim_bound_item","equivalence_stmt","@2",
"equivalence_list","equivalence_list_item","equiv_entity","array_equiv_name",
"substring_equiv_name","common_stmt","common_block_list","labeled_common_block",
"common_block_name","common_variable_list","common_list_item","common_entity",
"namelist_stmt","namelist_list","namelist_decl","namelist_name","namelist_var_list",
"namelist_item","type_stmt","arith_type_name","sizeable_type_name","unsizeable_type_name",
"plain_char_type_name","char_type_name","arith_type_decl_list","arith_type_decl_item",
"char_type_decl_list","char_type_decl_item","implicit_handle","implicit_stmt",
"implicit_decl_list","@3","implicit_decl_item","@4","letter_list","letter_list_item",
"len_specification","parameter_stmt","parameter_defn_list","parameter_defn_item",
"@5","external_stmt","external_name_list","intrinsic_stmt","intrinsic_name_list",
"pointer_stmt","pointer_item_list","pointer_item","pointer_name","pointee_name",
"save_stmt","save_list","save_item","data_stmt","data_defn_list","data_defn_item",
"@6","@7","data_defn_assignee_list","data_defn_assignee","data_value_list","data_value",
"data_repeat_factor","data_constant_value","data_dlist","data_dlist_item","data_implied_do_list",
"data_do_loop_bounds","assignment_stmt","@8","@9","lvalue","assign_stmt","unconditional_goto",
"computed_goto","assigned_goto","goto","goto_list","arithmetic_if_stmt","logical_if_stmt",
"block_if_stmt","if_handle","@10","else_if_stmt","@11","@12","else_stmt","end_if_stmt",
"do_stmt","@13","@14","do_handle","do_loop_bounds","enddo_stmt","continue_stmt",
"stop_stmt","pause_stmt","stop_info","write_stmt","@15","@16","write_handle",
"@17","read_stmt","read_handle","accept_stmt","print_stmt","@18","@19","type_output_stmt",
"@20","@21","control_info_list","control_info_item","open_info_list","open_info_item",
"io_list","io_item","io_implied_do_list","open_stmt","@22","close_stmt","@23",
"inquire_stmt","@24","backspace_stmt","backspace_handle","endfile_stmt","endfile_handle",
"rewind_stmt","rewind_handle","unit_id","format_id","format_stmt","@25","format_spec",
"nonempty_format_spec","fmt_spec_item","repeatable_fmt_item","unrepeatable_fmt_item",
"fmt_item_separator","nonstandard_fmt_item","repeat_spec","variable_fmt_item",
"@26","@27","stmt_function_handle","stmt_function_dummy_list","nonempty_stmt_fun_dummy_list",
"stmt_function_dummy_arg","call_stmt","@28","@29","@30","call_handle","subr_arg_list",
"subr_arg","return_stmt","function_reference","fun_or_substr_handle","fun_arg_list",
"nonempty_fun_arg_list","parameter_expr","expr","log_expr","log_disjunct","log_term",
"log_factor","log_primary","arith_expr","term","factor","char_expr","primary",
"literal_const","numeric_const","integer_expr","int_real_dp_expr","int_constant_expr",
"dim_bound_expr","array_element_lvalue","array_element_name","subscript_list",
"subscript","substring_name","substring_lvalue","substring_interval","substr_index_expr",
"variable_name","scalar_name","array_name","symbolic_name","data_constant","nonzero_unsigned_int_const",
"pre_label","label",""
};
#endif

static const short yyr1[] = {     0,
   103,   103,   104,   104,   105,   105,   105,   106,   106,   107,
   107,   108,   108,   108,   108,   108,   109,   109,   109,   109,
   110,   110,   111,   112,   113,   113,   113,   113,   113,   114,
   114,   115,   115,   115,   115,   115,   115,   115,   115,   115,
   116,   116,   117,   117,   117,   117,   117,   118,   118,   118,
   118,   118,   118,   118,   118,   118,   118,   118,   118,   118,
   118,   118,   118,   118,   119,   119,   120,   120,   120,   120,
   121,   121,   121,   123,   122,   124,   124,   125,   126,   126,
   126,   126,   127,   128,   129,   130,   130,   130,   131,   132,
   132,   133,   134,   134,   135,   135,   136,   136,   137,   137,
   138,   138,   139,   140,   140,   141,   142,   142,   143,   143,
   143,   143,   145,   144,   146,   146,   147,   147,   148,   148,
   148,   149,   150,   150,   151,   151,   151,   152,   152,   153,
   154,   154,   154,   155,   155,   156,   156,   157,   157,   158,
   159,   159,   160,   161,   162,   162,   163,   163,   164,   164,
   164,   164,   165,   165,   165,   166,   166,   166,   166,   167,
   167,   167,   167,   167,   168,   169,   170,   170,   171,   171,
   172,   172,   173,   173,   173,   173,   174,   175,   175,   176,
   177,   176,   179,   178,   180,   180,   181,   181,   182,   182,
   182,   183,   183,   184,   184,   186,   185,   187,   188,   188,
   189,   190,   190,   191,   192,   192,   193,   194,   195,   195,
   196,   196,   197,   197,   198,   198,   199,   200,   200,   200,
   202,   203,   201,   204,   204,   205,   205,   206,   206,   207,
   207,   208,   208,   209,   209,   210,   210,   211,   211,   212,
   213,   213,   215,   216,   214,   217,   217,   217,   217,   218,
   219,   220,   220,   221,   221,   221,   222,   222,   223,   223,
   224,   225,   226,   228,   227,   229,   230,   231,   229,   232,
   233,   233,   234,   235,   234,   236,   234,   237,   237,   237,
   238,   238,   239,   239,   240,   241,   242,   243,   243,   243,
   243,   245,   244,   246,   244,   248,   247,   249,   249,   249,
   249,   249,   250,   251,   251,   252,   253,   254,   252,   255,
   256,   257,   255,   258,   258,   259,   259,   260,   260,   260,
   261,   261,   262,   262,   263,   263,   264,   266,   265,   268,
   267,   270,   269,   271,   271,   272,   273,   273,   274,   274,
   275,   275,   276,   277,   277,   278,   278,   280,   279,   281,
   281,   282,   282,   283,   283,   283,   284,   284,   285,   285,
   285,   285,   286,   286,   286,   286,   286,   286,   287,   288,
   288,   288,   290,   291,   289,   292,   293,   293,   294,   294,
   295,   297,   296,   298,   296,   299,   296,   300,   301,   301,
   302,   302,   303,   303,   304,   305,   306,   306,   307,   307,
   308,   309,   310,   310,   310,   311,   311,   312,   312,   313,
   313,   314,   314,   315,   315,   315,   315,   315,   316,   316,
   316,   317,   317,   318,   318,   319,   319,   319,   319,   319,
   319,   320,   320,   320,   320,   321,   321,   321,   321,   321,
   321,   322,   323,   324,   325,   326,   327,   328,   328,   329,
   330,   330,   330,   331,   331,   332,   332,   332,   332,   333,
   334,   334,   335,   336,   337,   337,   338,   338,   338,   338,
   338,   338,   339,   340,   341
};

static const short yyr2[] = {     0,
     1,     0,     1,     2,     1,     1,     1,     1,     1,     2,
     1,     1,     1,     1,     1,     2,     1,     1,     1,     1,
     1,     2,     2,     3,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     0,     4,     3,     6,     1,     3,     6,
     3,     6,     2,     1,     1,     1,     1,     1,     1,     3,
     6,     1,     0,     1,     1,     3,     1,     1,     2,     3,
     2,     1,     3,     1,     3,     4,     1,     3,     1,     3,
     1,     3,     0,     4,     3,     5,     3,     3,     1,     1,
     1,     4,     2,     2,     3,     3,     4,     1,     2,     2,
     3,     2,     1,     1,     2,     1,     2,     1,     1,     3,
     1,     2,     2,     3,     1,     2,     1,     2,     3,     3,
     3,     4,     1,     3,     1,     1,     1,     1,     1,     2,
     1,     2,     1,     1,     1,     3,     1,     3,     1,     1,
     1,     3,     1,     3,     1,     3,     1,     3,     3,     1,
     0,     4,     0,     5,     1,     3,     1,     3,     3,     1,
     3,     5,     3,     1,     3,     0,     4,     3,     1,     3,
     3,     1,     3,     3,     1,     3,     5,     1,     1,     1,
     2,     3,     1,     3,     1,     3,     3,     1,     2,     3,
     0,     0,     6,     1,     3,     1,     1,     1,     3,     1,
     3,     1,     1,     1,     1,     1,     3,     1,     1,     7,
     3,     5,     0,     0,     6,     1,     1,     1,     1,     6,
     4,     6,     7,     3,     6,     7,     1,     2,     2,     4,
    10,     2,     3,     0,     5,     2,     0,     0,     8,     2,
     2,     3,     5,     0,     7,     0,     6,     3,     4,     2,
     3,     5,     3,     2,     2,     3,     3,     0,     1,     1,
     1,     0,     3,     0,     4,     0,     5,     5,     6,     7,
     3,     5,     1,     3,     5,     3,     0,     0,     7,     3,
     0,     0,     7,     1,     3,     3,     1,     1,     3,     3,
     3,     1,     1,     3,     1,     1,     7,     0,     6,     0,
     6,     0,     6,     3,     5,     1,     3,     5,     1,     2,
     3,     5,     1,     1,     1,     1,     1,     0,     6,     0,
     1,     1,     2,     1,     1,     1,     3,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     2,     2,     0,     0,     5,     4,     0,     1,     1,     3,
     1,     0,     3,     0,     5,     0,     6,     2,     1,     3,
     1,     3,     2,     3,     4,     1,     0,     1,     1,     3,
     1,     1,     1,     3,     3,     1,     3,     1,     3,     1,
     2,     1,     3,     1,     2,     2,     3,     3,     1,     3,
     3,     1,     3,     1,     3,     1,     1,     1,     1,     1,
     3,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     4,     4,     1,     3,     1,
     2,     2,     2,     2,     2,     3,     4,     4,     5,     1,
     1,     1,     1,     1,     1,     1,     1,     2,     2,     1,
     1,     1,     1,     0,     1
};

static const short yydefact[] = {     0,
     0,   463,   464,     0,     0,   474,   336,     0,   102,   164,
     0,   165,   330,     0,   158,     0,     0,     0,   474,     0,
   163,   161,     0,     0,     0,     0,     0,   339,     0,     0,
   113,     0,   348,    85,     0,   257,     0,   177,     0,   332,
   156,     0,   159,     0,   328,     0,   288,     0,     0,    74,
   303,   157,     0,   343,     0,   288,    92,     0,   296,     7,
     0,     3,     5,     8,    11,    12,     9,    21,     6,    13,
    25,    29,    14,    41,    42,    15,    65,    66,    17,    30,
    18,    78,     0,     0,    84,     0,    19,    89,     0,    20,
     0,    32,    33,    34,    35,    36,    86,   153,   155,    87,
    88,     0,    27,    26,    37,    38,    40,    39,    28,    48,
     0,    49,    43,    50,    44,   474,    45,    67,    68,   474,
    71,    72,    73,    69,     0,    70,    51,    46,    52,    55,
   292,    53,     0,    54,    56,    57,    61,    62,    63,    59,
     0,    60,     0,    58,     0,    31,   249,    64,   382,    47,
   247,   248,   246,   461,   462,    16,    10,    22,   436,   437,
   438,   439,   440,   441,   435,   433,   434,     0,   347,     0,
   428,     0,   346,   424,   430,   432,   427,   429,   426,   461,
   462,     0,   101,   465,   466,   388,     0,   133,     0,   139,
     0,   128,     0,     0,   134,   136,   138,   285,     0,     0,
   218,     0,   224,   227,   226,     0,   104,     0,   280,   162,
   160,   276,   270,   266,     0,   267,     0,   340,     0,    23,
   284,   271,     0,     0,     0,   199,     0,   258,   264,     0,
     0,     0,   202,     0,     0,   141,     0,     0,     0,     0,
   194,   196,   289,   291,     0,   290,     0,     0,   205,     0,
     0,   393,     0,     0,   442,   414,   419,   422,     0,   211,
     0,     0,   213,   215,     0,     0,     0,     4,     0,     0,
    83,     0,    99,     0,   170,     0,   167,   169,     0,     0,
   175,     0,   171,   173,     0,     0,     0,     0,    86,    87,
    88,     0,   180,   243,   474,     0,     0,     0,     0,   262,
   474,     0,     0,     0,   461,   462,     0,     0,     0,   294,
   323,   326,   325,   402,   403,   406,   408,   410,   412,     0,
     0,     0,   345,     0,   344,     0,     0,     0,     0,     0,
     0,     0,   455,   377,   454,     0,     0,   304,     0,   452,
   397,   451,     0,   453,     0,   475,     0,     0,   132,     0,
   126,   129,   130,   125,     0,   135,   137,     0,     0,   236,
   239,   238,     0,   217,     0,   219,     0,   221,   103,     0,
   278,     0,     0,   283,   272,    76,    93,     0,     0,   198,
     0,   350,     0,    24,     0,   201,     0,     0,   140,   142,
   143,   145,   147,     0,     0,   193,     0,     0,   287,     0,
   208,   204,     0,   306,   307,     0,   415,   416,     0,     0,
     0,     0,     0,   394,     0,   212,     0,   286,   310,   311,
     0,    79,    93,    81,    93,    90,    93,   100,   149,     0,
   473,   154,     0,   166,   190,     0,   150,     0,     0,     0,
   151,   179,   183,   178,   181,     0,     0,     0,   254,   474,
     0,     0,   263,     0,   274,     0,   411,     0,   325,   293,
     0,     0,     0,     0,     0,     0,     0,   463,   464,     0,
   314,   317,   344,     0,   301,     0,     0,   334,     0,   337,
     0,   341,   384,   474,     0,   389,   391,   383,     0,   460,
     0,     0,   378,   379,   426,   450,     0,   448,   431,     0,
     0,   398,   399,   412,   425,     0,     0,     0,   131,   127,
   111,     0,   107,   445,   109,     0,   220,   225,     0,   105,
   279,     0,     0,    98,     0,    94,    95,    97,     0,     0,
   120,   121,   119,   114,     0,   200,   370,   359,   360,   358,
   365,     0,   363,   366,   364,     0,   367,   369,     0,   373,
     0,   351,   352,   354,   355,   356,   368,   361,   362,     0,
     0,   203,   144,   146,   148,     0,   318,     0,     0,   195,
     0,     0,   206,     0,    75,   418,   417,   421,   420,   423,
   216,   214,     0,     0,     0,     0,     0,   168,     0,   444,
     0,   176,   172,   174,   152,     0,     0,   244,     0,   474,
   259,     0,   474,   251,   474,     0,     0,   443,     0,     0,
   324,   295,   404,   405,   407,   409,   413,     0,     0,     0,
     0,     0,     0,     0,     0,     0,   386,     0,   456,     0,
     0,   376,     0,   446,     0,   305,   395,     0,   447,     0,
     0,   106,     0,     0,   237,     0,   436,   470,   471,   472,
     0,     0,   222,   228,     0,   230,   467,   235,   234,   232,
     0,   268,     0,     0,   115,     0,     0,   124,     0,   123,
     0,     0,   371,   372,     0,     0,   353,   265,     0,     0,
     0,     0,   192,   197,   401,   210,     0,   209,   308,   312,
   297,     0,     0,     0,   189,   191,   187,     0,   185,   182,
     0,     0,     0,     0,     0,     0,     0,     0,   273,     0,
   426,   298,     0,     0,   315,   316,   302,   335,   338,   342,
   385,   392,     0,   390,   458,   457,     0,   380,   381,   449,
   400,   250,   331,   108,   112,   110,     0,   468,   469,     0,
     0,     0,   277,     0,    77,    96,   118,   117,     0,     0,
   357,   374,   349,   333,   329,   320,   322,   319,   207,     0,
     0,    80,    82,    91,     0,   184,     0,   245,     0,   252,
   260,   255,     0,     0,     0,   281,     0,     0,   299,   387,
   459,     0,     0,   229,   223,   231,   235,     0,   122,   116,
     0,     0,   309,   313,   188,   186,   253,   256,   474,   275,
     0,     0,   300,   240,     0,   269,   375,   321,     0,   282,
   327,   241,     0,     0,   261,   242,     0,     0,     0
};

static const short yydefgoto[] = {   817,
    61,    62,    63,    64,    65,    66,    67,    68,    69,    70,
    71,    72,    73,    74,    75,    76,    77,    78,    79,   251,
    80,    81,    82,    83,    84,    85,    86,    87,    88,    89,
   525,   526,   527,    90,    91,    92,   206,   190,   512,   513,
    93,   224,   379,   529,   530,   531,   532,    94,   191,   192,
   193,   194,   195,   196,    95,   235,   236,   237,   391,   392,
    96,    97,    98,    99,   100,   101,   276,   277,   282,   283,
   102,   103,   292,   597,   293,   596,   698,   699,   434,   104,
   240,   241,   398,   105,   225,   106,   232,   107,   248,   249,
   400,   687,   108,   262,   263,   109,   200,   201,   519,   741,
   202,   203,   653,   654,   655,   656,   359,   360,   204,   782,
   110,   446,   701,   111,   112,   113,   114,   115,   116,   447,
   117,   118,   119,   120,   383,   121,   373,   744,   122,   123,
   124,   606,   372,   125,   607,   126,   127,   128,   129,   245,
   130,   309,   462,   131,   267,   132,   133,   134,   135,   574,
   760,   136,   583,   761,   470,   471,   566,   756,   310,   311,
   312,   137,   238,   138,   187,   139,   231,   140,   141,   142,
   143,   144,   145,   472,   170,   146,   227,   551,   552,   553,
   554,   555,   556,   557,   558,   559,   675,   791,   147,   492,
   493,   494,   148,   331,   625,   723,   149,   485,   486,   150,
   171,   172,   501,   502,   684,   325,   314,   315,   316,   317,
   318,   319,   256,   257,   258,   174,   175,   176,   259,   609,
   591,   515,   151,   177,   497,   498,   178,   152,   333,   491,
   179,   180,   181,   474,   659,   435,   448,   347
};

static const short yypact[] = {  1182,
     9,-32768,-32768,  1351,   461,-32768,-32768,    65,-32768,-32768,
    40,-32768,-32768,    61,-32768,    35,    67,    40,-32768,    18,
-32768,-32768,    81,   113,    86,   214,   155,-32768,   169,    40,
-32768,    40,-32768,-32768,   123,-32768,   207,-32768,   292,-32768,
-32768,    40,-32768,   248,-32768,    83,   310,   218,   461,-32768,
-32768,-32768,   757,-32768,    69,   310,-32768,   461,-32768,-32768,
  1268,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,    40,    40,-32768,   294,-32768,-32768,    40,-32768,
   112,-32768,-32768,-32768,-32768,-32768,    40,   266,-32768,    57,
   104,   579,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   265,-32768,-32768,-32768,-32768,   117,-32768,-32768,-32768,  1429,
-32768,-32768,-32768,-32768,    95,-32768,-32768,-32768,-32768,-32768,
   828,-32768,  1113,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
   444,-32768,   507,-32768,   683,-32768,-32768,-32768,   274,-32768,
   303,-32768,-32768,   309,   323,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,   873,-32768,    53,
   303,   328,   409,-32768,-32768,-32768,   303,-32768,-32768,   358,
   394,   493,-32768,-32768,-32768,-32768,   417,-32768,    52,-32768,
   141,-32768,    40,    54,-32768,   435,   443,-32768,    62,   115,
-32768,   103,-32768,-32768,-32768,    63,-32768,   443,   493,-32768,
-32768,-32768,-32768,-32768,   458,-32768,   454,-32768,   462,-32768,
-32768,-32768,   140,   465,   187,-32768,   482,-32768,-32768,   480,
   496,   212,-32768,    40,    17,-32768,    40,   497,    40,   237,
-32768,-32768,-32768,-32768,   489,-32768,    40,   245,-32768,   252,
    40,-32768,  1144,  1144,   152,   -12,-32768,   250,   501,-32768,
    40,   272,-32768,-32768,   502,   287,   504,-32768,   195,   197,
-32768,   236,-32768,   505,-32768,   290,-32768,   443,   590,   119,
   492,   314,-32768,   312,    40,   320,   509,   510,-32768,   512,
-32768,   342,-32768,-32768,-32768,   167,   493,   559,   525,-32768,
-32768,   493,   531,   519,-32768,-32768,  1042,   828,   536,   533,
-32768,-32768,   271,-32768,   607,   609,-32768,   612,   152,   708,
   350,   708,-32768,   542,   271,   708,   543,   708,   544,   126,
   545,   852,-32768,   852,-32768,   873,   191,-32768,   828,-32768,
   733,-32768,  1144,-32768,   873,-32768,   552,   708,-32768,   541,
-32768,-32768,    40,-32768,   189,-32768,-32768,   898,   547,-32768,
-32768,-32768,   323,-32768,    67,-32768,    67,-32768,-32768,    40,
   548,   873,   873,-32768,-32768,-32768,    76,    40,   351,-32768,
    40,   297,   873,-32768,   708,-32768,    40,   551,-32768,-32768,
    40,-32768,   550,   708,   321,-32768,    40,   554,-32768,   555,
-32768,-32768,   218,-32768,-32768,   549,   -12,   -12,  1144,  1144,
  1144,  1144,  1144,-32768,   553,-32768,    71,-32768,-32768,-32768,
   708,-32768,    76,-32768,    76,-32768,    76,-32768,-32768,    40,
-32768,-32768,   923,-32768,-32768,   119,-32768,    40,   119,   353,
-32768,-32768,-32768,-32768,-32768,   873,   370,   493,-32768,-32768,
   558,   564,-32768,   561,-32768,  1042,   612,   563,   191,-32768,
   828,   568,   873,   873,   873,   873,  1042,   565,   566,   403,
-32768,-32768,   271,   569,-32768,   828,   404,-32768,   412,-32768,
   415,-32768,-32768,-32768,   432,-32768,   271,-32768,   947,   152,
   571,   578,   580,-32768,   433,   271,   436,-32768,-32768,   371,
   581,   584,   271,   139,-32768,   440,   373,   441,-32768,-32768,
-32768,   446,-32768,   152,   576,   124,-32768,-32768,  1063,-32768,
-32768,   200,   204,-32768,   583,   585,-32768,-32768,   453,   586,
   303,-32768,   588,-32768,   589,-32768,-32768,-32768,-32768,-32768,
-32768,   297,-32768,-32768,-32768,   675,-32768,-32768,   676,-32768,
   594,   297,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   217,
   456,-32768,-32768,-32768,-32768,   463,-32768,   591,   610,-32768,
   873,    40,-32768,   828,-32768,   -12,   -12,-32768,-32768,-32768,
-32768,-32768,   828,   469,   611,   613,   614,-32768,   616,   152,
   617,-32768,-32768,-32768,-32768,   684,   540,   271,   968,-32768,
-32768,   470,-32768,-32768,-32768,   873,   620,   152,   618,   828,
-32768,-32768,   607,   607,   609,-32768,   682,   344,   708,   778,
   398,   621,   635,   636,   638,   493,-32768,   803,-32768,   637,
   993,-32768,   373,-32768,   873,-32768,-32768,   873,-32768,   640,
   641,-32768,   898,  1018,-32768,   605,   639,-32768,-32768,-32768,
   473,   473,   642,-32768,   645,-32768,-32768,   655,-32768,-32768,
   643,-32768,   662,    76,-32768,    40,    40,-32768,   733,-32768,
    40,   170,-32768,-32768,  1042,   663,-32768,-32768,   664,   666,
    40,   778,-32768,-32768,   271,-32768,   667,   443,   533,   533,
-32768,   668,   670,   671,-32768,-32768,   677,   474,-32768,-32768,
   687,  1042,   689,   493,   690,   477,   493,   225,-32768,  1042,
   697,-32768,   828,   399,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,   692,-32768,-32768,-32768,   705,-32768,-32768,-32768,
   271,-32768,-32768,-32768,-32768,-32768,  1042,-32768,-32768,  1063,
   701,  1088,-32768,   691,-32768,-32768,-32768,-32768,   486,   494,
-32768,-32768,-32768,-32768,-32768,-32768,   700,-32768,-32768,   710,
   714,-32768,-32768,-32768,   787,-32768,   684,-32768,   717,-32768,
-32768,-32768,   730,   727,   732,   729,  1042,   400,-32768,-32768,
-32768,   736,   731,-32768,-32768,-32768,-32768,   734,-32768,-32768,
   726,   778,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
  1042,   740,-32768,-32768,  1042,-32768,-32768,-32768,   493,-32768,
-32768,   751,   756,  1042,-32768,-32768,   846,   847,-32768
};

static const short yypgoto[] = {-32768,
-32768,   788,-32768,-32768,   848,-32768,-32768,   850,-32768,-32768,
-32768,-32768,   747,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   765,  -100,-32768,-32768,-32768,
  -126,-32768,   206,-32768,-32768,-32768,-32768,    -9,-32768,   229,
-32768,-32768,-32768,   202,  -281,-32768,-32768,-32768,   674,  -167,
-32768,   695,  -172,-32768,-32768,-32768,   654,-32768,-32768,   484,
-32768,   -99,-32768,-32768,   -97,   -96,-32768,   460,   -81,   455,
-32768,-32768,-32768,-32768,   295,-32768,-32768,   130,  -101,-32768,
   652,   503,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   495,
-32768,-32768,-32768,-32768,   498,-32768,-32768,  -174,-32768,-32768,
-32768,   546,-32768,   174,-32768,   175,-32768,   402,  -184,-32768,
-32768,-32768,-32768,     2,-32768,-32768,-32768,-32768,-32768,  -423,
-32768,-32768,   892,    23,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,   143,-32768,-32768,-32768,-32768,   865,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,  -222,   304,-32768,-32768,  -287,  -432,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,  -131,   160,-32768,-32768,-32768,   380,  -520,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,   305,-32768,-32768,-32768,-32768,-32768,-32768,   311,-32768,
-32768,-32768,-32768,-32768,-32768,     0,-32768,   -36,   475,   459,
  -277,   -52,  -217,   -94,    64,   598,-32768,  -491,  -558,  -677,
  -591,   298,  -182,-32768,  -327,   327,-32768,-32768,  -109,  -458,
    34,    50,    42,    -7,-32768,  -263,    -6,  -201
};


#define	YYLAST		1514


static const short yytable[] = {   182,
   255,   288,   289,   186,   290,   291,   197,   371,   207,   324,
   208,   327,   209,   329,   361,   432,   362,   506,   205,   286,
   458,   356,   223,   352,   226,   366,   602,   657,   611,   457,
   630,   677,   776,   153,   233,   407,   408,   153,   242,   246,
   703,   155,   184,   185,   335,   155,   215,   264,   246,   154,
   153,   500,   210,   154,   184,   185,   184,   185,   155,   184,
   185,   340,   342,   184,   185,     3,   154,   344,   173,     2,
     3,   184,   185,   184,   185,   269,   270,   188,   184,   185,
   411,   272,   412,   274,   188,   184,   185,   275,   211,   278,
   281,   281,   284,   284,   153,   452,   156,     2,     3,   477,
   454,   183,   155,   479,   389,   481,   184,   185,   296,   297,
   154,   234,   173,   302,   184,   185,   752,     2,     3,   184,
   185,   173,   198,   810,   431,   508,   184,   469,     2,     3,
   313,   159,   160,   161,   162,   163,   164,   165,   166,   167,
   338,   354,   301,   769,   339,   783,   349,   307,   189,   280,
   369,   677,   199,   153,   370,   189,   260,   199,   304,   738,
   739,   155,   561,   261,   188,   261,   306,   337,   524,   154,
    37,   212,   727,   239,   305,   537,   216,   611,   303,   706,
   356,   350,   538,   539,   540,   197,   197,   352,   621,   617,
   517,   576,   577,   541,   367,   285,   173,   368,   584,   273,
   213,   205,   364,   440,   228,   199,   365,   295,   250,   433,
   463,   464,   188,   812,   199,   483,   168,   266,   484,   463,
   464,   253,   816,   463,   464,   254,   388,   376,   351,   393,
   377,   242,  -460,   153,   409,   189,   463,   464,   410,   401,
   363,   155,   221,   406,   463,   464,   601,   409,   657,   154,
   657,   410,   217,   415,   449,   660,   222,   450,   451,   751,
   542,   543,   567,   544,   545,   546,   218,   547,   548,   549,
   550,   219,   413,   343,   380,   281,   510,   284,   381,   490,
   499,   490,   422,   189,   424,   423,   689,   425,   504,   661,
   463,   464,   321,   662,   302,   690,   585,   229,   586,   386,
   587,   220,   537,   387,   230,   514,   678,   459,   247,   538,
   539,   540,   184,   185,   775,   243,   578,   579,   580,   473,
   541,   473,   244,   426,   396,   473,   427,   473,   397,   487,
   714,   361,   402,   362,   592,   496,   403,   594,   313,   404,
   503,   749,   234,   405,   496,   197,     2,     3,    34,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   279,   416,
   520,   294,   208,   417,   330,   307,   205,   495,   205,   528,
   533,   522,   523,   536,   419,     2,     3,   429,   420,   562,
   590,   430,   560,   393,   747,   748,   568,   542,   543,   242,
   544,   545,   546,   332,   547,   548,   549,   550,   153,   334,
   153,   437,   358,   608,   439,   438,   155,   441,   155,   264,
   569,   438,   397,   336,   154,   528,   154,   528,   341,   528,
   275,   668,   278,   670,   722,   778,   613,   614,   281,   444,
   284,   712,   343,   445,   308,   713,   490,   475,   534,   253,
   595,   476,   535,   254,   438,   598,     2,     3,  -396,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   636,   599,
   313,   600,   461,     2,     3,   307,   159,   160,   161,   162,
   163,   164,   165,   166,   167,   313,   660,   626,   159,   160,
   161,   162,   163,   164,   345,   717,   779,   803,   716,   461,
   461,   461,   618,   622,   619,   619,   288,   289,   346,   290,
   291,   623,   771,   619,   624,   774,   619,   348,   646,     2,
     3,   658,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   627,  -381,   628,  -381,   634,   357,   635,   307,   639,
   641,   635,   619,   358,   322,   642,   323,   643,   299,   253,
   640,   374,   665,   254,   666,   679,   255,   619,   306,   375,
   758,   168,   680,   169,   681,   378,   305,   363,   691,   705,
   619,   600,   686,   766,   688,   767,   773,   384,   600,    10,
   685,    12,   382,   313,    15,   789,   399,   635,   490,    20,
    21,    22,   313,   790,   436,   666,   385,   394,   414,   418,
   514,   514,   428,   704,   421,   431,   442,   326,   707,   323,
   443,    41,   253,    43,   280,   708,   254,   813,    10,   313,
    12,   218,   453,    15,    52,   456,   504,   313,    20,    21,
    22,   455,   255,   460,   461,   465,   466,   487,   467,   478,
   480,   482,   488,   507,   496,   509,   575,   731,   516,   521,
    41,   565,    43,   711,   287,   563,   572,   581,   603,   255,
   571,   604,   605,    52,   610,   612,   528,   608,   533,   533,
   808,  -465,  -466,   533,   631,   620,   729,   632,   496,   644,
   637,   633,   663,   757,   306,   638,   664,   667,   669,   671,
   673,   674,   305,   676,   590,     2,     3,   682,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   683,-32768,   697,
   692,   737,   693,   694,   307,   695,   696,   709,   718,   710,
   468,   469,   313,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   719,   720,   608,   721,   725,   732,   733,   307,
   743,  -473,   658,   740,   787,     2,     3,   742,   159,   160,
   161,   162,   163,   164,   165,   166,   167,  -233,   608,   745,
   753,   754,   590,   755,   307,   762,   759,   763,   764,     2,
     3,   590,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   788,   765,   328,   768,   323,   770,   772,   253,   780,
     2,     3,   254,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   809,   777,   781,   785,   792,   793,   168,   307,
   323,   794,   795,   253,   797,     2,     3,   254,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   798,   799,   800,
   801,   806,   805,   168,   307,   804,   489,   807,   253,   811,
     2,     3,   254,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   814,   815,   252,   818,   819,   168,   268,   307,
   271,   157,   253,   158,     2,     3,   254,   159,   160,   161,
   162,   163,   164,   165,   166,   167,   300,   355,   168,   746,
   323,   734,   750,   253,   564,     2,     3,   254,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   353,   390,   588,
   395,   700,   593,   168,   307,   484,   796,   573,   253,   570,
     2,     3,   254,   159,   160,   161,   162,   163,   164,   165,
   166,   167,   518,   784,   582,   214,   786,   645,   308,   802,
   265,   672,   715,   253,   616,     2,     3,   254,   159,   160,
   161,   162,   163,   164,   165,   166,   167,   728,   724,   615,
   505,   736,   168,     0,     0,   489,     0,   253,     0,     2,
     3,   254,   159,   160,   161,   162,   163,   164,   165,   166,
   167,   730,     0,   168,     0,     0,     0,     0,   253,     0,
     2,     3,   254,   159,   160,   161,   162,   163,   164,   165,
   166,   167,     0,     0,     0,     0,     0,     0,   168,     0,
   511,     0,     0,   253,     0,     2,     3,   254,   159,   160,
   161,   162,   163,   164,   165,   166,   167,     0,     0,     0,
     0,     0,     0,   168,     0,   589,     0,     0,   253,     0,
     2,     3,   254,   159,   160,   161,   162,   163,   164,   165,
   166,   167,     0,     0,     0,     0,   629,   168,     0,     0,
     0,     0,   253,     0,     2,     3,   254,   159,   160,   161,
   162,   163,   164,   165,   166,   167,     0,     0,   168,   702,
     0,     0,     0,   253,     0,   184,   185,   254,   647,   160,
   161,   162,   163,   164,   648,   649,   650,     0,     0,     0,
     0,     0,   726,   168,     0,     0,     0,     0,   253,     0,
   184,   185,   254,   159,   160,   161,   162,   163,   164,   648,
   649,   650,     0,     0,     0,     0,     0,     0,   168,     0,
   735,     0,     0,   253,     0,     2,     3,   254,   159,   160,
   161,   162,   163,   164,   165,   166,   167,     0,     0,     0,
     0,     0,   168,     0,     0,     0,     0,   253,     0,     0,
     0,   254,     0,     0,     0,     0,     2,     3,     0,   159,
   160,   161,   162,   163,   164,   165,   166,   167,   651,     0,
     0,     0,   652,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    -2,     1,   651,     2,     3,     4,   652,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   320,     0,   169,     5,     6,     7,     8,
     9,    10,    11,    12,    13,    14,    15,    16,    17,    18,
    19,    20,    21,    22,    23,    24,    25,    26,    27,    28,
    29,    30,    31,    32,   168,    33,    34,    35,    36,    37,
    38,    39,    40,    41,    42,    43,    44,     0,    45,    46,
    47,    48,     0,    49,    50,    51,    52,    53,    54,    55,
    56,    57,     0,     0,    58,     0,    59,    -1,     1,    60,
     2,     3,     4,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     5,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    15,    16,    17,    18,    19,    20,    21,    22,
    23,    24,    25,    26,    27,    28,    29,    30,    31,    32,
     0,    33,    34,    35,    36,    37,    38,    39,    40,    41,
    42,    43,    44,     0,    45,    46,    47,    48,     0,    49,
    50,    51,    52,    53,    54,    55,    56,    57,     0,     0,
    58,     1,    59,     2,     3,    60,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     5,     6,     7,     8,     9,
    10,    11,    12,    13,    14,    15,    16,    17,    18,    19,
    20,    21,    22,    23,    24,    25,    26,    27,    28,    29,
    30,    31,    32,     0,    33,    34,    35,    36,    37,    38,
     0,    40,    41,    42,    43,    44,     0,    45,    46,    47,
    48,     0,    49,    50,    51,    52,    53,    54,    55,    56,
    57,     2,     3,    58,     0,    59,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     5,     6,     7,     0,     0,     0,    11,
     0,    13,     0,     0,    16,     0,     0,     0,     0,     0,
     0,     0,     0,     0,   298,     0,    28,     0,     0,     0,
     0,     0,     0,     0,    35,    36,    37,     0,     0,    40,
     0,     0,     0,     0,     0,    45,     0,    47,     0,     0,
    49,     0,    51,     0,    53,    54,     0,    56,     0,   299,
     0,    58,     0,    59
};

static const short yycheck[] = {     6,
    53,   102,   102,    11,   102,   102,    14,   209,    18,   141,
    18,   143,    19,   145,   199,   279,   199,   345,    17,   101,
   308,   194,    30,   191,    32,   200,   450,   519,   461,   307,
   489,   552,   710,     0,    42,   253,   254,     4,    46,    47,
   599,     0,     3,     4,   154,     4,    24,    55,    56,     0,
    17,   339,    35,     4,     3,     4,     3,     4,    17,     3,
     4,   171,   172,     3,     4,     4,    17,   177,     5,     3,
     4,     3,     4,     3,     4,    83,    84,    24,     3,     4,
    93,    89,    95,    91,    24,     3,     4,    97,    71,    97,
   100,   101,   100,   101,    61,   297,    88,     3,     4,   322,
   302,    37,    61,   326,    88,   328,     3,     4,   116,   116,
    61,    95,    49,   120,     3,     4,   675,     3,     4,     3,
     4,    58,    88,   801,     6,   348,     3,     4,     3,     4,
   131,     6,     7,     8,     9,    10,    11,    12,    13,    14,
    88,    88,   120,   702,    92,   737,    95,    22,    95,    93,
    88,   672,    91,   120,    92,    95,    88,    91,   125,   651,
   652,   120,   385,    95,    24,    95,   125,   168,    93,   120,
    58,    91,   631,    91,   125,     6,    91,   610,    84,   603,
   353,   189,    13,    14,    15,   193,   194,   355,   476,   467,
   365,   409,   410,    24,    92,    92,   133,    95,   421,    88,
    88,   200,    88,   285,    82,    91,    92,    91,    49,    91,
    20,    21,    24,   805,    91,    90,    91,    58,    93,    20,
    21,    96,   814,    20,    21,   100,   234,    88,    88,   237,
    91,   239,    94,   200,    96,    95,    20,    21,   100,   247,
   199,   200,    88,   251,    20,    21,   448,    96,   740,   200,
   742,   100,    39,   261,    88,   519,    88,    91,    92,    90,
    91,    92,   394,    94,    95,    96,    53,    98,    99,   100,
   101,    58,    23,    24,    88,   285,    88,   285,    92,   332,
    90,   334,    88,    95,    88,    91,   574,    91,   341,    90,
    20,    21,   133,    90,   301,   583,   423,    91,   425,    88,
   427,    88,     6,    92,    13,   358,    90,   308,    91,    13,
    14,    15,     3,     4,    90,     6,   411,   412,   413,   320,
    24,   322,    13,    88,    88,   326,    91,   328,    92,   330,
   618,   516,    88,   516,   436,   336,    92,   439,   339,    88,
   341,   669,    95,    92,   345,   353,     3,     4,    55,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    93,    88,
   370,    97,   370,    92,    91,    22,   365,   334,   367,   377,
   378,   372,   373,   381,    88,     3,     4,    88,    92,   387,
   433,    92,   383,   391,   666,   667,   394,    91,    92,   397,
    94,    95,    96,    91,    98,    99,   100,   101,   365,    91,
   367,    88,    91,   456,    93,    92,   365,    88,   367,   417,
    90,    92,    92,    91,   365,   423,   367,   425,    91,   427,
   430,   531,   430,   533,   626,   713,   463,   464,   438,    88,
   438,    88,    24,    92,    91,    92,   489,    88,    88,    96,
    88,    92,    92,   100,    92,   446,     3,     4,    91,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    88,    90,
   461,    92,    92,     3,     4,    22,     6,     7,     8,     9,
    10,    11,    12,    13,    14,   476,   740,   484,     6,     7,
     8,     9,    10,    11,    91,    88,    88,    88,   620,    92,
    92,    92,    90,    90,    92,    92,   597,   597,     6,   597,
   597,    90,   704,    92,    90,   707,    92,    91,   516,     3,
     4,   519,     6,     7,     8,     9,    10,    11,    12,    13,
    14,    90,    90,    92,    92,    90,    92,    92,    22,    90,
    90,    92,    92,    91,    91,    90,    93,    92,    81,    96,
   507,    88,    90,   100,    92,    90,   599,    92,   507,    88,
   682,    91,    90,    93,    92,    91,   507,   516,    90,    90,
    92,    92,   572,    90,   572,    92,    90,    88,    92,    30,
   571,    32,    91,   574,    35,    90,    88,    92,   631,    40,
    41,    42,   583,    90,    93,    92,    91,    91,    88,    88,
   643,   644,    88,   600,    91,     6,    88,    91,   605,    93,
    91,    62,    96,    64,    93,   606,   100,   809,    30,   610,
    32,    53,    88,    35,    75,    97,   669,   618,    40,    41,
    42,    91,   675,    88,    92,    19,    18,   628,    17,    88,
    88,    88,    88,    82,   635,    95,    88,   638,    92,    92,
    62,    92,    64,   610,    66,    95,    92,    95,    91,   702,
    97,    88,    92,    75,    92,    88,   664,   710,   666,   667,
   792,    97,    97,   671,    94,    97,   633,    90,   669,    94,
    90,    92,    90,   681,   633,    92,    92,    92,    91,    91,
     6,     6,   633,    90,   737,     3,     4,    97,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    88,    17,    16,
    90,    97,    90,    90,    22,    90,    90,    88,    88,    92,
     3,     4,   713,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    88,    88,   777,    88,    90,    88,    88,    22,
    88,    93,   740,    92,   742,     3,     4,    93,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    93,   801,    88,
    88,    88,   805,    88,    22,    88,    90,    88,    88,     3,
     4,   814,     6,     7,     8,     9,    10,    11,    12,    13,
    14,    81,    96,    91,    88,    93,    88,    88,    96,    88,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,   799,    97,    90,    95,    97,    88,    91,    22,
    93,    88,    16,    96,    88,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    88,    92,    88,
    92,    88,    92,    91,    22,    90,    94,   102,    96,    90,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    92,    88,    88,     0,     0,    91,    61,    22,
    86,     4,    96,     4,     3,     4,   100,     6,     7,     8,
     9,    10,    11,    12,    13,    14,   120,   194,    91,   664,
    93,   643,   671,    96,   391,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,   193,   235,   430,
   239,   597,   438,    91,    22,    93,   767,   403,    96,   397,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,   367,   740,   417,    24,   742,   516,    91,   777,
    56,   542,   619,    96,   466,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,   633,   628,   465,
   343,   644,    91,    -1,    -1,    94,    -1,    96,    -1,     3,
     4,   100,     6,     7,     8,     9,    10,    11,    12,    13,
    14,   635,    -1,    91,    -1,    -1,    -1,    -1,    96,    -1,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    91,    -1,
    93,    -1,    -1,    96,    -1,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
    -1,    -1,    -1,    91,    -1,    93,    -1,    -1,    96,    -1,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    -1,    -1,    -1,    -1,    90,    91,    -1,    -1,
    -1,    -1,    96,    -1,     3,     4,   100,     6,     7,     8,
     9,    10,    11,    12,    13,    14,    -1,    -1,    91,    92,
    -1,    -1,    -1,    96,    -1,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
    -1,    -1,    90,    91,    -1,    -1,    -1,    -1,    96,    -1,
     3,     4,   100,     6,     7,     8,     9,    10,    11,    12,
    13,    14,    -1,    -1,    -1,    -1,    -1,    -1,    91,    -1,
    93,    -1,    -1,    96,    -1,     3,     4,   100,     6,     7,
     8,     9,    10,    11,    12,    13,    14,    -1,    -1,    -1,
    -1,    -1,    91,    -1,    -1,    -1,    -1,    96,    -1,    -1,
    -1,   100,    -1,    -1,    -1,    -1,     3,     4,    -1,     6,
     7,     8,     9,    10,    11,    12,    13,    14,    96,    -1,
    -1,    -1,   100,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,     0,     1,    96,     3,     4,     5,   100,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    91,    -1,    93,    25,    26,    27,    28,
    29,    30,    31,    32,    33,    34,    35,    36,    37,    38,
    39,    40,    41,    42,    43,    44,    45,    46,    47,    48,
    49,    50,    51,    52,    91,    54,    55,    56,    57,    58,
    59,    60,    61,    62,    63,    64,    65,    -1,    67,    68,
    69,    70,    -1,    72,    73,    74,    75,    76,    77,    78,
    79,    80,    -1,    -1,    83,    -1,    85,     0,     1,    88,
     3,     4,     5,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    25,    26,    27,    28,    29,    30,    31,    32,
    33,    34,    35,    36,    37,    38,    39,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    -1,    54,    55,    56,    57,    58,    59,    60,    61,    62,
    63,    64,    65,    -1,    67,    68,    69,    70,    -1,    72,
    73,    74,    75,    76,    77,    78,    79,    80,    -1,    -1,
    83,     1,    85,     3,     4,    88,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    25,    26,    27,    28,    29,
    30,    31,    32,    33,    34,    35,    36,    37,    38,    39,
    40,    41,    42,    43,    44,    45,    46,    47,    48,    49,
    50,    51,    52,    -1,    54,    55,    56,    57,    58,    59,
    -1,    61,    62,    63,    64,    65,    -1,    67,    68,    69,
    70,    -1,    72,    73,    74,    75,    76,    77,    78,    79,
    80,     3,     4,    83,    -1,    85,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    25,    26,    27,    -1,    -1,    -1,    31,
    -1,    33,    -1,    -1,    36,    -1,    -1,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    46,    -1,    48,    -1,    -1,    -1,
    -1,    -1,    -1,    -1,    56,    57,    58,    -1,    -1,    61,
    -1,    -1,    -1,    -1,    -1,    67,    -1,    69,    -1,    -1,
    72,    -1,    74,    -1,    76,    77,    -1,    79,    -1,    81,
    -1,    83,    -1,    85
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "/usr/lib/bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Bob Corbett and Richard Stallman

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 1, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */


#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
#if defined (MSDOS) && !defined (__TURBOC__)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#define YYLEX		yylex(&yylval, &yylloc)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_bcopy(FROM,TO,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (from, to, count)
     char *from;
     char *to;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_bcopy (char *from, char *to, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 184 "/usr/lib/bison.simple"
int
yyparse()
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_bcopy ((char *)yyss1, (char *)yyss, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_bcopy ((char *)yyvs1, (char *)yyvs, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_bcopy ((char *)yyls1, (char *)yyls, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 5:
#line 267 "fortran.y"
{
				/* Create id token for prog if unnamed. */
			  if(current_module_hash == -1) {
			    implied_id_token(&(yyvsp[0]),unnamed_prog);
			    def_function(
					 type_PROGRAM,	/* type */
					 size_DEFAULT,	/* size */
					 (char *)NULL,	/* size text */
					 &(yyvsp[0]),		/* name */
					 (Token*)NULL);	/* args */
			    current_module_hash =
			      def_curr_module(&(yyvsp[0]));
			    current_module_type = type_PROGRAM;
			  }

					/* Handle END statement */
			  if(curr_stmt_class == tok_END) {
			    if(prev_stmt_class != tok_RETURN)
			      do_RETURN(current_module_hash,&(yyvsp[0]));
			    END_processing(&(yyval));
			    goto_flag = prev_goto = FALSE;
			  }
			  prev_stmt_class = curr_stmt_class;
			  integer_context = FALSE;
			  true_prev_stmt_line_num = yyval.line_num;
			;
    break;}
case 10:
#line 307 "fortran.y"
{
#ifdef CHECK_LABELS
			  def_label(&(yyvsp[-1]));
#endif
			  if(executable_stmt)
			    prev_goto = goto_flag;
			;
    break;}
case 11:
#line 315 "fortran.y"
{
			  if(executable_stmt) {
			    if(prev_goto)
				syntax_error(yyvsp[0].line_num, NO_COL_NUM,
					"No path to this statement");
			    prev_goto = goto_flag;
			  }
			;
    break;}
case 12:
#line 326 "fortran.y"
{
			    exec_stmt_count = 0;
			    executable_stmt = FALSE;
			;
    break;}
case 13:
#line 331 "fortran.y"
{
			    executable_stmt = FALSE;
			;
    break;}
case 14:
#line 335 "fortran.y"
{	/* handle statement functions correctly */
			  if(is_true(STMT_FUNCTION_EXPR, yyvsp[0].TOK_flags)
				     && stmt_sequence_no <= SEQ_STMT_FUN) {
			    stmt_sequence_no = SEQ_STMT_FUN;
			    executable_stmt = FALSE;
			  }
			  else {
			    stmt_sequence_no = SEQ_EXEC;
			    ++exec_stmt_count;
			    executable_stmt = TRUE;
			  }
			;
    break;}
case 15:
#line 348 "fortran.y"
{
			    stmt_sequence_no = SEQ_EXEC;
			    ++exec_stmt_count;
			    executable_stmt = TRUE;
			;
    break;}
case 16:
#line 354 "fortran.y"
{
			    executable_stmt = TRUE;
			    if(stmt_sequence_no == 0)
			      stmt_sequence_no = SEQ_HEADER;
			    complex_const_allowed = FALSE; /* turn off flags */
			    inside_format=FALSE;
			    integer_context = FALSE;
			    in_assignment_stmt = FALSE;
			    yyval.line_num = prev_stmt_line_num; /* best guess */
			    yyerrok; /* (error message already given) */
			;
    break;}
case 17:
#line 368 "fortran.y"
{
			    current_module_type = type_PROGRAM;
			;
    break;}
case 18:
#line 372 "fortran.y"
{
			    current_module_type = type_SUBROUTINE;
			;
    break;}
case 19:
#line 376 "fortran.y"
{
			    current_module_type = type_SUBROUTINE;
			;
    break;}
case 20:
#line 380 "fortran.y"
{
			    current_module_type = type_BLOCK_DATA;
			;
    break;}
case 24:
#line 393 "fortran.y"
{
#ifdef ALLOW_INCLUDE
			  if(f77_include) {
			      nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			  }
 			  open_include_file(yyvsp[-1].value.string,yyvsp[-2].line_num);
#else
			  syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
				"statement not permitted");
#endif
 			;
    break;}
case 25:
#line 412 "fortran.y"
{
			     if(stmt_sequence_no < SEQ_IMPLICIT) {
				stmt_sequence_no = SEQ_IMPLICIT;
			     }
			;
    break;}
case 26:
#line 418 "fortran.y"
{
			     if(stmt_sequence_no < SEQ_IMPLICIT) {
				   stmt_sequence_no = SEQ_IMPLICIT;
			     }
			     else if(stmt_sequence_no > SEQ_SPECIF) {
			       check_stmt_sequence(&(yyvsp[0]),SEQ_SPECIF);
			     }
			;
    break;}
case 27:
#line 427 "fortran.y"
{
			  check_stmt_sequence(&(yyvsp[0]),SEQ_IMPLICIT);
			;
    break;}
case 28:
#line 431 "fortran.y"
{
			     if(stmt_sequence_no < SEQ_STMT_FUN) {
				stmt_sequence_no = SEQ_STMT_FUN;
		 	     }
			;
    break;}
case 29:
#line 437 "fortran.y"
{
			  check_stmt_sequence(&(yyvsp[0]),SEQ_SPECIF);
			;
    break;}
case 30:
#line 443 "fortran.y"
{
			     goto_flag = prev_goto = FALSE;
			;
    break;}
case 41:
#line 464 "fortran.y"
{
			    goto_flag=TRUE;
			;
    break;}
case 42:
#line 468 "fortran.y"
{
			    goto_flag=FALSE;
			;
    break;}
case 65:
#line 501 "fortran.y"
{
			    goto_flag=FALSE;
			;
    break;}
case 66:
#line 505 "fortran.y"
{
			    prev_goto = goto_flag =FALSE;
			;
    break;}
case 69:
#line 514 "fortran.y"
{	/* Flag DO w/o label or DO WHILE forms here */
			  if(is_true(NONSTD_USAGE_FLAG,yyvsp[0].TOK_flags))
#ifdef ALLOW_DO_ENDDO
			    if(f77_do_enddo)
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
#else
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				    "Nonstandard syntax");
#endif
			;
    break;}
case 70:
#line 526 "fortran.y"
{
#ifdef ALLOW_DO_ENDDO
			    if(f77_do_enddo)
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
#else
			    syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
				    "Nonstandard syntax");
#endif
			;
    break;}
case 74:
#line 543 "fortran.y"
{check_seq_header(&(yyvsp[0]));;
    break;}
case 75:
#line 545 "fortran.y"
{
			     def_function(
					  type_PROGRAM,	/* type */
					  size_DEFAULT,	/* size */
					  (char *)NULL,	/* size text */
					  &(yyvsp[-1]),	/* name */
					  (Token*)NULL);/* args */
			     current_module_hash =
			       def_curr_module(&(yyvsp[-1]));
			;
    break;}
case 76:
#line 562 "fortran.y"
{
			  do_ENTRY(&(yyvsp[-1]),(Token*)NULL
				   ,current_module_hash);
			;
    break;}
case 77:
#line 567 "fortran.y"
{
			  do_ENTRY(&(yyvsp[-4]),&(yyvsp[-2])
				   ,current_module_hash);
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_exprlist("entry stmt",&(yyvsp[-2]));
#endif
			;
    break;}
case 79:
#line 583 "fortran.y"
{
			     if(f77_function_noparen) {
				nonstandard(yyvsp[-1].line_num,
			     (unsigned)(yyvsp[-1].col_num+strlen(token_name(yyvsp[-1]))));
				msg_tail(": parentheses required");
			     }
			 def_function(
				      current_datatype,
				      current_typesize,
				      current_len_text,
				      &(yyvsp[-1]),
				      (Token*)NULL);
			 current_module_hash=
			   def_curr_module(&(yyvsp[-1]));
			;
    break;}
case 80:
#line 600 "fortran.y"
{
			 def_function(
				      current_datatype,
				      current_typesize,
				      current_len_text,
				      &(yyvsp[-4]),
				      &(yyvsp[-2]));
			 current_module_hash=
			   def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			 if(debug_parser)
			   print_exprlist("function stmt",&(yyvsp[-2]));
#endif
			;
    break;}
case 81:
#line 615 "fortran.y"
{
			     if(f77_function_noparen) {
				nonstandard(yyvsp[-1].line_num,
			      (unsigned)(yyvsp[-1].col_num+strlen(token_name(yyvsp[-1]))));
				msg_tail(": parentheses required");
			     }
			 def_function(
				      type_UNDECL,
				      size_DEFAULT,
				      (char *)NULL,
				      &(yyvsp[-1]),
				      (Token*)NULL);
			 current_module_hash=
			   def_curr_module(&(yyvsp[-1]));
			;
    break;}
case 82:
#line 632 "fortran.y"
{
			 def_function(
				      type_UNDECL,	/* type */
				      size_DEFAULT,	/* size */
				      (char *)NULL,	/* size text */
				      &(yyvsp[-4]),		/* name */
				      &(yyvsp[-2]));		/* args */
			 current_module_hash=
			   def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			 if(debug_parser)
			   print_exprlist("function stmt",&(yyvsp[-2]));
#endif
			;
    break;}
case 85:
#line 655 "fortran.y"
{
			  check_seq_header(&(yyvsp[0]));
			;
    break;}
case 90:
#line 674 "fortran.y"
{
			  def_function(
				       type_SUBROUTINE,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-1]),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyvsp[-1]));
			;
    break;}
case 91:
#line 686 "fortran.y"
{
			  def_function(
				       type_SUBROUTINE,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-4]),
				       &(yyvsp[-2]));
			  current_module_hash=
			    def_curr_module(&(yyvsp[-4]));
#ifdef DEBUG_PARSER
			  if(debug_parser)
			    print_exprlist("subroutine stmt",&(yyvsp[-2]));
#endif
			;
    break;}
case 92:
#line 703 "fortran.y"
{
			  check_seq_header(&(yyvsp[0]));
			;
    break;}
case 93:
#line 709 "fortran.y"
{
			    yyval.next_token = (Token*)NULL;
			;
    break;}
case 95:
#line 716 "fortran.y"
{
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 96:
#line 720 "fortran.y"
{
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 97:
#line 726 "fortran.y"
{
			     def_arg_name(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			;
    break;}
case 98:
#line 731 "fortran.y"
{
			     yyval.TOK_type = type_byte(class_LABEL,type_LABEL);
			     yyval.size = size_DEFAULT;
			     yyval.TOK_flags = 0;
			     yyval.left_token = (Token *)NULL;
			;
    break;}
case 99:
#line 743 "fortran.y"
{
				  /* form name %DATnn */
			  ++block_data_number;
			  (void)sprintf(unnamed_block_data+4,"%02d",
					block_data_number%100);
			  implied_id_token(&(yyval),unnamed_block_data);

			  def_function(
				       type_BLOCK_DATA,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyval),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyval));
			;
    break;}
case 100:
#line 760 "fortran.y"
{
			  def_function(
				       type_BLOCK_DATA,
				       size_DEFAULT,
				       (char *)NULL,
				       &(yyvsp[-1]),
				       (Token*)NULL);
			  current_module_hash=
			    def_curr_module(&(yyvsp[-1]));
			;
    break;}
case 101:
#line 773 "fortran.y"
{
			  check_seq_header(&(yyvsp[0]));
			;
    break;}
case 102:
#line 777 "fortran.y"
{
			  check_seq_header(&(yyvsp[0]));
			;
    break;}
case 106:
#line 792 "fortran.y"
{
			     def_array_dim(&(yyvsp[-3]),&(yyvsp[-1]));
			;
    break;}
case 107:
#line 799 "fortran.y"
{
			     yyval.TOK_dims = 1;
			     yyval.TOK_elts = yyvsp[0].TOK_elts;
			     yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 108:
#line 805 "fortran.y"
{
			     yyval.TOK_dims = yyvsp[-2].TOK_dims + 1; /* one more dimension */
			     yyval.TOK_elts = yyvsp[-2].TOK_elts * yyvsp[0].TOK_elts;
			     yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 109:
#line 813 "fortran.y"
{
			      if( datatype_of(yyvsp[0].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.TOK_elts = yyvsp[0].value.integer;
			      else
				yyval.TOK_elts = 0;
			;
    break;}
case 110:
#line 821 "fortran.y"
{	/* avoid getting 0 - 0 + 1 = 1 if bounds nonconstant */
			      if( datatype_of(yyvsp[-2].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[-2].TOK_flags)
				 && datatype_of(yyvsp[0].TOK_type) == type_INTEGER
				 && is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.TOK_elts = yyvsp[0].value.integer - yyvsp[-2].value.integer + 1;
			      else
				yyval.TOK_elts = 0;

			      yyval.left_token = add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),&(yyvsp[0]));
			;
    break;}
case 111:
#line 833 "fortran.y"
{
			     yyval.TOK_elts = 0;
			     yyval.left_token = (Token *)NULL;
			;
    break;}
case 112:
#line 838 "fortran.y"
{
			     yyval.TOK_elts = 0;
			     yyvsp[0].left_token = (Token *)NULL;
			     yyval.left_token = add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),&(yyvsp[0]));
			;
    break;}
case 113:
#line 846 "fortran.y"
{equivalence_flag = TRUE;;
    break;}
case 114:
#line 847 "fortran.y"
{equivalence_flag = FALSE;;
    break;}
case 117:
#line 855 "fortran.y"
{
			  equivalence(&(yyvsp[-2]), &(yyvsp[0]));
			;
    break;}
case 118:
#line 859 "fortran.y"
{
			  equivalence(&(yyvsp[-2]), &(yyvsp[0]));
			;
    break;}
case 119:
#line 866 "fortran.y"
{
			     def_equiv_name(&(yyvsp[0]));
			;
    break;}
case 120:
#line 870 "fortran.y"
{
			     def_equiv_name(&(yyvsp[0]));
			;
    break;}
case 121:
#line 874 "fortran.y"
{
			     def_equiv_name(&(yyvsp[0]));
			;
    break;}
case 125:
#line 889 "fortran.y"
{
			     implied_id_token(&(yyval),blank_com_name);
			     def_com_block(&(yyval), &(yyvsp[-1]));
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
			   	syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("blank common",&(yyvsp[-1]));
#endif

			;
    break;}
case 126:
#line 903 "fortran.y"
{
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");

			;
    break;}
case 127:
#line 911 "fortran.y"
{
			     implied_id_token(&(yyval),blank_com_name);
			     def_com_block(&(yyval),&(yyvsp[-2]));
			     if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					     yyvsp[-1].line_num,yyvsp[-1].col_num,
					     "trailing comma");
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("blank common",&(yyvsp[-2]));
#endif
			;
    break;}
case 128:
#line 929 "fortran.y"
{
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			;
    break;}
case 129:
#line 933 "fortran.y"
{
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     yyval.line_num = yyvsp[0].line_num;
			     yyval.col_num = yyvsp[0].col_num;
			;
    break;}
case 130:
#line 941 "fortran.y"
{
			     def_com_block(&(yyvsp[-1]),&(yyvsp[0]));
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     yyval.line_num = yyvsp[0].line_num;
			     yyval.col_num = yyvsp[0].col_num;
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_comlist("labeled common",&(yyvsp[0]));
#endif
			;
    break;}
case 131:
#line 954 "fortran.y"
{
			     yyval = yyvsp[-1];
			;
    break;}
case 132:
#line 959 "fortran.y"
{
			     implied_id_token(&(yyval),blank_com_name);
			;
    break;}
case 133:
#line 963 "fortran.y"
{
			     implied_id_token(&(yyval),blank_com_name);
			;
    break;}
case 134:
#line 969 "fortran.y"
{
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 135:
#line 974 "fortran.y"
{
			    if(!is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num-1,
					"missing comma");
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.line_num = yyvsp[0].line_num;
			    yyval.col_num = yyvsp[0].col_num;
			    yyval.next_token = append_token(yyvsp[-1].next_token,&(yyvsp[0]));
			;
    break;}
case 136:
#line 987 "fortran.y"
{			   /* no comma */
			     yyval.TOK_flags = yyvsp[0].TOK_flags;
			     make_false(COMMA_FLAG,yyval.TOK_flags);
			;
    break;}
case 137:
#line 992 "fortran.y"
{			   /* has comma */
			     yyval.TOK_flags = yyvsp[-1].TOK_flags;
			     make_true(COMMA_FLAG,yyval.TOK_flags);
   			;
    break;}
case 138:
#line 999 "fortran.y"
{
			     def_com_variable(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			;
    break;}
case 139:
#line 1004 "fortran.y"
{
			     def_com_variable(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			;
    break;}
case 140:
#line 1017 "fortran.y"
{
			    if(is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(yyvsp[-1].line_num,
				 (unsigned)(yyvsp[-1].col_num+strlen(token_name(yyvsp[-1]))),
					"trailing comma");
			    if(f77_namelist) {
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			    }
			;
    break;}
case 142:
#line 1030 "fortran.y"
{
			    yyval = yyvsp[0];
			;
    break;}
case 143:
#line 1036 "fortran.y"
{
			     def_namelist(&(yyvsp[-1]),&(yyvsp[0]));
			     yyval = yyvsp[0];
			;
    break;}
case 144:
#line 1043 "fortran.y"
{
			    yyval = yyvsp[-1];
			;
    break;}
case 145:
#line 1049 "fortran.y"
{
			     yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 146:
#line 1053 "fortran.y"
{
			    if(!is_true(COMMA_FLAG,yyvsp[-1].TOK_flags))
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num-1,
					"missing comma");
			    yyval.TOK_flags = yyvsp[0].TOK_flags;
			    yyval.line_num = yyvsp[0].line_num;
			    yyval.col_num = yyvsp[0].col_num;
			    yyval.next_token = append_token(yyvsp[-1].next_token,&(yyvsp[0]));
			;
    break;}
case 147:
#line 1066 "fortran.y"
{			   /* no comma */
			     def_namelist_item(&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[0]),&(yyval));
			     make_false(COMMA_FLAG,yyval.TOK_flags);
			;
    break;}
case 148:
#line 1072 "fortran.y"
{			   /* has comma */
			     def_namelist_item(&(yyvsp[-1]));
			     primary_id_expr(&(yyvsp[-1]),&(yyval));
			     make_true(COMMA_FLAG,yyval.TOK_flags);
			;
    break;}
case 153:
#line 1087 "fortran.y"
{
			  current_typesize = size_DEFAULT;
			  current_len_text = NULL;
			;
    break;}
case 154:
#line 1093 "fortran.y"
{
			    current_typesize = yyvsp[0].value.integer;
			    current_len_text = NULL;
#if 0 /* defunct feature */
			    if(local_wordsize > 0) {
			      /*  recognize REAL*2w as DOUBLE PRECISION */
			      if(current_datatype == type_REAL
				 && yyvsp[0].value.integer == type_size[type_DP])
				current_datatype = type_DP;
			      /*  recognize COMPLEX*4w as DOUBLE COMPLEX */
			      if(current_datatype == type_COMPLEX
				 && yyvsp[0].value.integer==type_size[type_DCOMPLEX])
				current_datatype = type_DCOMPLEX;
			    }
#endif
			     if(f77_typesize) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			     }
			;
    break;}
case 156:
#line 1117 "fortran.y"
{
			     current_datatype = type_INTEGER;
			     integer_context = TRUE;
			;
    break;}
case 157:
#line 1122 "fortran.y"
{
			     current_datatype = type_REAL;
			     integer_context = TRUE;
			;
    break;}
case 158:
#line 1127 "fortran.y"
{
			     current_datatype = type_COMPLEX;
			     integer_context = TRUE;
			;
    break;}
case 159:
#line 1132 "fortran.y"
{
			     current_datatype = type_LOGICAL;
			     integer_context = TRUE;
			;
    break;}
case 160:
#line 1139 "fortran.y"
{
			     current_datatype = type_DP;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			;
    break;}
case 161:
#line 1145 "fortran.y"
{
			     current_datatype = type_DP;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			;
    break;}
case 162:
#line 1151 "fortran.y"
{
			     current_datatype = type_DCOMPLEX;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			     if(f77_double_complex) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			     }
			;
    break;}
case 163:
#line 1160 "fortran.y"
{
			     current_datatype = type_DCOMPLEX;
			     current_typesize = size_DEFAULT;
			     current_len_text = NULL;
			     if(f77_double_complex) {
				nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			     }
			;
    break;}
case 164:
#line 1169 "fortran.y"
{
			     current_datatype = type_INTEGER;
			     current_typesize = 1;
			     current_len_text = NULL;
			     if(f77_byte)
			       nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			;
    break;}
case 165:
#line 1179 "fortran.y"
{
			     current_datatype = type_STRING;
			     current_typesize = 1;
			     current_len_text = NULL;
			     current_size_is_adjustable = 0;
			     current_size_is_expression = 0;
			     integer_context = TRUE;
			;
    break;}
case 166:
#line 1190 "fortran.y"
{
			     current_typesize = yyvsp[0].value.integer;
			     current_size_is_adjustable = yyvsp[0].size_is_adjustable;
			     current_size_is_expression = yyvsp[0].size_is_expression;
				/* Save length spec text if expression */
			     if(current_size_is_expression) {
			       if(yyvsp[0].left_token == NULL)
				 current_len_text = new_tree_text(&(yyvsp[0]));
			       else
				 current_len_text = new_tree_text(yyvsp[0].left_token);
			     }
			     else
			       current_len_text = NULL;
			;
    break;}
case 169:
#line 1211 "fortran.y"
{
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			;
    break;}
case 170:
#line 1218 "fortran.y"
{
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			;
    break;}
case 173:
#line 1231 "fortran.y"
{
			     yyvsp[0].size_is_adjustable = current_size_is_adjustable;
			     yyvsp[0].size_is_expression = current_size_is_expression;
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			;
    break;}
case 174:
#line 1240 "fortran.y"
{
			     yyvsp[-2].size_is_adjustable = yyvsp[0].size_is_adjustable;
			     yyvsp[-2].size_is_expression = yyvsp[0].size_is_expression;
			     declare_type(&(yyvsp[-2]),
					  current_datatype,
					  yyvsp[0].value.integer,
					  new_tree_text(
					     yyvsp[0].left_token == NULL?
					     &(yyvsp[0]): yyvsp[0].left_token )
					  );
			;
    break;}
case 175:
#line 1252 "fortran.y"
{
			     yyvsp[0].size_is_adjustable = current_size_is_adjustable;
			     yyvsp[0].size_is_expression = current_size_is_expression;
			     declare_type(&(yyvsp[0]),
					  current_datatype,
					  current_typesize,
					  current_len_text);
			;
    break;}
case 176:
#line 1261 "fortran.y"
{
			     yyvsp[-2].size_is_adjustable = yyvsp[0].size_is_adjustable;
			     yyvsp[-2].size_is_expression = yyvsp[0].size_is_expression;
			     declare_type(&(yyvsp[-2]),
					  current_datatype,
					  yyvsp[0].value.integer,
					  new_tree_text(
					     yyvsp[0].left_token == NULL?
					     &(yyvsp[0]): yyvsp[0].left_token )
					  );
			;
    break;}
case 177:
#line 1276 "fortran.y"
{implicit_flag=TRUE;;
    break;}
case 178:
#line 1280 "fortran.y"
{
			    implicit_flag=FALSE;
			    if(implicit_none) {
				syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
				     "conflicts with IMPLICIT NONE");
			    }
			    else {
				implicit_type_given = TRUE;
			    }
			;
    break;}
case 179:
#line 1292 "fortran.y"
{
			    implicit_flag=FALSE;
				if(implicit_type_given) {
				    syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
					 "conflicts with IMPLICIT statement");
				}
				else {
				    if(f77_implicit_none)
				      nonstandard(yyvsp[-1].line_num,yyvsp[-1].col_num);
				    implicit_none = TRUE;
				}
			;
    break;}
case 181:
#line 1307 "fortran.y"
{initial_flag = TRUE;;
    break;}
case 183:
#line 1313 "fortran.y"
{implicit_letter_flag = TRUE;;
    break;}
case 184:
#line 1314 "fortran.y"
{implicit_letter_flag = FALSE;;
    break;}
case 187:
#line 1322 "fortran.y"
{
			  int c1 = (int)yyvsp[0].subclass;

			  if( (f77_dollarsigns && c1=='$')
			   || (f77_underscores && c1=='_') ) {
			    nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			    msg_tail(": nonalphabetic character");
			  }

			   set_implicit_type(current_datatype,
					     current_typesize,
					     current_len_text,
					     c1,c1);
			;
    break;}
case 188:
#line 1337 "fortran.y"
{
			  int c1 = (int)yyvsp[-2].subclass,
			      c2 = (int)yyvsp[0].subclass;

			  if( (f77_dollarsigns && (c1 == '$' || c2 == '$'))
			   || (f77_underscores && (c1 == '_' || c2 == '_')))
			  {
			    if(!isalpha(c1))
			      nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			    else
			      nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			    msg_tail(": nonalphabetic character");
			  }

			   set_implicit_type(current_datatype,
					     current_typesize,
					     current_len_text,
					     c1,c2);
			;
    break;}
case 189:
#line 1361 "fortran.y"
{
			     yyvsp[-1].left_token = (Token *)NULL;
			     yyval.value.integer = size_ADJUSTABLE;
			     yyval.size_is_adjustable = 1;
			     yyval.size_is_expression = 0;
				/* Store as a parenthesized expr tree */
			     yyval.left_token = add_tree_node(&(yyvsp[-2]),&(yyvsp[-1]),
							  (Token*)NULL);
			;
    break;}
case 190:
#line 1371 "fortran.y"
{
			     yyval.value.integer = yyvsp[0].value.integer;
			     yyval.size_is_adjustable = 0;
			     yyval.size_is_expression = 0;
			;
    break;}
case 191:
#line 1377 "fortran.y"
{
			     yyval = yyvsp[-1];
			     yyval.size_is_adjustable = 0;
			     yyval.size_is_expression = 1;
			     if( yyval.value.integer <= 0 ){
			       warning(yyvsp[-1].line_num,yyvsp[-1].col_num,
					"invalid length specification");
			       msg_tail(": substituting 1");
			       yyval.value.integer = 1;
			     }
			     yyval.left_token = add_tree_node(&(yyvsp[-2]),&(yyvsp[-1]),
							  (Token*)NULL);
			;
    break;}
case 193:
#line 1395 "fortran.y"
{
			    if(f77_param_noparen)
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			;
    break;}
case 196:
#line 1405 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 197:
#line 1407 "fortran.y"
{
			     def_parameter(&(yyvsp[-3]),&(yyvsp[0]));
			     primary_id_expr(&(yyvsp[-3]),&(yyvsp[-3]));
			     assignment_stmt_type(&(yyvsp[-3]),&(yyvsp[-1]),&(yyvsp[0]));
			     complex_const_allowed = FALSE;
			;
    break;}
case 199:
#line 1420 "fortran.y"
{
			     def_ext_name(&(yyvsp[0]));
			;
    break;}
case 200:
#line 1424 "fortran.y"
{
			     def_ext_name(&(yyvsp[0]));
			;
    break;}
case 202:
#line 1434 "fortran.y"
{
			     def_intrins_name(&(yyvsp[0]));
			;
    break;}
case 203:
#line 1438 "fortran.y"
{
			     def_intrins_name(&(yyvsp[0]));
			;
    break;}
case 204:
#line 1445 "fortran.y"
{
		  if(f77_cray_pointers)
		    nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
		;
    break;}
case 208:
#line 1459 "fortran.y"
{
			     declare_type(&(yyvsp[0]),type_INTEGER,local_wordsize,
					  NULL );
			;
    break;}
case 209:
#line 1466 "fortran.y"
{
				/* Suppress set/used warnings since
				   often is accessed only via pointer */
		             use_lvalue(&(yyvsp[0]));
		             use_variable(&(yyvsp[0]));
		        ;
    break;}
case 210:
#line 1473 "fortran.y"
{
		             use_lvalue(&(yyvsp[0]));
		             use_variable(&(yyvsp[0]));
		        ;
    break;}
case 211:
#line 1481 "fortran.y"
{
			  global_save = TRUE;
			;
    break;}
case 215:
#line 1492 "fortran.y"
{
			     save_variable(&(yyvsp[0]));
			;
    break;}
case 216:
#line 1496 "fortran.y"
{
/***			     def_com_block(&($2),(Token*)NULL);***/
			     save_com_block(&(yyvsp[-1]));
			;
    break;}
case 221:
#line 1512 "fortran.y"
{complex_const_allowed=TRUE;;
    break;}
case 222:
#line 1514 "fortran.y"
{complex_const_allowed=FALSE;;
    break;}
case 226:
#line 1523 "fortran.y"
{
			     use_lvalue(&(yyvsp[0]));
			;
    break;}
case 233:
#line 1539 "fortran.y"
{
			     use_parameter(&(yyvsp[0]));
			;
    break;}
case 235:
#line 1546 "fortran.y"
{
			     use_parameter(&(yyvsp[0]));
			;
    break;}
case 238:
#line 1557 "fortran.y"
{
			     use_lvalue(&(yyvsp[0]));
			;
    break;}
case 240:
#line 1565 "fortran.y"
{
			    use_implied_do_index(&(yyvsp[-3]));
			;
    break;}
case 243:
#line 1576 "fortran.y"
{complex_const_allowed = TRUE;
				    in_assignment_stmt = TRUE;;
    break;}
case 244:
#line 1578 "fortran.y"
{
			  if( ! (is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags)
			       || is_true(STMT_FUNCTION_EXPR,yyvsp[-3].TOK_flags) )) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "left side is not assignable");
			  }
			  else {
			    assignment_stmt_type(&(yyvsp[-3]),&(yyvsp[-2]),
					&(yyvsp[0]));
			  }
			  complex_const_allowed = FALSE;
			  in_assignment_stmt = FALSE;
			;
    break;}
case 245:
#line 1592 "fortran.y"
{
				/* Clear u-b-s flags spuriously set */
			  if(is_true(STMT_FUNCTION_EXPR, yyvsp[-5].TOK_flags)
				     && stmt_sequence_no <= SEQ_STMT_FUN)
			     stmt_function_stmt(&(yyvsp[-5]));
		        ;
    break;}
case 250:
#line 1610 "fortran.y"
{
			    do_ASSIGN(&(yyvsp[-1]));
			;
    break;}
case 254:
#line 1627 "fortran.y"
{
			     do_assigned_GOTO(&(yyvsp[-1]));
			;
    break;}
case 255:
#line 1631 "fortran.y"
{
			     do_assigned_GOTO(&(yyvsp[-4]));
			;
    break;}
case 256:
#line 1635 "fortran.y"
{
			     do_assigned_GOTO(&(yyvsp[-5]));
			;
    break;}
case 257:
#line 1641 "fortran.y"
{
			    integer_context=TRUE;
			;
    break;}
case 258:
#line 1645 "fortran.y"
{
			    integer_context=TRUE;
			;
    break;}
case 261:
#line 1657 "fortran.y"
{
			  int t=datatype_of(yyvsp[-9].class);
			  if(t != type_INTEGER && t != type_REAL
			     && t != type_DP && t != type_ERROR ) {
			    syntax_error(yyvsp[-9].line_num,yyvsp[-9].col_num,
		  "integer, real, or double precision expression required");
			  }
			;
    break;}
case 262:
#line 1669 "fortran.y"
{
			  int t=datatype_of(yyvsp[-1].TOK_type);
			  if(t != type_LOGICAL && t != type_ERROR)
			     syntax_error(yyvsp[-1].line_num,yyvsp[-1].col_num,
					  "logical expression required");
			;
    break;}
case 263:
#line 1679 "fortran.y"
{
			  int t=datatype_of(yyvsp[-2].TOK_type);
			  if(t != type_LOGICAL && t != type_ERROR)
			     syntax_error(yyvsp[-2].line_num,yyvsp[-2].col_num,
					  "logical expression required");
			;
    break;}
case 264:
#line 1687 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 265:
#line 1688 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    complex_const_allowed = FALSE;

			    initial_flag = TRUE;	/* for is_keyword */
			    yyval = yyvsp[-1]; /* Inherit expr for type checking above */
			;
    break;}
case 267:
#line 1701 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 268:
#line 1702 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			    complex_const_allowed = FALSE;

			    initial_flag = TRUE;
			;
    break;}
case 273:
#line 1732 "fortran.y"
{
			  if( ! is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags) ) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "index is not assignable");
			  }
			  else {
			     use_lvalue(&(yyvsp[-3]));
			     use_variable(&(yyvsp[-3]));
			  }

				/* Check for non-integer DO index or bounds */
			     if(datatype_of(yyvsp[-3].TOK_type) == type_INTEGER
				&& datatype_of(yyvsp[-1].TOK_type) != type_INTEGER)
			       warning(yyvsp[-2].line_num,yyvsp[-2].col_num,
				  "type mismatch between DO index and bounds");

			     else if(datatype_of(yyvsp[-3].TOK_type) != type_INTEGER)
			       if(datatype_of(yyvsp[-1].TOK_type) != type_INTEGER) {
				 if(port_real_do)
				   nonportable(yyvsp[-1].line_num,yyvsp[-1].col_num,
					       "non-integer DO loop bounds");
			       }
			       else {
				 if(trunc_real_do_index)
				   warning(yyvsp[-3].line_num,yyvsp[-3].col_num,
					   "DO index is not integer");
			       }
			;
    break;}
case 274:
#line 1761 "fortran.y"
{complex_const_allowed=TRUE;;
    break;}
case 275:
#line 1762 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[-2].TOK_flags)){
				use_variable(&(yyvsp[-2]));
			    }
			    complex_const_allowed=FALSE;
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			;
    break;}
case 276:
#line 1770 "fortran.y"
{complex_const_allowed=TRUE;;
    break;}
case 277:
#line 1771 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[-2].TOK_flags)){
				use_variable(&(yyvsp[-2]));
			    }
			    complex_const_allowed=FALSE;
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			;
    break;}
case 280:
#line 1783 "fortran.y"
{
			    make_true(NONSTD_USAGE_FLAG,yyval.TOK_flags);
			    integer_context=FALSE;
			;
    break;}
case 281:
#line 1790 "fortran.y"
{
			    yyval.TOK_type=do_bounds_type(&(yyvsp[-2]),&(yyvsp[0]),&(yyvsp[0]));
			;
    break;}
case 282:
#line 1794 "fortran.y"
{
			    yyval.TOK_type=do_bounds_type(&(yyvsp[-4]),&(yyvsp[-2]),&(yyvsp[0]));
			;
    break;}
case 290:
#line 1818 "fortran.y"
{
			     use_variable(&(yyvsp[0]));
			;
    break;}
case 292:
#line 1826 "fortran.y"
{complex_const_allowed = FALSE;;
    break;}
case 294:
#line 1828 "fortran.y"
{complex_const_allowed = FALSE;;
    break;}
case 296:
#line 1831 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 297:
#line 1833 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 303:
#line 1846 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 304:
#line 1850 "fortran.y"
{
			    if(f77_accept_type)
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			;
    break;}
case 305:
#line 1855 "fortran.y"
{
			    if(f77_accept_type)
				nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num);
			;
    break;}
case 307:
#line 1864 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 308:
#line 1865 "fortran.y"
{complex_const_allowed = FALSE;;
    break;}
case 310:
#line 1869 "fortran.y"
{
			    if(f77_accept_type)
				nonstandard(yyvsp[-2].line_num,yyvsp[-2].col_num);
			;
    break;}
case 311:
#line 1874 "fortran.y"
{complex_const_allowed = TRUE;;
    break;}
case 312:
#line 1875 "fortran.y"
{complex_const_allowed = FALSE;;
    break;}
case 313:
#line 1876 "fortran.y"
{
			    if(f77_accept_type)
				nonstandard(yyvsp[-6].line_num,yyvsp[-6].col_num);
			;
    break;}
case 314:
#line 1884 "fortran.y"
{
			    ++control_item_count;
			;
    break;}
case 315:
#line 1888 "fortran.y"
{
			    ++control_item_count;
			    if(! io_warning_given) {
			      if( io_internal_file ) {
				if( (curr_stmt_class == tok_WRITE ||
				     curr_stmt_class == tok_READ) &&
				    io_list_directed ) {
				  if(f77_internal_list_io) {
				    nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
	    msg_tail(": internal file cannot be used with list-directed I/O");
				  }
				  io_warning_given = TRUE;
				}
			      }
			    }
			;
    break;}
case 316:
#line 1910 "fortran.y"
{
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			;
    break;}
case 317:
#line 1914 "fortran.y"
{
			    if( yyvsp[0].class == '*' ) {
			      if(control_item_count == 1) /* format id */
				{
				  io_list_directed = TRUE;
				}
			    }
			    else if( is_true(ID_EXPR,yyvsp[0].TOK_flags)){

					/* Handle special cases */
				if(control_item_count == 0 &&
				 datatype_of(yyvsp[0].TOK_type) == type_STRING) {
					/* unit id=char variable is
					   an internal file.  I/O goes in
					   and out of the variable. */
				  io_internal_file = TRUE;
				  if(curr_stmt_class == tok_WRITE) {
				    use_lvalue(&(yyvsp[0]));
				  }
				}

					/* format id=namelist means
					   I/O with variables of namelist. */
				else if( control_item_count == 1 &&
				 datatype_of(yyvsp[0].TOK_type) == type_NAMELIST) {
				    ref_namelist(&(yyvsp[0]),curr_stmt_class);
				}

					/* Handle use of variable */
				use_variable(&(yyvsp[0]));
			    }
			;
    break;}
case 318:
#line 1954 "fortran.y"
{
			    if( yyvsp[0].class != '*'
			       && is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    ++control_item_count;
			;
    break;}
case 319:
#line 1962 "fortran.y"
{
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			    ++control_item_count;
			;
    break;}
case 320:
#line 1967 "fortran.y"
{
			    ++control_item_count;
			;
    break;}
case 321:
#line 1973 "fortran.y"
{
			    use_io_keyword(&(yyvsp[-2]),&(yyvsp[0]),curr_stmt_class);
			;
    break;}
case 322:
#line 1977 "fortran.y"
{
			    use_special_open_keywd(&(yyvsp[0]));
			;
    break;}
case 325:
#line 1988 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				if( curr_stmt_class == tok_READ ||
				    curr_stmt_class == tok_ACCEPT )
				    use_lvalue(&(yyvsp[0]));
				else
				    use_variable(&(yyvsp[0]));
			    }
			;
    break;}
case 327:
#line 2002 "fortran.y"
{
			  if( ! is_true(LVALUE_EXPR,yyvsp[-3].TOK_flags) ) {
			    syntax_error(yyvsp[-3].line_num,yyvsp[-3].col_num,
					 "index is not assignable");
			  }
			  else {
			     use_implied_do_index(&(yyvsp[-3]));
			  }
			;
    break;}
case 328:
#line 2014 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 330:
#line 2019 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 332:
#line 2024 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 334:
#line 2030 "fortran.y"
{
			    if( yyvsp[-1].class != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			;
    break;}
case 336:
#line 2038 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 337:
#line 2043 "fortran.y"
{
			    if( yyvsp[-1].class != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			;
    break;}
case 339:
#line 2051 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 340:
#line 2052 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 341:
#line 2057 "fortran.y"
{
			    if( yyvsp[-1].class != '*'
			       && is_true(ID_EXPR,yyvsp[-1].TOK_flags)){
				use_variable(&(yyvsp[-1]));
			    }
			;
    break;}
case 343:
#line 2065 "fortran.y"
{init_io_ctrl_list();;
    break;}
case 346:
#line 2079 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 use_variable(&(yyvsp[0]));
			    }
			;
    break;}
case 348:
#line 2088 "fortran.y"
{inside_format=TRUE;;
    break;}
case 349:
#line 2089 "fortran.y"
{
			  inside_format=FALSE;
			;
    break;}
case 368:
#line 2125 "fortran.y"
{
			  if(f77_format_dollarsigns)
			     nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
			;
    break;}
case 373:
#line 2140 "fortran.y"
{inside_format=FALSE;;
    break;}
case 374:
#line 2141 "fortran.y"
{inside_format=TRUE;;
    break;}
case 375:
#line 2142 "fortran.y"
{
			  if(f77_variable_format)
			     nonstandard(yyvsp[-4].line_num,yyvsp[-4].col_num);
			;
    break;}
case 376:
#line 2151 "fortran.y"
{
			  check_stmt_sequence(&(yyvsp[-3]),SEQ_STMT_FUN);

				def_stmt_function(&(yyvsp[-3]),&(yyvsp[-1]));
					/* make token info */
				primary_id_expr(&(yyvsp[-3]),&(yyval));
#ifdef DEBUG_PARSER
				if(debug_parser)
				  print_exprlist("stmt function",&(yyvsp[-1]));
#endif
			;
    break;}
case 377:
#line 2165 "fortran.y"
{
			    yyval.next_token = (Token*)NULL;
			;
    break;}
case 379:
#line 2172 "fortran.y"
{
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 380:
#line 2177 "fortran.y"
{
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 382:
#line 2187 "fortran.y"
{
			     call_subr(&(yyvsp[0]),(Token*)NULL);
			     complex_const_allowed = FALSE;
			;
    break;}
case 384:
#line 2193 "fortran.y"
{
			     call_subr(&(yyvsp[-2]),(Token*)NULL);
			     complex_const_allowed = FALSE;
			;
    break;}
case 386:
#line 2199 "fortran.y"
{
			     call_subr(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
			     if(debug_parser)
				print_exprlist("call stmt",&(yyvsp[-1]));
#endif
			     complex_const_allowed = FALSE;
			;
    break;}
case 388:
#line 2210 "fortran.y"
{
			     complex_const_allowed = TRUE;
			     yyval = yyvsp[0];
			;
    break;}
case 389:
#line 2216 "fortran.y"
{
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			    yyval.left_token = (Token *)NULL;
			;
    break;}
case 390:
#line 2221 "fortran.y"
{
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 391:
#line 2227 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 use_actual_arg(&(yyvsp[0]));
				 use_variable(&(yyvsp[0]));
			    }
			;
    break;}
case 392:
#line 2234 "fortran.y"
{
			  yyval = yyvsp[0];
			  yyval.left_token = (Token *)NULL;
			;
    break;}
case 393:
#line 2242 "fortran.y"
{
			     do_RETURN(current_module_hash,&(yyvsp[-1]));
			;
    break;}
case 394:
#line 2246 "fortran.y"
{
			     do_RETURN(current_module_hash,&(yyvsp[-2]));
			;
    break;}
case 395:
#line 2253 "fortran.y"
{
				   /* restore context */
				if(!is_true(COMPLEX_FLAG,yyvsp[-3].TOK_flags))
				  complex_const_allowed=FALSE;
				if(is_true(IN_ASSIGN,yyvsp[-3].TOK_flags))
				  in_assignment_stmt = TRUE;

				  /* Change empty arg list to no arg list */
				if(yyvsp[-1].next_token == NULL)
				  call_func(&(yyvsp[-3]),(Token *)NULL);
				else
				  call_func(&(yyvsp[-3]),&(yyvsp[-1]));
							/* make token info */
				func_ref_expr(&(yyvsp[-3]),&(yyvsp[-1]),&(yyval));
				/* Substitute empty token for null arglist */
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),
						   (yyvsp[-1].next_token == NULL?
						    empty_token(&(yyvsp[-1])) :
						    yyvsp[-1].next_token) );
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("function",&(yyvsp[-1]));
#endif
			;
    break;}
case 396:
#line 2281 "fortran.y"
{
			  if(complex_const_allowed)/* save context */
			    make_true(COMPLEX_FLAG,yyval.TOK_flags);
			  complex_const_allowed=TRUE;
			  if(in_assignment_stmt)
			    make_true(IN_ASSIGN,yyval.TOK_flags);
			  in_assignment_stmt = FALSE;
			;
    break;}
case 397:
#line 2291 "fortran.y"
{
				yyval.class = 0;
				yyval.next_token = (Token *)NULL;
				yyval.left_token = (Token *)NULL;
			;
    break;}
case 399:
#line 2300 "fortran.y"
{
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			    yyval.left_token = (Token *)NULL;
			;
    break;}
case 400:
#line 2305 "fortran.y"
{
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 401:
#line 2313 "fortran.y"
{
			  int t=datatype_of(yyvsp[0].TOK_type);
			  if( t != type_ERROR){
			    if( ! is_const_type(t) ) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
		      "arithmetic, char, or logical expression expected");
			    }
			    else {
			      if( !is_true(PARAMETER_EXPR,yyvsp[0].TOK_flags) ) {
				syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					   "constant expression expected");
			      }
			    /* Here we allow, with some warnings, expr
			       containing intrins func or **REAL in
			       PARAMETER defn. */
			      else if( !is_true(CONST_EXPR,yyvsp[0].TOK_flags) ) {
				if(f77_param_intrinsic) {
				  nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
				  msg_tail(
			 "intrinsic function or **REAL in PARAMETER defn");
				}
			      }
			    }
			  }
			;
    break;}
case 402:
#line 2342 "fortran.y"
{
				/* Fix it up in case it is used in expr list */
			  yyval.next_token = (Token *) NULL;
#ifdef DEBUG_PARSER
			    if(debug_parser) {
				(void)fprintf(list_fd,
					"\nexpr: class=0x%x subclass=0x%x",
					yyvsp[0].class,
					yyvsp[0].subclass);
			    }
#endif
			;
    break;}
case 404:
#line 2359 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 405:
#line 2364 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 407:
#line 2373 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 409:
#line 2382 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 411:
#line 2391 "fortran.y"
{
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			;
    break;}
case 413:
#line 2399 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 415:
#line 2409 "fortran.y"
{
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			;
    break;}
case 416:
#line 2413 "fortran.y"
{
			    do_unexpr(&(yyvsp[-1]),&(yyvsp[0]),&(yyval));
			;
    break;}
case 417:
#line 2417 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 418:
#line 2422 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 420:
#line 2431 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			    if(div_check &&
			       !is_true(CONST_EXPR,yyvsp[0].TOK_flags)){
				warning(yyvsp[-1].line_num,yyvsp[-1].col_num,
					"Possible division by zero");
			    }
			;
    break;}
case 421:
#line 2441 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 423:
#line 2450 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 425:
#line 2459 "fortran.y"
{
			    do_binexpr(&(yyvsp[-2]),&(yyvsp[-1]),&(yyvsp[0])
					 ,&(yyval));
			;
    break;}
case 430:
#line 2474 "fortran.y"
{
			    yyval.TOK_flags = 0;
			    yyval.left_token = (Token *)NULL;
			    make_true(CONST_EXPR,yyval.TOK_flags);
			    make_true(PARAMETER_EXPR,yyval.TOK_flags);
			    make_true(LIT_CONST,yyval.TOK_flags);
			    make_true(EVALUATED_EXPR,yyval.TOK_flags);
			;
    break;}
case 431:
#line 2483 "fortran.y"
{
			    yyval = yyvsp[-1];
				/* (identifier) becomes a non-identifier */
			    if(is_true(LVALUE_EXPR,yyvsp[-1].TOK_flags)) {
				if(pretty_parens) {
				  ugly_code(yyvsp[-1].line_num,yyvsp[-1].col_num,
					  "Extraneous parentheses");
				}
				use_variable(&(yyvsp[-1]));
				make_false(LVALUE_EXPR,yyval.TOK_flags);
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_false(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				make_false(ID_EXPR,yyval.TOK_flags);
			    }
				/* (expr) becomes tree node with root = '(' */
			    yyval.left_token = add_tree_node(&(yyvsp[-2]),&(yyvsp[-1]),
							  (Token*)NULL);
			;
    break;}
case 433:
#line 2508 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_STRING);
			    /* (size is set in get_string) */
			;
    break;}
case 434:
#line 2513 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_HOLLERITH);
			    /* (size is set in get_hollerith) */
			    if(port_hollerith) {
				warning(yyvsp[0].line_num,yyvsp[0].col_num,
				"hollerith constant may not be portable");
			    }
			;
    break;}
case 435:
#line 2522 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_LOGICAL);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 436:
#line 2529 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_INTEGER);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 437:
#line 2534 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_REAL);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 438:
#line 2539 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_DP);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 439:
#line 2544 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_QUAD);
			    yyval.size = size_QUAD;
                            if(f77_quad_constants) {
                              nonstandard(yyvsp[0].line_num,yyvsp[0].col_num);
                              msg_tail(": quad precision constant");
                            }
			;
    break;}
case 440:
#line 2553 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_COMPLEX);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 441:
#line 2558 "fortran.y"
{
			    yyval.TOK_type = type_byte(class_VAR,type_DCOMPLEX);
			    yyval.size = size_DEFAULT;
			;
    break;}
case 442:
#line 2566 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER) {
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"expression must be integer type");
			    }
			;
    break;}
case 443:
#line 2580 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    {
				int t=datatype_of(yyvsp[0].TOK_type);
				    if(t != type_INTEGER && t != type_REAL
					&& t != type_DP ) {
					syntax_error(
					  yyvsp[0].line_num,yyvsp[0].col_num,
		"expression must be integer, real, or double precision type");
			    	    }
			    }
			;
    break;}
case 444:
#line 2600 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }
			    if( ! is_true(CONST_EXPR,yyvsp[0].TOK_flags) ) {
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"constant expression expected");
			    }
			    else {
			      if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER){
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"integer expression expected");
			      }
			      else {
				yyval.value.integer = int_expr_value(&(yyvsp[0]));
			      }
			    }
			;
    break;}
case 445:
#line 2624 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				use_variable(&(yyvsp[0]));
			    }

			    if( datatype_of(yyvsp[0].TOK_type) != type_INTEGER ){
				syntax_error(
					yyvsp[0].line_num,yyvsp[0].col_num,
					"integer dimension expected");
				yyval.value.integer = 0;
			    }
			    else {
			      if( is_true(EVALUATED_EXPR,yyvsp[0].TOK_flags) )
				yyval.value.integer =
				  int_expr_value(&(yyvsp[0]));
			      else		/* must be dummy */
				yyval.value.integer = 0;
			    }
			;
    break;}
case 446:
#line 2650 "fortran.y"
{
				ref_array(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("array lvalue",&(yyvsp[-1]));
#endif
					/* array now becomes scalar */
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),yyvsp[-1].next_token);
				yyval.next_token = (Token *) NULL;
			;
    break;}
case 447:
#line 2666 "fortran.y"
{
				ref_array(&(yyvsp[-3]),&(yyvsp[-1]));
#ifdef DEBUG_PARSER
				if(debug_parser)
				    print_exprlist("array",&(yyvsp[-1]));
#endif
					/* array now becomes scalar */
				make_false(ARRAY_ID_EXPR,yyval.TOK_flags);
				make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
				yyval.left_token = add_tree_node(
						   &(yyvsp[-2]),&(yyvsp[-3]),yyvsp[-1].next_token);
				yyval.next_token = (Token *) NULL;
			;
    break;}
case 448:
#line 2682 "fortran.y"
{
			    yyval.next_token = append_token((Token*)NULL,&(yyvsp[0]));
			;
    break;}
case 449:
#line 2686 "fortran.y"
{
			    yyval.next_token = append_token(yyvsp[-2].next_token,&(yyvsp[0]));
			;
    break;}
case 450:
#line 2692 "fortran.y"
{
			    if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
				 use_variable(&(yyvsp[0]));
			    }
				/* check subscript exprs for integer type */
			    if(datatype_of(yyvsp[0].TOK_type) != type_INTEGER)
			      if(trunc_real_subscript)
			         warning(yyvsp[0].line_num,yyvsp[0].col_num,
					 "subscript is not integer");
			;
    break;}
case 451:
#line 2706 "fortran.y"
{
				   /* restore status of complex flag */
			    if(!is_true(COMPLEX_FLAG,yyvsp[-1].TOK_flags))
				  complex_const_allowed=FALSE;
				/* set flag to keep more than just id for
				   arg list text */
			    if(is_true(ID_EXPR,yyvsp[-1].TOK_flags))
			       make_true(ARRAY_ELEMENT_EXPR,yyval.TOK_flags);
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			;
    break;}
case 452:
#line 2721 "fortran.y"
{
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			;
    break;}
case 453:
#line 2729 "fortran.y"
{
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.left_token = add_tree_node(
					       &save_token,&(yyvsp[-1]),&(yyvsp[0]));
			    yyval.next_token = (Token *) NULL;
			;
    break;}
case 454:
#line 2738 "fortran.y"
{
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			;
    break;}
case 455:
#line 2742 "fortran.y"
{
			    yyval.size=substring_size(&(yyvsp[-1]),&(yyvsp[0]));
			;
    break;}
case 456:
#line 2751 "fortran.y"
{
			    yyval.TOK_start=1;
			    yyval.TOK_end=0; /* 0 means LEN */

			    save_token = yyvsp[-2]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-1]),
				     empty_token(&(yyvsp[-2])),empty_token(&(yyvsp[0])));
				/* Nullify next_token so it looks like
				   a tokenlist */
			    yyval.next_token = (Token *)NULL;
			;
    break;}
case 457:
#line 2765 "fortran.y"
{
			    yyval.TOK_start=yyvsp[-2].value.integer;
			    yyval.TOK_end=0; /* 0 means LEN */

			    save_token = yyvsp[-3]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-1]),&(yyvsp[-2]),empty_token(&(yyvsp[0])));
			    yyval.next_token = (Token *)NULL;
			;
    break;}
case 458:
#line 2775 "fortran.y"
{
			    yyval.TOK_start=1;
			    yyval.TOK_end=yyvsp[-1].value.integer;

			    save_token = yyvsp[-3]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-2]),empty_token(&(yyvsp[-3])),&(yyvsp[-1]));
			    yyval.next_token = (Token *)NULL;
			;
    break;}
case 459:
#line 2785 "fortran.y"
{
			    yyval.TOK_start=yyvsp[-3].value.integer;
			    yyval.TOK_end=yyvsp[-1].value.integer;

			    save_token = yyvsp[-4]; /* Save the paren for tree node */
			    yyval.left_token =
			      add_tree_node(&(yyvsp[-2]),&(yyvsp[-3]),&(yyvsp[-1]));
			    yyval.next_token = (Token *)NULL;
			;
    break;}
case 460:
#line 2797 "fortran.y"
{
			  if(is_true(ID_EXPR,yyvsp[0].TOK_flags)){
			    use_variable(&(yyvsp[0]));
			  }
				/* check validity and replace nonconst
				   value by size_UNKNOWN. */
			  if(is_true(CONST_EXPR,yyvsp[0].TOK_flags)) {
			    if( (yyval.value.integer=int_expr_value(&(yyvsp[0]))) < 1) {
			      syntax_error(yyvsp[0].line_num,yyvsp[0].col_num,
					   "invalid substring index");
			    }
			  }
			  else  /* (no longer need ID hash index) */
			    yyval.value.integer=size_UNKNOWN;
			;
    break;}
case 463:
#line 2822 "fortran.y"
{
			    ref_variable(&(yyvsp[0]));
			    primary_id_expr(&(yyvsp[0]),&(yyval));
			;
    break;}
case 464:
#line 2829 "fortran.y"
{
			    ref_variable(&(yyvsp[0]));
			    primary_id_expr(&(yyvsp[0]),&(yyval));
			;
    break;}
case 473:
#line 2855 "fortran.y"
{
			  if(yyvsp[0].value.integer == 0) {
			    warning(yyvsp[0].line_num,yyvsp[0].col_num,
				    "nonzero integer expected");
			    msg_tail(": substituting 1");
			    yyval.value.integer = 1;
			  }
			  yyval.left_token = (Token *)NULL;
			;
    break;}
case 474:
#line 2871 "fortran.y"
{
			    integer_context=TRUE;
			;
    break;}
case 475:
#line 2878 "fortran.y"
{
				integer_context=FALSE;
				yyval.TOK_type = type_byte(class_LABEL,type_LABEL);
				yyval.size = size_DEFAULT;
				yyval.TOK_flags = 0;
			;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 465 "/usr/lib/bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 2888 "fortran.y"


void
init_parser(VOID)			/* Initialize various flags & counters */
{
	initial_flag = TRUE;	/* set flag for keyword test */
	implicit_flag=FALSE;	/* clear flags for IMPLICIT stmt */
	implicit_letter_flag = FALSE;
	implicit_type_given = FALSE;
	implicit_none = FALSE;
	global_save = FALSE;
	prev_token_class = EOS;
	complex_const_allowed = FALSE;
	stmt_sequence_no = 0;
	true_prev_stmt_line_num = 0;
}

				/* Handle unary expressions: link
				   into a tree and propagate type.
				 */
PRIVATE void
#if HAVE_STDC
do_unexpr(Token *op, Token *expr, Token *result)
#else /* K&R style */
do_unexpr(op,expr,result)
     Token *op,*expr,*result;
#endif /* HAVE_STDC */
{
  unexpr_type(op,expr,result);

  result->left_token = add_tree_node(op, expr, (Token*)NULL);
}
				/* Handle binary expressions: link
				   into a tree and propagate type.
				 */
PRIVATE void
#if HAVE_STDC
do_binexpr(Token *l_expr, Token *op, Token *r_expr, Token *result)
#else /* K&R style */
do_binexpr(l_expr,op,r_expr,result)
     Token *l_expr,*op,*r_expr,*result;
#endif /* HAVE_STDC */
{
  binexpr_type(l_expr,op,r_expr,result); /* Propagate the type */

  result->left_token = add_tree_node(op, l_expr, r_expr);
}


			/* Changes a token to empty and replaces
			   src_text by null string, value by 0.  Other
			   info (line, col, etc.)  unchanged. */

PRIVATE Token *
#if HAVE_STDC
empty_token(Token *t)
#else /* K&R style */
empty_token(t)
     Token *t;
#endif /* HAVE_STDC */
{
#ifdef DEBUG_EMPTY_TOKEN
  static char *nullstring="(empty)"; /* for debugging.  */
#else
  static char *nullstring=""; /* for operation.  */
#endif
  t->class = tok_empty;
  t->subclass = 0;
  t->value.integer = 0;
  t->left_token = (Token *) NULL;
  t->src_text = nullstring;

  return t;
}

		/* Propagate non-integer type if any of DO loop
		   bounds are non-integer. */
PRIVATE int
#if HAVE_STDC
do_bounds_type(Token *t1, Token *t2, Token *t3)
#else /* K&R style */
do_bounds_type(t1,t2,t3)
     Token *t1, *t2, *t3;
#endif /* HAVE_STDC */
{
  int result_type;
       if(datatype_of(t1->TOK_type) != type_INTEGER)result_type = t1->TOK_type;
  else if(datatype_of(t2->TOK_type) != type_INTEGER)result_type = t2->TOK_type;
  else if(datatype_of(t3->TOK_type) != type_INTEGER)result_type = t3->TOK_type;
  else result_type = t1->TOK_type;
  return result_type;
}


/* Debugging routine: prints the expression list of various productions */
#ifdef DEBUG_PARSER
PRIVATE void
print_exprlist(s,t)
	char *s;
	Token *t;
{

	(void)fprintf(list_fd,"\n%s arglist: ",s);

	if(t == NULL)
		(void)fprintf(list_fd,"(empty)");
	else {
  	    while( (t=t->next_token) != NULL) {
		  fprintf(list_fd,"%s ",type_name[datatype_of(t->TOK_type)]);
		  if( is_true(ID_EXPR,t->TOK_flags) )
			(void)fprintf(list_fd,"(%s) ",token_name(*t));
	    }
	}
}

PRIVATE void
print_comlist(s,t)
	char *s;
	Token *t;
{

	(void)fprintf(list_fd,"\n%s varlist: ",s);

	if(t == NULL)
		(void)fprintf(list_fd,"(empty)");
	else {
  	    while( (t=t->next_token) != NULL) {
		  fprintf(list_fd,"%s ",type_name[datatype_of(t->TOK_type)]);
		  if( is_true(ID_EXPR,t->TOK_flags) )
			(void)fprintf(list_fd,"(%s) ",token_name(*t));
		}
	  }
}
#endif

/* After having parsed prog_stmt, function_stmt, subroutine_stmt,
   block_data_stmt, the stmt_sequence_no is set to the value SEQ_HEADER.
*/

void
#if HAVE_STDC
check_seq_header(Token *t)
#else /* K&R style */
check_seq_header(t)
     Token *t;
#endif /* HAVE_STDC */
{
	if(stmt_sequence_no >= SEQ_HEADER) {
	   syntax_error( (t == (Token *) NULL? line_num: t->line_num),
			NO_COL_NUM,
			"missing END statement inserted");
	   msg_tail( (t == (Token *) NULL? "at end of file":
		      "prior to statement") );

	   END_processing(t);
	}
	stmt_sequence_no = SEQ_HEADER;
}

PRIVATE void
#if HAVE_STDC
check_stmt_sequence(Token *t, int seq_num)
#else /* K&R style */
check_stmt_sequence(t,seq_num)
     Token *t;
     int seq_num;
#endif /* HAVE_STDC */
{
    if(stmt_sequence_no > seq_num) {
	 syntax_error(t->line_num, NO_COL_NUM,
		      "Statement out of order.");
    }
    else {
	stmt_sequence_no = seq_num;
    }
}

PRIVATE void
init_io_ctrl_list(VOID)
{
  control_item_count = 0;
  io_internal_file = FALSE;
  io_list_directed = FALSE;
  io_warning_given = FALSE;
}


	/* After having parsed end_stmt, common block lists and
	   subprogram argument lists are copied over into global symbol
	   table, the local symbol table is printed out and then cleared,
	   and stmt_sequence_no is set to zero for start of next module.
	*/

PRIVATE void
#if HAVE_STDC
END_processing(Token *t)
#else /* K&R style */
END_processing(t)
	Token *t;
#endif /* HAVE_STDC */
{
  ++tot_module_count;
  if(current_module_hash != -1) {
        if(exec_stmt_count == 0 &&
	   current_module_type != type_BLOCK_DATA) {
	  warning(t == (Token *)NULL? line_num: t->line_num, NO_COL_NUM,
		  "Module contains no executable statements");
	}
	if(do_list && t != (Token *)NULL)
	    (void)flush_line_out(t->line_num);
	check_loose_ends(current_module_hash);
	process_lists(current_module_hash);
	debug_symtabs();
	print_loc_symbols(current_module_hash);
	init_symtab();
  }
  exec_stmt_count = 0;
  stmt_sequence_no = 0;
  current_module_hash = -1;
  implicit_type_given = FALSE;
  implicit_none = FALSE;
  true_prev_stmt_line_num = 0;
  integer_context = FALSE;
  global_save = FALSE;
}

		/* Routine to create a node for an expr tree.  Returns
		   a pointer to the newly created node.
		 */
PRIVATE Token *
#if HAVE_STDC
add_tree_node(Token *node, Token *left, Token *right)
#else /* K&R style */
add_tree_node(node,left,right)
     Token *node,*left,*right;
#endif /* HAVE_STDC */
{
  Token *new_node, *new_left, *new_right;

  new_node=new_token();

  *new_node = *node;		/* Make a permanent copy of root */

		/* Add the children.  If child's left_token pointer is
		   null, then that expression is a primary.  Otherwise
		   it is the root node of a subtree.
		 */
  if(left->left_token == (Token *)NULL) {
    new_left=new_token();
    *new_left = *left;			/* Copy primary to permanent space */
  }
  else {
    new_left = left->left_token;	/* No copying needed in this case */
  }

  if(right == (Token *)NULL) {
    new_right = (Token *)NULL;		/* No right child */
  }
  else if(right->left_token == (Token *)NULL
	  || node->class == '(') { /* Paren means right child is expr list */
    new_right=new_token();
    *new_right = *right;		/* Copy primary to permanent space */
  }
  else {
    new_right = right->left_token;	/* No copying needed in this case */
  }

  new_node->left_token = new_left;	/* Link children onto the new root */
  new_node->next_token = new_right;
  return new_node;
}

		/* Routine to add token t to the front of a token list. */
PRIVATE Token *
#if HAVE_STDC
append_token(Token *tlist, Token *t)
#else /* K&R style */
append_token(tlist,t)
     Token *tlist, *t;
#endif /* HAVE_STDC */
{
	Token *tcopy;

	tcopy=new_token();

	*tcopy = *t;		/* make permanent copy of token */
	tcopy->next_token = tlist; /* link it onto front of list */
	return tcopy;		/* return it as new tlist */
}
