efence	stream	tcp	nowait	root	/usr/sbin/tcpd /usr/sbin/efence
