#include <stdio.h>

hello () {
    printf ("hello world!\n");
}
