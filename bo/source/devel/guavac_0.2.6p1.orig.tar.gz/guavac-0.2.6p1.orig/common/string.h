// Copyright (c) 1995  David Engberg  All rights reserved
// $Id: string.h,v 1.1 1995/12/15 10:56:26 geppetto Exp $

// this little business avoids an annoying template instantiation clash
#ifndef __SINST__
#define __SINST__
#endif
#include <string>
