/* Configuration for GCC for Sun SPARC running NetBSD as host.  */

#include <sparc/xm-sparc.h>
#include <xm-netbsd.h>
