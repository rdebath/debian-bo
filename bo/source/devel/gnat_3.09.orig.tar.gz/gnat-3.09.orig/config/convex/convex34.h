/* tm.h file for a Convex C34xx.  */

#define TARGET_DEFAULT 010

#include "convex/convex.h"
