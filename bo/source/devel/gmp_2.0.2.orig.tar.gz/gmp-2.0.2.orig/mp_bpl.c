#include "gmp.h"
#include "gmp-impl.h"

const int mp_bits_per_limb = BITS_PER_MP_LIMB;
