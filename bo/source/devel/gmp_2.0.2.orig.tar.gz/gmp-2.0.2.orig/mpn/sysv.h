#define C_SYMBOL_NAME(name) name
