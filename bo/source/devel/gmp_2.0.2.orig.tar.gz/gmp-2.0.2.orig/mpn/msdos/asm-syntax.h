#define ELF_SYNTAX
#include "x86/syntax.h"
