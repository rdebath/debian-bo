/* Define if you have MIT Kerberos version 4 available.  */
#undef HAVE_KERBEROS

/* Define if you want release-based fields to be included.  */
#undef GNATS_RELEASE_BASED
