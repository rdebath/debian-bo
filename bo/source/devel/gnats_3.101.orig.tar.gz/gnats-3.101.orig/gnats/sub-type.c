/* Ask the server what type of submitter someone is.
   Copyright (C) 1994, 1995 Free Software Foundation, Inc.
   Contributed by Brendan Kehoe (brendan@cygnus.com).

This file is part of GNU GNATS.

GNU GNATS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU GNATS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU GNATS; see the file COPYING.  If not, write to the Free
Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111, USA.  */

#include "config.h"
#include "gnats.h"
#include "query.h"

/* The name of the GNATS server.  */
char *name;

/* The name this program was run with.  */
char *program_name;

/* If 1, send information as we make the query.  */
int debug = 0;

struct option long_options[] =
{
  {"debug", 0, NULL, 'D'},
  {"version", 0, NULL, 'V'},
};

void usage (), version ();

int
main (argc, argv)
     int argc;
     char **argv;
{
  int optc;

  program_name = basename (argv[0]);
  if (argc == 1)
    usage (1);

  name = gnats_server;

  while ((optc = getopt_long (argc, argv, "p:c:s:VD",
			      long_options, (int *) 0)) != EOF)
    {
      switch (optc)
	{
	case 'V':
	  version ();
	  exit (0);
	  break;

	case 'D':
	  debug = 1;
	  break;

	default:
	  usage ();
	}
    }

  if (! argv[optind])
    usage ();

  client_init ();
  if (debug)
    fprintf (stderr, "%s: writing `TYPE %s'\n", program_name,
	     argv[optind]);
  fprintf (serv_write, "TYPE %s\r\n", argv[optind]);
  get_reply ();

  client_exit ();

  exit (0);
}

void
usage ()
{
  fprintf (stderr, "Usage: %s [-V] submitter\n", program_name);
  exit (1);
}

void
version ()
{
  printf ("sub-type %s\n", version_string);
}

