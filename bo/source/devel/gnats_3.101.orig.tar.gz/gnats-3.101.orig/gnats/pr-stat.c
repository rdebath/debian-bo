/* Give stats on PRs regarding their lifetime from open to closed state.
   Copyright (C) 1994, 1995 Free Software Foundation, Inc.
   Contributed by Brendan Kehoe (brendan@cygnus.com).

This file is part of GNU GNATS.

GNU GNATS is free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation; either version 2, or (at your option)
any later version.

GNU GNATS is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with GNU GNATS; see the file COPYING.  If not, write to the Free
Software Foundation, 59 Temple Place - Suite 330, Boston, MA 02111, USA.  */

/* Initial version, when complete dissect it and put functionality into
   the server, and make this a bare client using that design to extend
   the possibilities of what we're adding.  */

#include "config.h"
#include "gnats.h"
#include "query.h"

void usage ();

/* The name of the GNATS server.  */
char *name;

/* The name this program was run with.  */
char *program_name;

typedef struct _times
{
  int days;
  int hours;
} Times;

struct option long_options[] =
{
/*  {"business-time", 0, NULL, 'b'},*/
/*  {"help", 0, NULL, 'h'},*/
  {NULL, 0, NULL, 0}
};

void
start_data ()
{
  return; /* Nothing */
}

Times *
time_diff_2 (start, stop)
     time_t start, stop;
{
  Times *t = (Times *) xmalloc (sizeof (Times));
  time_t diff = stop - start;
  time_t days, hours;

  days = (diff / 3600) / 24;
  diff -= (days * 86400); /* days * 60 * 60 * 24 */
  hours = diff / 3600;

  t->days = days;
  t->hours = hours;
  return t;
}

time_t
got_closed (p)
     char *p;
{
  time_t t;
  char *final1, *final2;
  char *c;

  /* Skip ahead to the last time it was closed.  */
  final1 = p;
  do
    {
      final2 = final1;
      final1 = strstr (final2, "-closed\n");
      if (final1)
	final1 += 8;
    } while (final1);
  if (! final2)
    return (time_t)0;

  /* Grab the date, and return the time it represents.  */
  final1 = strstr (final2, "When: ");
  if (! final1)
    return (time_t)0;
  c = strchr (final1 + 6, '\n');
  if (c)
    *c = '\0';

  return get_date (final1 + 6, NULL);
}

void
do_stat (p)
     char *p;
{
  char *path;

  if (((char *) strchr (p, '/')) == NULL)
    path = get_category (p);
  else
    {
      path = (char *) xmalloc (PATH_MAX);
      sprintf (path, "%s/%s", gnats_root, p);
    }

  if (path)
    {
      if (get_pr (path, p, 0))
	{
	  time_t start = get_date (pr[ARRIVAL_DATE].value, NULL);
	  time_t stop = got_closed (pr[AUDIT_TRAIL].value);
	  Times *t;

	  /* We don't care about ones that had no closed status in its
	     audit trail.  */
	  if (!start || !stop)
	    {
	      free (path);
	      return;
	    }

	  t = time_diff_2 (start, stop);
	  /* XXX do real stuff here */
	  printf ("%d %2d\n", t->days, t->hours);
	  free (t);
	}
      free (path);
    }

}

void
do_category (c)
     char *c;
{
  Index *i;
  char *path = (char *) xmalloc (PATH_MAX);

  for (i = index_chain; i ; i = i->next)
    if (strcmp (i->category, c) == 0 && strcmp (i->state, "closed") == 0)
      {
	sprintf (path, "%s/%s", c, i->number);
	do_stat (path);
      }

  free (path);
}

int
main (argc, argv)
     int argc;
     char **argv;
{
  int optc;
  program_name = basename (argv[0]);

  name = gnats_server;

  while ((optc = getopt_long (argc, argv, "h",
			      long_options, (int *) 0)) != EOF)
    {
      switch (optc)
	{
	case 'h':
	  usage (0);
	  break;

	default:
	  usage (1);
	}
    }

  if (optind == argc || optind >= argc)
    usage (1);

  configure ();
  init_gnats ();

  index_chain = get_index ();
  if (index_chain == NULL)
    {
      fprintf (stderr, "%s: couldn't read the index\n", program_name);
      exit (1);
    }

  /* We need this in order to read in the audit trail.  */
  query_format = FORMAT_FULL;

  if (optind == argc)
    /* nothing */ ;
  else
    while (optind < argc)
      do_category (argv[optind++]);

#if 0
  /* One approach: */
  printf ("Category         # bugs         Avg Age  Max Age  Min Age\n");
  printf ("                                  dy hr    dy hr    dy hr\n\n");

  printf ("%-16s %4d           %4d %02d  %4d %02d  %4d %02d\n", c, cnt[c], avgd, avgh, maxd, maxh, mind, minh);
#endif

  exit (0);
}

void
usage (x)
  int x;
{
  fprintf (stderr, "Usage: %s category [category...]\n", program_name);
  exit (x);
}
