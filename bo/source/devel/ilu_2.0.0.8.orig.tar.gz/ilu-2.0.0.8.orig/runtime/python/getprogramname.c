char *getprogramname()
{
  return "unknown";
}
