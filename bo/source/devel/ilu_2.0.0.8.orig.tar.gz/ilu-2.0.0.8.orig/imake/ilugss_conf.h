/* ilugss_conf.h.  Generated automatically by configure.  */
/* To be processed by Autoconf */

#ifndef	_ILUGSS_CONF_H_
#define	_ILUGSS_CONF_H_

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).
   Some security mechanisms need to have this information to
   do marshalling properly. */
#define WORDS_BIGENDIAN 1

/* figure the sizes of char, short, int, and long */
#define SIZEOF_CHAR 1
#define SIZEOF_SHORT 2
#define SIZEOF_INT 4
#define SIZEOF_LONG 4

#endif	/* _ILUGSS_CONF_H_ */
