#include "icmun.h"

void fun_add ()
{
    puts ("        add");
}
