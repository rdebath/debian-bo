#include "icmun.h"

void fun_sm ()
{
    puts ("        sm");
}
