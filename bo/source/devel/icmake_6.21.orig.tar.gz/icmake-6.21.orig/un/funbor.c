#include "icmun.h"

void fun_bor ()
{
    puts ("        or");
}
