#include "icmun.h"

void fun_shl ()
{
    puts ("        shl");
}
