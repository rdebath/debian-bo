#include "icmun.h"

void fun_push_0 ()
{
    puts ("        push int 0");
}
