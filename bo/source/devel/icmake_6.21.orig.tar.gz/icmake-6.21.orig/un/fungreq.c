#include "icmun.h"

void fun_greq ()
{
    puts ("        greq");
}
