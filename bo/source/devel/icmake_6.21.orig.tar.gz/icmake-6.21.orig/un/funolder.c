#include "icmun.h"

void fun_older ()
{
    puts ("        older");
}
