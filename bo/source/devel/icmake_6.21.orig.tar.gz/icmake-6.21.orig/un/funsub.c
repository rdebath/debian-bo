#include "icmun.h"

void fun_sub ()
{
    puts ("        sub");
}
