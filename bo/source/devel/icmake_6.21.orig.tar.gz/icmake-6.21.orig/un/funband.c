#include "icmun.h"

void fun_band ()
{
    puts ("        and");
}
