#include "icmun.h"

void fun_eq ()
{
    puts ("        eq");
}
