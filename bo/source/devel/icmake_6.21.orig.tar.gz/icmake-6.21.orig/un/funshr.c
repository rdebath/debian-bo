#include "icmun.h"

void fun_shr ()
{
    puts ("        shr");
}
