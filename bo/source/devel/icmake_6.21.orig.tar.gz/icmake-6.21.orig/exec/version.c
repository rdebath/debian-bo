/*
                          V E R S I O N  . C
*/

#include "icm-exec.h"

char
    version[] = "6.11",
    release[] = "1992-1995";
