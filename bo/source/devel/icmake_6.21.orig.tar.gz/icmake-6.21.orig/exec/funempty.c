void fun_empty ()
{
}
