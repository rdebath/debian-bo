#ifndef MSDOS

#include <stdio.h>
#include "icrssdef.h"

unsigned redirect_start (unsigned x, unsigned y)
{
    return (1);
}

#endif
