/*
** old-style function starting with a C comment
*/
void oldstyle(single_before, multiple_before, end_of_line, multiple_eol)

/* single line before */
int single_before;

/*
 * multiple
 * lines before
 */
int multiple_before;

int end_of_line;	/* end of the line */

int multiple_eol;	/*
			 * multiple lines
			 * starting at
			 * the EOL
			 */
{
	/* blah, blah, blah, blah, blah! */
}
