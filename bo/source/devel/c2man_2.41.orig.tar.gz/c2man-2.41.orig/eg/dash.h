/* dash - comment with a dash. */
int dash(int x);
