int commentafter;	/* you'll need -v to get this documented */
