/*
 * grouped functions
 *
 */

/* my grouped1 does something weird */
grouped1(a,b)
int a;	/* the a parameter */
char b; /* the b parameter */
{

	/* do nothing */
	return(1);
}
/* my grouped2 does also something weird */
grouped2(a,b)
int a;	/* the a parameter */
char *b;/* the b parameter */
{

	/* do nothing */
	return(1);
}
