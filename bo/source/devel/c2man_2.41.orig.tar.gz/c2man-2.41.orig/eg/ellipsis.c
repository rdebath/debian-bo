int             pr(int,...);

void            main(void)
{
    pr(3, 'a', 'b', 'c');
}

/* ellipsis test function */
int             pr(
	int nitems,		/* number of items */
	...			/* items */
)
{
    /* blah, blah, blah, blah, blah! */
}
