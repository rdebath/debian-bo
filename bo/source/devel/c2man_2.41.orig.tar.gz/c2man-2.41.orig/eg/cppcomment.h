//
// function starting with a C++ comment
//
void cppcomment(
	// single line before
	int single_before,

	//
	// multiple
	// lines before
	//
	int multiple_before,

	int end_of_line,	// end of the line

	int multiple_eol,	//
				// multiple lines
				// starting at
				// the EOL
				//

	int single_after
	// single line after
	,
	int multiple_after
	//
	// multiple lines
	// after.
	// cant imagine anyone coding like this.
	//
);

