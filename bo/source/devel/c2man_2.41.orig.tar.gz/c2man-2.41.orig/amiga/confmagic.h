/*
 * This file was produced by running metaconfig and is intended to be included
 * after config.h and after all the other needed includes have been dealt with.
 *
 * This file may be empty, and should not be edited. Rerun metaconfig instead.
 * If you wish to get rid of this magic, remove this file and rerun metaconfig
 * without the -M option.
 *
 *  $Id: confmagic.h,v 2.0.1.1 1995/07/05 08:08:22 greyham Exp $
 */

#ifndef _confmagic_h_
#define _confmagic_h_

#ifndef HAS_INDEX
#ifndef index
#define index strchr
#endif
#endif

#ifndef HAS_INDEX
#ifndef rindex
#define rindex strrchr
#endif
#endif

extern FILE *popen(const char *cmd,const char *mode);
extern int pclose(FILE *fp);
#endif
