/* Define as the path of the `chmod' program. */
#undef CHMOD_PATH
