#define Precision 16
#define GetHost
#define MaxHdr 4196

#define UNIX 1
