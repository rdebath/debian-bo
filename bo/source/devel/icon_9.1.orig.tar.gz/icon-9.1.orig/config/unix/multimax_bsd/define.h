#define MaxHdr 12388
#define Precision 15
#define GetHost

#define MULTIMAX

#define UNIX 1
