/*
 * Icon configuration file for the DECstation 3100.
 */
#define GetHost
#define MaxHdr 16384
#define CStateSize 32  /* anything >= 26 should actually do */
#define Double

#define UNIX 1

#define KeyboardFncs
#define HaveTioc
