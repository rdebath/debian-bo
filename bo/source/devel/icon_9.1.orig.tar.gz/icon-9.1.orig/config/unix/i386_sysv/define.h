/*
 * Icon configuration file for the i386 running under System V.
 */
#define HostStr "UNIX 386"
#define index strchr
#define rindex strrchr
#define MaxHdr 4396
#define VoidType
#define SigFncCast

#define NoRanlib
#define COpts "-O"

#define UNIX 1
#define NoIconify
