/*
 * Icon configuration file for the Sun 4
 */
#define GetHost 1
#define MaxHdr  13100
#define MaxStatSize 20000
#define StackAlign 8
#define SysTime <sys/time.h>
#define Double

#define SUN
#define CComp "gcc"
#define LoadFunc

#define StandardC
#define StandardPP

#define COpts "-O -ldl"

#define UNIX 1
