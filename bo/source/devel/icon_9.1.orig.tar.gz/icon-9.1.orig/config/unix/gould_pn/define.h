#define Double
#define GetHost
#define IconAlloc
#define SysTime <sys/time.h>

#define UNIX 1
