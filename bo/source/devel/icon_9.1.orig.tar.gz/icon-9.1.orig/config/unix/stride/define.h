#define HostStr "thermo"
#define UNIX 1
#define ZeroDivide
#define SysMem
#define index strchr
#define rindex strrchr
#define MaxStatSize 20480
#define Hz 100
#define NoLargeInts
