#define HostStr "SCO XENIX V"
#define IntBits 16
#define MaxHdr  8000
#define SCO_XENIX
#define index strchr
#define rindex strrchr
#define DiffPtrs(p1,p2) ((word)(p1)-(word)(p2))

#define UNIX 1
