#define HostStr "HP 9000; HP-UX"
#define Hz 50
#define MaxHdr  2048
#define NoCoexpr
#define index strchr
#define rindex strrchr

#define UNIX 1
