#define GetHost
#define SysTime <sys/time.h>

#define UNIX 1
