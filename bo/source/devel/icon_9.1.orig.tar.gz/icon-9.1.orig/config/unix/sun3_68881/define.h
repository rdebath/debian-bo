#define GetHost 1
#define MaxHdr  20480
#define SUN
#define SysTime <sys/time.h>

#define UNIX 1
