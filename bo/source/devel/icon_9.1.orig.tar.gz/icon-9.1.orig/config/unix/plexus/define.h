
#define MaxHdr	1636
#define UtsName
#define index strchr 
#define rindex strrchr 

#define UNIX 1
