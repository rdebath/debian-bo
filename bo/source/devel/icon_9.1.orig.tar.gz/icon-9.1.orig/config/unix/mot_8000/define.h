#define HostStr "m8000"
#define NoCoexpr
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
