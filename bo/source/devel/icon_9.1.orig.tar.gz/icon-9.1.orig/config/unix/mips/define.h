#define MIPS
#define UtsName
#define MaxHdr 16384
#define CStateSize 32  /* anything >= 26 should actually do */
#define Double
#define index strchr
#define rindex strrchr
 
#define UNIX 1
