#define GetHost
#define MaxHdr 13600
#define NoCoexpr
#define SysTime <sys/time.h>

#define UNIX 1
