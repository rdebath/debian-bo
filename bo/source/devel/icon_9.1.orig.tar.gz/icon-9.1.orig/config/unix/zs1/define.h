#define HostStr "Astronautics ZS-1"
#define NoCoexpr

#define MaxHdr 132000
#define MaxStatSize 51500

#define UNIX 1
