#define MaxHdr  2000
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
#define NoRanlib
