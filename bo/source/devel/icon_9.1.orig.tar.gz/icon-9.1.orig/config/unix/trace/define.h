#define Double
#define StackAlign 8
#define SysTime <sys/time.h>
#define GetHost
#define MaxHdr 160000

#define UNIX 1
