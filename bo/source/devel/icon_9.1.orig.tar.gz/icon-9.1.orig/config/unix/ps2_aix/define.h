#define UtsName
#define index strchr
#define rindex strrchr
#define MaxHdr 5732
#define MaxStatSize 20480

#define UNIX 1

/* C options to suppress the copyright info, and strip the linked output. */
/* #define COpts "-O -qs" */
#define COpts "-qs"

