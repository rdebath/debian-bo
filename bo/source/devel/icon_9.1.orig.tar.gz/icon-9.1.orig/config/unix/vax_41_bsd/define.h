#define Big 72057594037927936.		/* larger than 2^56 lose precision */
#define LogHuge 39
#define MaxHdr  2000
#define Precision 16
#define WhoHost 1

#define UNIX 1
