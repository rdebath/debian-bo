#define HostStr "Microport V/AT"
#define NoCoexpr
#define index	strchr
#define rindex	strrchr

#define UNIX 1
