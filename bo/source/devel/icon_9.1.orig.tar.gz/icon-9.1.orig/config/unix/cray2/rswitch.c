#include "../h/config.h"
#include "../h/rt.h"

/*
 * coswitch
 */
coswitch(old_cs, new_cs, first)
int *old_cs, *new_cs;
int first;
{
   fatalerr(401, NULL);
}
