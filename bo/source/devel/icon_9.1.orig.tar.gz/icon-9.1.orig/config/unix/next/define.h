/*
 * Icon configuration file for the NeXT.
 */
#define Big 72057594037927936.		/* larger than 2^56 lose precision */
#define GetHost 1
#define LogHuge 39
#define MaxHdr  50000
#define CStateSize 25
#define Precision 16
#define Standard
#define VoidType
#define AllowConst
#define SysTime <sys/time.h>

#define COpts "-pipe -O2"

#define UNIX 1
