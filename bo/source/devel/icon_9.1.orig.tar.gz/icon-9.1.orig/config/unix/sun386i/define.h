#define GetHost 1
#deinfe MaxHdr 95000
#define SysTime <sys/time.h>

#define UNIX 1
