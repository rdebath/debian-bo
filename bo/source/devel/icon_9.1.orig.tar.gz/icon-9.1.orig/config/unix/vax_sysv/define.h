#define Big 72057594037927936.		/* larger than 2^56 lose precision */
#define HostStr "System V"
#define LogHuge 39
#define MaxHdr  2048
#define Precision 16
#define index strchr
#define rindex strrchr

#define UNIX 1
