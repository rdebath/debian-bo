#define Double
#define GetHost 1
#define MaxHdr  16384
#define SysTime <sys/time.h>

#define UNIX 1
