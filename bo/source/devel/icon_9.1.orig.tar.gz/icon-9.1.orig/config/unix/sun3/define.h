/*
 * Icon configuration file for the Sun 3
 */
#define GetHost 1
#define MaxHdr  16500
#define SysTime <sys/time.h>

#define SUN
#define COpts "-O"

#define UNIX 1

#define KeyboardFncs
#define HaveTioc
