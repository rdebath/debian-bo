#define HostStr "Pyramid DC/OSx"
#define index strchr
#define rindex strrchr
#define MaxHdr 10240
#define UNIX 1
#define Standard
#define SVR4
#define NoRanlib
#define NoCoexpr
#define Hz 100
#define SystemFnc
#define Double		/* Mark B 5/5/95 - live in hope ! */
/* #define LoadFunc */
/* #define Big 999999999 */
/* #define Precision 9 */
