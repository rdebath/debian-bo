/*
 * This is a place holder
 */

/*
 * coswitch
 */

coswitch(old_cs, new_cs, first)
int *old_cs, *new_cs;
int first;
   {
	return(0);
   }
