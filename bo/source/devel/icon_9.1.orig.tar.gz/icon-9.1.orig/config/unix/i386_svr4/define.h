#define HostStr "ESIX SVR4 486"
#define index strchr
#define rindex strrchr
#define MaxHdr 10240
#define UNIX 1
#define StandardPP
#define VoidType
#define SVR4
#define NoRanlib
