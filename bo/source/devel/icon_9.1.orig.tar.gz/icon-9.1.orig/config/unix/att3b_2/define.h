#define HostStr "ATT 3B4000 3.1.1"  /* good for 3B2/3B15/3B4000 */
#define IconAlloc
#define MaxHdr  4708
#define UpStack 1
#define index strchr
#define rindex strrchr

#define ATTM32 1

#define UNIX 1
