/*
 * Icon configuration file for the VAX-11 running under 4.3bsd.
 */
#define GetHost 1
#define LogHuge 39
#define MaxHdr  2000
#define Precision 16
#define SysTime <sys/time.h>

#define GenericBSD

#define UNIX 1
