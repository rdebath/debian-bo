#define HostStr "Xenix 386"
#define MaxHdr  6644
#define index strchr
#define rindex strrchr
#define StandardC		/* for gcc */
#define StandardPP		/* for gcc */
#define XENIX_386	1
#define MaxStatSize	20480

#define register

#define UNIX	1
