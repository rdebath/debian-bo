#define GetHost 1
#define MaxHdr  2100
#define SysTime <sys/time.h>

#define UNIX 1
