#define UNIX 1
#define CONVEX

#define MaxHdr 38000
#define Precision 15
#define StackSize 8000
#define GetHost
#define SysTime <sys/time.h>

#define __NO_INLINE_MATH

#undef StandardPP
#define StandardPP

#define KeyboardFncs
#define HaveTioc
