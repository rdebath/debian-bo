/*
 * Icon configuration file for the HP9000/s300.
 */
#define Hz 50
#define index strchr
#define rindex strrchr
#define GetHost

#define MaxHdr 7000
#define NoRanlib
#define COpts "-O -Wc,-Ns4000"

#define UNIX 1
