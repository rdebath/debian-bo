#define NoCoexpr

#define MaxHdr		4500
#define MaxStatSize	20480
#define Precision	16
#define GetHost
#define SysTime		<sys/time.h>

#define UNIX 1
