#define HostStr "Codata 3400"
#define MaxHdr  2100
#define SUN

#define UNIX 1
