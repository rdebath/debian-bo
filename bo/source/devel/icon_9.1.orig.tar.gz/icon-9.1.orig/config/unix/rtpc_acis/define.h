#define GetHost 1
#define MaxHdr	2048
#define RTACIS
#define SysTime <sys/time.h>

#define UNIX 1
