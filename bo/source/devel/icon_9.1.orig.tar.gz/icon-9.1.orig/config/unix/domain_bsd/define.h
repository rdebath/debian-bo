#define Standard
#define GetHost
#define MaxHdr 5120
#define MaxStatSize 40960
#define SysTime <sys/time.h>
#define Precision 16

#define UNIX 1
