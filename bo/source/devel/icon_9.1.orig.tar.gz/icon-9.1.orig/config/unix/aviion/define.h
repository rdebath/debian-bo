#define Standard
#define Hz 100
#define Double
#define GetHost
#define MaxStatSize 80000
#define NoCoexpr
#define MaxHdr 18100
#define IconCalling
#define CComp "gcc"
#define COpts "-O2 -msvr4 -dumpbase -w"
#define NoRanlib
#define KeyboardFncs
#define HaveTermio

#define UNIX 1
