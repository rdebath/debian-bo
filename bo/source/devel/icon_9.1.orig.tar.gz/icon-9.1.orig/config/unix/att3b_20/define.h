#define MaxHdr  3100
#define HostStr  "AT&T 3B20S UNIX 2.1.1.4 09/23 "
#define UpStack 1
#define ATT3B20P 1  /* Set if paging system - larger initial memory regions*/
#define index strchr
#define rindex strrchr

#define UNIX 1
