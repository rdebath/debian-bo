#define HostStr "IBM 3090 AIX/370"
#define NoCoexpr
#define MaxHdr 22000
#define MaxStatSize 20480
#define Double
#define NoLargeInts

/*
 * Do not remove the following definition. It controls many
 * aspects of conditional assembly that are specific to UNIX
 * systems.
 */

#define UNIX 1
