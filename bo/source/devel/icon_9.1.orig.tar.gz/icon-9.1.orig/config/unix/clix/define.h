/*
 * Icon configuration file for Intergraph Clipper-based workstation 
 */
#define NoCoexpr

/* things specific to icon on CLIX (Clipper Unix) */

#define CLIX
#define UtsName
#define Double

#define index  strchr
#define rindex strrchr
#define MaxHdr 9128
#define MaxStatSize 10240

#define UNIX 1
