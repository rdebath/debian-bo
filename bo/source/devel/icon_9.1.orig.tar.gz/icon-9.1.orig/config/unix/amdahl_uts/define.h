#define Double
#define MaxHdr  9316
#define UpStack
#define UtsName
#define index strchr
#define rindex strrchr
#define SysTime <time.h>
#define Precision 10
#define UtsS5

#define MaxAbrSize		512000	/* size of block region in bytes */
#define MaxStrSpace		256000	/* size of string space in bytes */
#define MaxStatSize		 6000	/* size of static region in bytes */
#define QualLstSize		17000	/* size of qualifier pointer region */
#define MStackSize		17000	/* size of the main stack in words */
#define StackSize		 4000	/* size of co-expression stack */

#define UNIX 1
