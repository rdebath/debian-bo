/*
 * Icon configuration file for the Sequent Symmetry.
 */
#define GetHost 1
#define MaxStatSize 32000
#define MaxHdr  9000

#define SysTime <sys/time.h>

#define UNIX 1
#define HaveTioc
