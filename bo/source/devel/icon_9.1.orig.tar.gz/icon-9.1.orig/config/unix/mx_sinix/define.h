#define MaxHdr 8700
#define Precision 16
#define SysTime <time.h>
#define UtsName
#define index strchr
#define rindex strrchr

#define UNIX 1
