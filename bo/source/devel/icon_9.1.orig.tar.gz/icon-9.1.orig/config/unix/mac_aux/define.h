#define GetHost 1
#define MaxHdr  3700
#define AUX

#define UNIX 1

#define COpts "-O -B /usr/lib/big/"

#define NoRanlib
