/* empty file of C functions for variant translator */

static char dummy = 'x';	/* dummy decl so not totally empty */
