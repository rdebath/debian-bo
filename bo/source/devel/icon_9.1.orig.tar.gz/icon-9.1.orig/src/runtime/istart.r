#if !COMPILER
/*
 *  Main program if Icon is called as a subprogram.
 */

static char x;				/* avoid empty module */
#endif					/* !COMPILER */
