/* test error message: syntax error on #include */

#include <t.h>>
