/* test error message: file on #include not found */

#include "garbage.h"
