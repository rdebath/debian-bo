/* test error message: #else with no #if */

#else
#endif
