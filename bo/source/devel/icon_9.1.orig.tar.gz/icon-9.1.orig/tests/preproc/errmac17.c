/* test error message: redefined macros must have identical parameters */

#define f(a) 1
#define f(b) 1
