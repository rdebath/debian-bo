/* test error message: macro definitions may not span multiple lines */

#define x(a
) a
