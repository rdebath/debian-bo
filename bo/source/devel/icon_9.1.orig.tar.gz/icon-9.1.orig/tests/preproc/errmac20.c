/* test error message: no identifier on #bedef */

#begdef
1
#enddef
