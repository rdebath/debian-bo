/* test error message: missing comma in macro parameter list */

#define f(a b) a b
