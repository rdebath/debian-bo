           #/*   */   undef /*




*/    x
\
#\
define\
 x\
 2\
		/*

*/
