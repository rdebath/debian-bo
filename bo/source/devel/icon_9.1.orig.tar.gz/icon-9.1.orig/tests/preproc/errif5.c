/* test error message: #endif with no #if */

xxx
#endif
