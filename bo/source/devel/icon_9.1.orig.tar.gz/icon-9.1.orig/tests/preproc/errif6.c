/* test error message: #elif with no #if */

#if 1
#endif
#elif 1
