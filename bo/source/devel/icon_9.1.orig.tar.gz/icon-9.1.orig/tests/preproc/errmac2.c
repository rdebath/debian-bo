/* test error message: too many arguments to macro */

#define m() "hi"
m(3)
