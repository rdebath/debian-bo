/* test error message: __RCRS__ must be an integer */

#undef __RCRS__
#define __RCRS__ "abc"
