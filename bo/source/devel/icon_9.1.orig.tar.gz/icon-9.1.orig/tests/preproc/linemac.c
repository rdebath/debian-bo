#define n 100
#line n
xxx
#define echo2(a,b) a b
#line echo2(1, "one.h")
yyy
#define fname "two.h"
#line n fname
zzz
