/* test error message: bad file name on line directive */

#line 1 +
