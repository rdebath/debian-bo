/* test the strinizing operator */
#define f(a) >#a<
f()
f(1)
f(  1    2    3  )
f("hi")
f(1 "bye"  2)
f('\n')
f("\x01\n")
#begdef ml(x,y)
#x,
  #  y
#enddef
ml(name, +)
