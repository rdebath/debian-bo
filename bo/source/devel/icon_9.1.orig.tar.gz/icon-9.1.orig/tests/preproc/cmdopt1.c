"this is file cmdopt1.c"
FILE
