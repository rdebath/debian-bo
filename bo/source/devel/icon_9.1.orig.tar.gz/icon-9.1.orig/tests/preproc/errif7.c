/* test error message: missing #endif with nested #ifs */

#if 1
#if 1
one
#endif
two
