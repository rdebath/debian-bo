#begdef f
one
two
three
#enddef
#include "glnml1.h"
f
#begdef f1(x)
x
#enddef
f1(3)
