/* test error message: invalid stringizing operand */

#define f(a) #b
f(1)
