/* test error message: empty #define */

#define
