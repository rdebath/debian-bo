

\
/*
*/ 	#	define x /*
*/    1
x
		#         include "delim2.h"
x
