/* this comments is part of some white space */


"b"


/* some more white space */
