/* test error message: no expression on #elif */

#if 0
one
#elif
two
#endif
