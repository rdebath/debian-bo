/*
 * This file is used in
 * various tests of command line
 * options.
 */

>testing<
__FILE__ __RCRS__

#include <stdio.h>
