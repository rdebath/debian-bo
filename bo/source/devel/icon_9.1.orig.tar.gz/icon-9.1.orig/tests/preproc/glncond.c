#if 0
1
2
#else
3
4
#endif
#include "glncond.h"
9
10
