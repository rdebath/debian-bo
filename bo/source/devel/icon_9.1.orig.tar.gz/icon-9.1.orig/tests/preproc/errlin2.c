/* test error message: bad line number in line directive */

#line 32.7 "t.c"
