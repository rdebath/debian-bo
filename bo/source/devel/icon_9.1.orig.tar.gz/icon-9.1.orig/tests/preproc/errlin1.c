/* test error message: no information in line directive */

#line
3
