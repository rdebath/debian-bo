/* this line is a * / comment /* */
"/* this is not a comment */"
123/**/456
#/*
*/define/*
*/x/*
*/3/*hi
*/
/*x*/
x
