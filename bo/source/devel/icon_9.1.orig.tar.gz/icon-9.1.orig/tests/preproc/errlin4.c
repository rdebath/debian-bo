/* test error message: extra tokens on line directive */

#line 7 "t.c" ""
