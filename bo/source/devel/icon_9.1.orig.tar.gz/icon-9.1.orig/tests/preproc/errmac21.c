/* test error message: identifier missing on #undef */

#undef
x
