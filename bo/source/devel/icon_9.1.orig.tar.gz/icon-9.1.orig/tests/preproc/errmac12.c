/* test error message: __RCRS__ may not have arguments */

#undef __RCRS__
#define __RCRS__(a) 3
