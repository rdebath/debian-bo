/* test error message: illegal redefinition of __DATE__ */

#begdef __DATE__
12/03/01
#enddef
