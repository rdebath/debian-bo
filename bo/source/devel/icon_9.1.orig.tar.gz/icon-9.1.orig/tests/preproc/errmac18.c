/* test error message: redefined macros must have identical bodies */

#define m 1
#define m 2
