/* test error message: no identifier on #ifndef */

#ifndef
one
#endif
