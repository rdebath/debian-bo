/* test error message: macro paramater must be an identifier */

#define f(3) a
