/* test error message: too few macro arguments */

#define m(a,b) a b
m(3)
