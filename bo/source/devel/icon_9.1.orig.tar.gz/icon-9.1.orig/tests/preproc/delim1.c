#define x 1
#define y 2
x,y
#include "delim1.h"
#undef y
#define y 4
x,y
#
define z
6
z
