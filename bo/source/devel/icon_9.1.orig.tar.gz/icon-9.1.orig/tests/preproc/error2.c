xxxx
#
yyyy
#error foo 'c' "string" L'C' L"wide string"	   7.3
zzzz
