/* test error message: incomplete macro call */

#define x(a) a
x(12
