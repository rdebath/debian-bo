/* test error message: invalid redefinition of __LINE__ */

#define __LINE__ 7
