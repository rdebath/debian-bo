/* test error message: no #enddef */

#begdef m
line 1
line 2
