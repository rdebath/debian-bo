#if 1
5
6
#else
7
8
#endif
>__LINE__<
