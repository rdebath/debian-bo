/* test error message: illegal redefinition of __FILE__ */

#define __FILE__ "file.c"
