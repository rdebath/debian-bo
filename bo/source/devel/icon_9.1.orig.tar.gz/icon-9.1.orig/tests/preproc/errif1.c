/* error message test: erroneous expression on #if */

#if 1+2 <
#endif
