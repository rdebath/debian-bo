/* error message test: hex escape too large in a condition */

#if '\x1ff'
#endif
