/* test error message: no identifier on #ifdef */

#ifdef
one
#elif
