/* test error message: no expression on #if */

#if
hi
#endif
