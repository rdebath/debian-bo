#define f(a) a
#begdef f1(a)
1
a
#enddef
