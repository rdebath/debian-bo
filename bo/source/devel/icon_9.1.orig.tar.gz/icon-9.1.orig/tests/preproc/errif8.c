/* test error message: missing #end after #elif */

#if 0
one
#elif 0
two
