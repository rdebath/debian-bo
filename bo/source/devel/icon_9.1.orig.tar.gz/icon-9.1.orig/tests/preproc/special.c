__LINE__, __FILE__,
__DATE__, __TIME__
#include "special.h"
__LINE__, __FILE__,
#undef __STDC__
#undef __RCRS__
__STDC__, __RCRS__,
#define __STDC__ "stdc"
#define __RCRS__ 1000
__STDC__, __RCRS__,
__LINE__, __FILE__,
