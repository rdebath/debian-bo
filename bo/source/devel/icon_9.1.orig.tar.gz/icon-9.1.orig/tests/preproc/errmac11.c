/* test error message: illegal redefinition of __TIME__ */

#define __TIME__(x) x
