#ifndef utils_h
#define utils_h

extern int print_name_only PARAMS ((Sym * self));
extern void print_name PARAMS ((Sym * self));

#endif /* utils_h */
