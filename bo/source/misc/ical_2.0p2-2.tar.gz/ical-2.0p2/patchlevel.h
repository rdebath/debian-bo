#ifndef _PATCHLEVEL_H
#define _PATCHLEVEL_H

#define ICAL_PATCH_LEVEL 1

#endif /* _PATCHLEVEL_H */
