/* Copyright (c) 1995 by Sanjay Ghemawat */
#ifndef _INTSET_H
#define _INTSET_H

#include "intcontrol.h"

#define HTABLE   IntSet
#define HTYPE    int
#define HCONTROL IntControl
#include "htable.h"

#endif /* _INTSET_H */
