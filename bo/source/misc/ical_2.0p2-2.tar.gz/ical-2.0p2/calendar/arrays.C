/* Copyright (c) 1993 by Sanjay Ghemawat */
#include "arrays.h"

implementArray(charArray,char)
implementArray(intArray,int)
implementArray(pointerArray,void*)
