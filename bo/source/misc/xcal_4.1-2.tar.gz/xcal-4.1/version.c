/*
 *	Version control file
 *	version.c	4.1	11/17/93
 *	Automatically created on Wed Nov 17 11:23:44 GMT 1993
 *	
 *	Hand edit none of this if you want freeze to continue to work
 */
#ifdef	VER_PROG
#define	PROGNAME	XCal
#endif
#ifdef	VER_VEC
char	version[] = "XCal Version 4.1, released Wed Nov 17 11:23:44 GMT 1993";
#endif
#ifdef	VER_DEF
#define	VERSION	"XCal Version 4.1, released Wed Nov 17 11:23:44 GMT 1993"
#endif

/*	SCCS files
 *
+1.26	Imakefile
+3.19	xcal_help.c
+1.3	calendar.bm
+1.26	xcal.man
+1.22	xcal_memo.c
+1.21	XCal.ad
+1.24	xcal_alarm.c
+3.37	xcal_edit.c
+1.8	README
+2.3	patchlevel.h
+3.27	xcal_strip.c
+1.3	help_press.bm
+3.13	xcal_popup.c
+3.50	xcal.c
+3.32	xcal.h
+2.38	CHANGES
+1.3	mouse.bm
+1.3	mouseaway.bm
+1.2	XCal.help
+1.3	help.bm
+1.2	README.sunos
+1.2	xcal_days.c
+1.3	xcal_buts.c
+1.2	C_from_help.sh
+1.3	strfdate.c
+1.1	C_from_ad.sh
+1.2	README.install
+1.1	README.contents
+1.1	xcal_mmap.h
 *
 */
