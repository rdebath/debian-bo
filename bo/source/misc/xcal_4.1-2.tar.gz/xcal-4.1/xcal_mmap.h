/*
 *      xcal_mmap.h     1.1     11/6/93
 *
 *      mmap control file
 *	All programs that use mmap include this file
 *	if your system does not have mmap or it gives errors,
 *	#define NO_MMAP in this file.
 */
 
/* #define NO_MMAP */
