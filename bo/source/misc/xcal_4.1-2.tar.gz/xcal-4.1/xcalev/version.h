/*
 *	Version control file
 *	version.h	1.5	11/15/93
 *	Automatically created on Mon Nov 15 23:57:53 GMT 1993
 *	
 *	Hand edit none of this if you want freeze to continue to work
 */
#ifdef	VER_PROG
#define	PROGNAME	xcalev
#endif
#ifdef	VER_VEC
char	version[] = "xcalev Version 1.5, released Mon Nov 15 23:57:53 GMT 1993";
#endif
#ifdef	VER_DEF
#define	VERSION	"xcalev Version 1.5, released Mon Nov 15 23:57:53 GMT 1993"
#endif

/*	SCCS files
 *
+1.15	xcalev.c
+1.2	xcalev.man
+1.6	Imakefile
 *
 */
