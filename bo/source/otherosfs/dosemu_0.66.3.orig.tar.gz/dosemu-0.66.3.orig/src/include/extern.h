#ifndef _EXTERN_H
#define _EXTERN_H

/* some included defines in all header files when
 * this isn't data.c 
 */

#ifndef INIT
#define INIT(x...)
#endif

#ifndef EXTERN
#define EXTERN extern
#endif

#endif

