
/***** begin user configuration section *****/

/* Define this if you want to use Xdf */
#undef USE_XDF


/* Define this if you use mtools together with Solaris' vold */
#undef USING_VOLD


/* Define for debugging messages */
#undef DEBUG


