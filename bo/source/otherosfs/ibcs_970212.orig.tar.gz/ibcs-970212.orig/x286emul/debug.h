#ifdef DEBUG
#include <stdio.h>

extern FILE *__dbf;
#endif
