#ifndef __SUPERCART__
#define __SUPERCART__

#include "atari.h"

int SuperCart_PutByte (UWORD addr, UBYTE byte);

#endif
