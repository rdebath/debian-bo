#ifndef __PROMPTS__
#define __PROMPTS__

void GetString (char *message, char *string);
void GetNumber (char *message, int *num);
void YesNo (char *message, char *yn);

#endif
