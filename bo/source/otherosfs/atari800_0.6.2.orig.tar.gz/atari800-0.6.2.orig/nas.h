#ifndef __NAS__
#define __NAS__

void NAS_Initialise (int *argc, char *argv[]);
void NAS_Exit (void);
void NAS_UpdateSound (void);

#endif
