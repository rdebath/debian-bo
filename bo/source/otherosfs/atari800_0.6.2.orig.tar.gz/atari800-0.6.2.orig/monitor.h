#ifndef __MONITOR__
#define __MONITOR__

int monitor (void);

#endif
