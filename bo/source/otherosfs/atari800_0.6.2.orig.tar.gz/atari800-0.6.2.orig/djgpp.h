
#ifndef __DJGPP__H__
#define __DJGPP__H__

#define read(a,b,c)     _read(a,b,c)

#endif

