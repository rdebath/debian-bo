#define	DL	/* recognize dl format */
#define	HECX	/* recognize hex and hcx formats */
#define	HQX	/* recognize hqx format */
#define	MU	/* recognize mu format */

#define	form_dl		0
#define	form_hecx	1
#define	form_hqx	2
#define	form_mu		3
#define	form_none	(-1)

