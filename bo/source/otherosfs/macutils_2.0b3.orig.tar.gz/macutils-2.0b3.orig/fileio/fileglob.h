extern int bytes_read, bytes_written;

