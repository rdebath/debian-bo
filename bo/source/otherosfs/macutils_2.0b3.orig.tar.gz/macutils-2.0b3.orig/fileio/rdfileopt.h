extern int rdfileopt();
extern void give_rdfileopt();
extern void set_norecurse();
extern char *get_rdfileopt();

