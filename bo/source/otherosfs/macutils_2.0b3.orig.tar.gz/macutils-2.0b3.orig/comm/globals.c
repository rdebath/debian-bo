#include "globals.h"

int xfertype = XMODEM;
int pre_beta = 0;
int time_out = 0;

