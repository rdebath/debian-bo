#include "comm.h"
#ifdef YM
#else /* YM */
int ym_to; /* Keep lint and some compilers happy */
#endif /* YM */
