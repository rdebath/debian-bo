#define	VERSION		"2.0b3 (22-OCT-1992)"
#define PATCHLEVEL	0

