#ifndef _MAC
#define _MAC
#endif

// These options should match the settings in the MW Pref panel.
//#define MAC68K_INT_SIZE               4
//#define MAC68K_DFLOAT_SIZE    10


#include <MacHeaders.h>

#define NDEBUG			// Comment out to enable debugging.
