typedef struct
{
    double comps[3];
} color_t;

#define RED_COMP 0
#define GREEN_COMP 1
#define BLUE_COMP 2
