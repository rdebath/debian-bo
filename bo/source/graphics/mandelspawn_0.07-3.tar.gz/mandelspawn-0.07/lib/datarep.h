#ifndef _datrep_h
#define _datrep_h

/* unfounded assumptions about data type sizes */
typedef unsigned char 	uint8;
typedef unsigned short 	uint16;
typedef unsigned int 	uint32;
typedef int 		sint32;

#endif /* _datrep_h */
