#ifndef _ELK_H_
#define _ELK_H_

extern int init_elk(int ac, char **av);

#endif // _ELK_H_
