#ifndef _ELK_H_
#define _ELK_H_

/* The initialisation function. */
extern int init_elk(int ac, char **av);

/* The eval function. */
extern char	*Elk_Eval(char*);

#endif /* _ELK_H_ */
