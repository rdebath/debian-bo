/*
 *  This file records official patches. To: XPaint 2.2
 *
 *  $Id: patchlevel.h,v 1.3 1996/04/19 09:18:23 torsten Exp $
 */
#define PATCHLEVEL	0
