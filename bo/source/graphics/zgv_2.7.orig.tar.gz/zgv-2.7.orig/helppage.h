/* Zgv v2.7 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1995 Russell Marks. See README for license details.
 *
 * helppage.c - prototype for showhelp() from helppage.c.
 */

extern int showhelp(int ttyfd, char *title, char help[][80]);
