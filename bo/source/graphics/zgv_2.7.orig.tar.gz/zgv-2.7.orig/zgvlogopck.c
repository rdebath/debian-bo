/* Zgv v2.7 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1995 Russell Marks. See README for license details.
 *
 * zgvlogopack.c - puts the logo file (zgvlogo.h) into an object file.
 *                 makes makes quicker. :-)
 */

#include "zgvlogo.h"
