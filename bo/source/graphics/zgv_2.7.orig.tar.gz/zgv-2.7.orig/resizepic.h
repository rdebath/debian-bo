/* Zgv v2.7 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1995 Russell Marks. See README for license details.
 *
 * resizepic.h - proto for resizepic().
 */


extern unsigned char *resizepic(unsigned char *,
		unsigned char *,unsigned char *,unsigned char *,
						int,int,int *,int *);
