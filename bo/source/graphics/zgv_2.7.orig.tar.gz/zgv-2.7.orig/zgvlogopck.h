/* Zgv v2.7 - GIF, JPEG and PBM/PGM/PPM viewer, for VGA PCs running Linux.
 * Copyright (C) 1993-1995 Russell Marks. See README for license details.
 *
 * zgvlogopack.h - header for object containing header.
 *                 are we sufficiently confused yet?
 */

extern unsigned char zgvlogo[];
extern int logow,logoh;
