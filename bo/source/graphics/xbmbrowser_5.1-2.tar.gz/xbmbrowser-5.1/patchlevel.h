/*
** This is reserved for official patches released by the project
** coordinator.  Currently this is   Anthony Thyssen  anthony@cit.gu.edu.au
** If you have a patch then please release it via me - you will be
** credited with creating it.  See README and CHANGES.
*/
#ifdef DO_XPMS
#define PATCHLEVEL "5.1 [xbm, xpm]"
#else
#define PATCHLEVEL "5.1 [xbm]"
#endif
