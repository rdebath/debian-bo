/*
  Version declaration.
*/
static char
  Version[]="@(#)ImageMagick 3.8.2 97/03/15 cristy@dupont.com";
