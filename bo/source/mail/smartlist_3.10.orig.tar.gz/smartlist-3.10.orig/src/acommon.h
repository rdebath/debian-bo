/*$Id: acommon.h,v 1.1 1994/04/05 15:34:07 berg Exp $*/

const char
 *hostname P((void));
char
 *ultoan P((unsigned long val,char*dest));
