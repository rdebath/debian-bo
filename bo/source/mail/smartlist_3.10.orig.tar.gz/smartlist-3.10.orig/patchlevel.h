#define VERSION "\
procmail v3.10 1994/10/31 written and created by Stephen R. van den Berg\n\
\t\t\t\tberg@pool.informatik.rwth-aachen.de\n\
\n\
Submit questions/answers to the procmail-related mailinglist by sending to:\n\
\tprocmail@informatik.rwth-aachen.de\n\
\n\
And of course, subscription and information requests for this list to:\n\
\tprocmail-request@informatik.rwth-aachen.de\n"

/* If the formatting or number of newlines of VERSION substantially changes,
   src/manconf.c needs to be changed as well */
