/* done.c - terminate the program */

#include "../h/mh.h"


void done (status)
register int     status;
{
    exit (status);
}
