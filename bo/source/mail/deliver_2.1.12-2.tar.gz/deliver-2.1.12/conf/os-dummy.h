/* $Id: os-dummy.h,v 1.2 1991/06/17 13:16:28 chip Exp $
 *
 * Dummy OS configuration header file.
 *
 * If your Makefile depends on this file, then you need to
 * edit your Makefile.  ("Well, don't do that, then!")
 */
