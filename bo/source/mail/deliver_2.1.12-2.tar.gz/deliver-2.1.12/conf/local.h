/* $Id: local.h,v 1.2 1991/06/04 18:14:53 chip Exp $
 *
 * Local configuration.
 * This file is included at the end of "config.h".
 */
