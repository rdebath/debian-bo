/*
 * version.h
 * Copyright (c) 1994,1995 by Christopher Heng. All rights reserved.
 * You may not remove any of the copyright notices and/or conditions for
 * use and distribution. See COPYING for additional conditions for use
 * and distribution.
 *
 * Header file to contain version number (for debugging purpose) and
 * copyright notice.
 *
 * $Id: version.h,v 2.5 1995/07/08 10:04:45 chris Released $
 */

#define VERSTR	"splitdigest 2.3 - Undigests file(s) with multiple mail digests.\n"\
	      "Copyright (c) 1994,1995 by Christopher Heng. All rights reserved.\n"
	      