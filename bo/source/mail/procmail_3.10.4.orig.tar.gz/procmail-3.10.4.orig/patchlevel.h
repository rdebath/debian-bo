#define VERSION "\
procmail v3.11pre4 1995/10/29 written and created by Stephen R. van den Berg\n\
\t\t\t\t\t\t\t<srb@cuci.nl>\n\
\n\
Submit questions/answers to the procmail-related mailinglist by sending to:\n\
\t<procmail@informatik.rwth-aachen.de>\n\
\n\
And of course, subscription and information requests for this list to:\n\
\t<procmail-request@informatik.rwth-aachen.de>\n"

/* If the formatting or number of newlines of VERSION substantially changes,
   src/manconf.c needs to be changed as well */
