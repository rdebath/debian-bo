
#define FastmailSet	0x12
#define FastmailCantFindFile	0x1
#define FastmailCouldntOpenTempFile	0x2
#define FastmailMailingTo	0x3
#define FastmailUsage	0x4
