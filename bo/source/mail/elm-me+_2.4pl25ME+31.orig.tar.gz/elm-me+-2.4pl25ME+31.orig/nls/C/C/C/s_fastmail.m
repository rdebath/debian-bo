$set 18 #Fastmail
$ #CantFindFile
1	Error: can't find file %s!\n
$ #CouldntOpenTempFile
2	Couldn't open temp file %s\n
$ #MailingTo
3	Mailing to %s%s%s%s%s [via %s]\n
$ #Usage
4	Usage: fastmail {args} [ filename | - ] address(es)\n\
   where {args} can be;\n\
\t-b bcc-list\n\t-c cc-list\n\t-d\n\
\t-C comments\n\t-f from-name\n\t-F from-addr\n\
\t-i msg-id\n\t-r reply-to\n\t-R references\n\
\t-s subject\n\n
