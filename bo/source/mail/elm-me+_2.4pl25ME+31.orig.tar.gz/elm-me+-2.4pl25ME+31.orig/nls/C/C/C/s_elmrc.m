$set 1 #Elmrc
$ #ExpandHome
1	Can't expand environment variable $HOME to find .elmrc file!\n
$ #OpenElmrc
2	Can't open your ".elmrc" file (%s) for reading!\n
$ #ExpandShell
3	Couldn't expand shell variable $%s in .elmrc!\n
$ #SavingWithoutComments
4	Warning: saving without comments! Can't get to %s.
$ #CantSaveConfig
5	Can't save configuration! Can't write to %s [%s].
$ #OptionsSavedIn
6	Options saved in file %s.
$ #OptionsFile
7	#\n# .elm/elmrc - options file for the ELM mail system\n#\n
$ #SavedAutoFor
8	# Saved automatically by ELM %s for %s\n#\n\n
$ #SavedAuto
9	# Saved automatically by ELM %s\n#\n\n
$ Do not change the strings ON and OFF in the following message, leave them in English as shown
