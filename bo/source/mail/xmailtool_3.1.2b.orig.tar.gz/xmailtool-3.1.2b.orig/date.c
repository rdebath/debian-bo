/*
 Copyright 1990 by Cray Research, Inc.
 
 Permission to use, copy, modify, and distribute this software and its
 documentation for any purpose is hereby granted without fee, provided that
 the above copyright notice appear in all copies and that both that
 copyright notice and this permission notice appear in supporting
 documentation, and that the name of Cray Research, Inc. not be used in 
 advertising or publicity pertaining to distribution of the software without
 specific, written prior permission, and that all documentation and source
 code provided in the original distribution are provided in the redistributed
 copy.  Cray Research, Inc. makes no representations about the suitability
 of this software for any purpose.  It is provided "as is" without express
 or implied warranty.
 
$Id: Copyright,v 1.1 1994/11/04 17:04:24 bobo Exp $
*/

char *ABOUT_STRING = "\n\
check_mail.c:\n\
     $Id: check_mail.c,v 1.19 1995/05/12 19:20:48 bobo Exp $\n\
\n\
xmailtool.c:\n\
     $Id: xmailtool.c,v 1.88 1995/05/12 18:51:54 bobo Exp $\n\
\n\
proc.c:\n\
     $Id: proc.c,v 1.77 1995/05/12 18:50:19 bobo Exp $\n\
\n\
util.c:\n\
     $Id: util.c,v 1.47 1994/11/03 22:45:35 bobo Exp $\n\
\n\
mail_int.c:\n\
     $Id: mail_int.c,v 1.52 1995/05/12 19:18:42 bobo Exp $\n\
\n\
setvars.c:\n\
     $Id: setvars.c,v 1.11 1995/05/12 19:16:46 bobo Exp $\n\
\n\
aliases.c:\n\
     $Id: aliases.c,v 1.10 93/09/27 14:49:20 bobo Exp $\n\
\n\
mailhandler.c:\n\
     $Id: mailhandler.c,v 1.12 1995/05/12 21:03:10 bobo Exp $\n\
\n\
expand_value.c:\n\
     $Id: expand_value.c,v 1.2 1994/09/19 21:22:32 bobo Exp $\n\
\n\
get_UV_value.c:\n\
     $Id: get_UV_value.c,v 1.2 1994/09/19 21:23:29 bobo Exp $\n\
\n\
setaliases.c:\n\
     $Id: setaliases.c,v 1.5 1995/03/15 23:29:33 bobo Exp $\n\
\n\
xmailtool.man:\n\
     $Id: xmailtool.man,v 1.36 1994/10/11 19:51:17 bobo Exp $\n\
\n\
defs.h:\n\
     $Id: defs.h,v 1.23 1995/05/12 19:16:06 bobo Exp $\n\
\n\
patchlevel.h:\n\
     $Id: patchlevel.h,v 1.14 1995/05/12 19:24:57 bobo Exp $\n\
";

