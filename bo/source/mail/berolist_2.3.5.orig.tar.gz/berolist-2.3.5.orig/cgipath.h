/* relative URL to BeroList CGI script, used in HTML-links */

#define MESSAGES_CGI "/cgi-bin/messages"
#define DISPLAY_CGI "/cgi-bin/display"
