/*                             -*- Mode: C++-C -*- 
 * 
 *  
 * 	     Copyright 1994 Christopher B. Liebman
 * 
 *  Permission to use, copy, modify, distribute, and sell this software
 *  and its documentation for any purpose is hereby granted without fee,
 *  provided that the above copyright notice appear in all copies and that
 *  both that copyright notice and this permission notice appear in
 *  supporting documentation, and that the name Christopher B. Liebman not
 *  be used in advertising or publicity pertaining to distribution of this
 *  software without specific, written prior permission.
 * 
 * THIS SOFTWARE IS PROVIDED `AS-IS'.  CHRISTOPHER B. LIEBMAN, DISCLAIMS
 * ALL WARRANTIES WITH REGARD TO THIS SOFTWARE, INCLUDING WITHOUT
 * LIMITATION ALL IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NONINFRINGEMENT.  IN NO EVENT SHALL CHRISTOPHER
 * B. LIEBMAN, BE LIABLE FOR ANY DAMAGES WHATSOEVER, INCLUDING SPECIAL,
 * INCIDENTAL OR CONSEQUENTIAL DAMAGES, INCLUDING LOSS OF USE, DATA, OR
 * PROFITS, EVEN IF ADVISED OF THE POSSIBILITY THEREOF, AND REGARDLESS OF
 * WHETHER IN AN ACTION IN CONTRACT, TORT OR NEGLIGENCE, ARISING OUT OF
 * OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
 * 
 * 
 * 
 * Author          : Chris Liebman
 * Created On      : Sat Feb 12 22:18:45 1994
 * Last Modified By: Chris Liebman
 * Last Modified On: Sun Feb 13 17:01:11 1994
 * Update Count    : 6
 * Status          : Released
 * 
 * HISTORY
 * 
 * PURPOSE
 * 	Definitions for commands.
 *
 * $Id: face_command.h,v 1.1 1994/02/13 22:01:14 liebman Exp $
*/

#ifndef FACE_COMMAND_H_
#define	FACE_COMMAND_H_

/*
 * Here is a face sound structure.
*/

struct face_command
{
    String		command;	/* Shell command. */
    int			refs;		/* Total refs on this face. */
    struct face_command	*next;		/* Pointer to next face. */
    struct face_command	*prev;		/* Pointer to prev face. */
};

#endif /* FACE_COMMAND_H_ */
