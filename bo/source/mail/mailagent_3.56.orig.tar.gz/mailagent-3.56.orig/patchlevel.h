/* mailagent-3.0 - 1 Dec 1993 */

#define VERSION 3.0
#define PATCHLEVEL 56
