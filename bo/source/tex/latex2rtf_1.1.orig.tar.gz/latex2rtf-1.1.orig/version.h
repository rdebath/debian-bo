/*
 * $Id: version.h,v 1.1 1994/07/13 09:29:37 ralf Exp $
 * History:
 * $Log: version.h,v $
 * Revision 1.1  1994/07/13  09:29:37  ralf
 * Corrected SunOs missing SEEK_SET, fpos_t, f{s,g}etpos
 *
 * Revision 1.0  1994/06/21  08:15:50  ralf
 * Initial revision
 *
 */
char *Version = "$Revision: 1.1 $ $Date: 1994/07/13 09:29:37 $";
