/*
 * $Id: stack.h,v 1.1 1994/06/17 11:26:29 ralf Exp $
 * History:
 * $Log: stack.h,v $
 * Revision 1.1  1994/06/17  11:26:29  ralf
 * Initial revision
 *
 */
int Push(int lev, int brack);
int Pop(int *lev, int *brack);

