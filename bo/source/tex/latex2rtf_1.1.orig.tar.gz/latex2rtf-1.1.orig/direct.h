/*
 * $Id: direct.h,v 1.1 1994/06/17 11:26:29 ralf Exp $
 * History:
 * $Log: direct.h,v $
 * Revision 1.1  1994/06/17  11:26:29  ralf
 * Initial revision
 *
 */

BOOL TryDirectConvert(char *command, FILE *fRtf);
BOOL WriteFontName(char **buffpoint, FILE *fRtf);
