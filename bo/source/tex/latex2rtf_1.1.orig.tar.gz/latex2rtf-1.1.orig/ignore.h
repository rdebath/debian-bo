/*
 * $Id: ignore.h,v 1.1 1994/06/17 11:26:29 ralf Exp $
 * History:
 * $Log: ignore.h,v $
 * Revision 1.1  1994/06/17  11:26:29  ralf
 * Initial revision
 *
 */
BOOL TryVariableIgnore(char *command, FILE *fRtf);
