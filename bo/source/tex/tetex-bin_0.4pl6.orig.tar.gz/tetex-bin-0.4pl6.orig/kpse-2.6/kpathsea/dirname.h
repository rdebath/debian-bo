extern char *dir_name (const char *name);
extern char *base_name (const char *name);
