/*
 * (c)1994 by MUFTI (scheurich@rus.uni-stuttgart.de) 
 * This file can be distributed under the terms of the GNU General Public
 * License.
 */

extern char *selfdir(char* argv0);
