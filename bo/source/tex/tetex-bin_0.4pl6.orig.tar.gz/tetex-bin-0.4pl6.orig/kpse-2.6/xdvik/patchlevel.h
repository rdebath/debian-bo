char *version = "xdvik version 18f";

