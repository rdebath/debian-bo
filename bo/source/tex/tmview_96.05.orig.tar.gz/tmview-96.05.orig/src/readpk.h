/* This is part of tmview, a dvi previewer. (c) 1995 Thomas Moor         */
/*                                                                       */
/* This program may be used without any warranty. It may be modified and */
/* distributed without any restrictions.                                 */


int pkfind(char*, char*, float, char*);
int pkdef(char*,int,long);
void pkloadchar(chdesc*);
void pkshrinkcharbw(chdesc*);
void pkshrinkcharazbw(chdesc*);
void pkshrinkchargs(chdesc*);
void pkshrinkcharazgs(chdesc*);
void pkshrinkcharazprecgs(chdesc*);


