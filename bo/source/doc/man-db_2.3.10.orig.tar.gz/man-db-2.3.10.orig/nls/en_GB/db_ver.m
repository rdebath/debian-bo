$set 101 #db_ver

$ #_WR_VERS Original Message:(fatal: unable to insert version identifier into %s)
# fatal: unable to insert version identifier into %s

$ #_NO_VERS Original Message:(warning: %s has no version identifier)
# warning: %s has no version identifier

$ #_BAD_VERS Original Message:(warning: %s is version %s, expecting %s)
# warning: %s is version %s, expecting %s
