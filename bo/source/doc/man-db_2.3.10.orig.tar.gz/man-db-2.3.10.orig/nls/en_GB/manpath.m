$set 8 #manpath

$ #_USAGE Original Message:(usage: %s [[-gcdq] [-m system]] | [-V] | [-h]\n)
# usage: %s [[-gcdq] [-m system]] | [-V] | [-h]\n

$ #_OPT Original Message:(-c --catpath                show relative catpaths.\n\
-g --global                 show the entire global manpath.\n\
-d --debug                  produce debugging info.\n\
-q --quiet                  produce fewer warnings.\n\
-m --systems system         express which `systems' to use.\n\
-V --version                show version.\n\
-h --help                   show this usage message.\n)
# -c --catpath                show relative catpaths.\n\
-g --global                 show the entire global manpath.\n\
-d --debug                  produce debugging info.\n\
-q --quiet                  produce fewer warnings.\n\
-m --systems system         express which `systems' to use.\n\
-V --version                show version.\n\
-h --help                   show this usage message.\n

$ #_NO_GLOBAL Original Message:(warning: no global manpaths set in config file %s)
# warning: no global manpaths set in config file %s
