$set 7 #lexgrog

$ #_TOOBIG Original Message:(warning: whatis for %s exceeds %d bytes, truncating.)
# warning: whatis for %s exceeds %d bytes, truncating.

$ #_OPEN Original Message:(can't open %s)
# can't open %s
