$set 3 #security

$ #_EUID Original Message:(can't set effective uid)
# can't set effective uid

$ #_REMOVE Original Message:(can't remove %s)
# can't remove %s

$ #_FORK Original Message:(can't fork)
# can't fork
