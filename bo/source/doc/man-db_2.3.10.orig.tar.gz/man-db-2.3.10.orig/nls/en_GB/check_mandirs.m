$set 12 #c_m

$ #_BOGUS Original Message:(warning: %s: ignoring bogus filename)
# warning: %s: ignoring bogus filename

$ #_MULT_EXT Original Message:(warning: %s/man%s/%s.%s*: competing extensions)
# warning: %s/man%s/%s.%s*: competing extensions

$ #_BAD_INCL Original Message:(warning: %s: bad symlink or ROFF `.so' request)
# warning: %s: bad symlink or ROFF `.so' request

$ #_MT_MAN Original Message:(warning: %s: ignoring empty file)
# warning: %s: ignoring empty file

$ #_NO_WHATIS Original Message:(warning: %s: whatis parse for %s(%s) failed)
# warning: %s: whatis parse for %s(%s) failed

$ #_OPENDIR Original Message:(can't search directory %s)
# can't search directory %s

$ #_UPDATE_DB Original Message:(can't update index cache %s)
# can't update index cache %s

$ #_UPDATE_DB_MSG Original Message:(\rUpdating index cache for path `%s'. Wait...)
# \rUpdating index cache for path `%s'. Wait...

$ #_CREATE_DB Original Message:(can't create index cache %s)
# can't create index cache %s

$ #_DONE Original Message:(done.\n)
# done.\n
