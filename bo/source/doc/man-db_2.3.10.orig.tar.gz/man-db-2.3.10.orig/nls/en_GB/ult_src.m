$set 4 #u_s

$ #_OPENDIR Original Message:(can't search directory %s)
# can't search directory %s

$ #_DANGLE Original Message:(warning: %s is a dangling symlink)
# warning: %s is a dangling symlink

$ #_RESOLVE Original Message:(can't resolve %s)
# can't resolve %s

$ #_SELF_REF Original Message:(%s is self referencing)
# %s is self referencing

$ #_OPEN Original Message:(can't open %s)
# can't open %s
