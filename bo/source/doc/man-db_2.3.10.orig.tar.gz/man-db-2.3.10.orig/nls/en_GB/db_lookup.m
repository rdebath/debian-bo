$set 104 #db_lookup

$ #_LOCK_DB Original Message:(can't lock index cache %s)
# can't lock index cache %s

$ #_CORRUPT Original Message:(index cache %s corrupt)
# index cache %s corrupt

$ #_REPLACE Original Message:(cannot replace key %s)
# cannot replace key %s

$ #_FEW_FIELDS Original Message:(only %d fields in content)
# only %d fields in content

$ #_BAD_MULTI Original Message:(bad fetch on multi key %s)
# bad fetch on multi key %s
