$set 11 #convnam

$ #_FAIL Original Message:(Can't convert %s to cat name)
# Can't convert %s to cat name
