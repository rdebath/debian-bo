$set 6 #stray

$ #_OPENDIR Original Message:(can't search directory %s)
# can't search directory %s

$ #_BOGUS Original Message:(warning: %s: ignoring bogus filename)
# warning: %s: ignoring bogus filename

$ #_NO_WHATIS Original Message:(warning: %s: whatis parse for %s(%s) failed)
# warning: %s: whatis parse for %s(%s) failed

$ #_CHECK Original Message:(Checking for stray cats under %s...\n)
# Checking for stray cats under %s...\n

$ #_UPDATE_DB Original Message:(warning: can't update index cache %s)
# warning: can't update index cache %s
