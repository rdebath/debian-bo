$set 1 #manp

$ #_PARSE_CONF Original Message:(can't make sense of the manpath configuration file %s)
# can't make sense of the manpath configuration file %s

$ #_STAT Original Message:(warning: %s)
# warning: %s

$ #_NOT_DIR Original Message:(warning: %s isn't a directory)
# warning: %s isn't a directory

$ #_NULL_MANPATH Original Message:(internal manpath equates to NULL)
# internal manpath equates to NULL

$ #_MANPATH Original Message:(warning: $MANPATH set, ignoring %s)
# warning: $MANPATH set, ignoring %s

$ #_NO_PATH Original Message:(warning: $PATH not set)
# warning: $PATH not set

$ #_MT_PATH Original Message:(warning: empty $PATH)
# warning: empty $PATH

$ #_OPEN_CONF Original Message:(can't open the manpath configuration file %s)
# can't open the manpath configuration file %s

$ #_PARSE_DIRS Original Message:(can't parse directory list `%s')
# can't parse directory list `%s'

$ #_MISS_DIR Original Message:(warning: mandatory directory %s doesn't exist)
# warning: mandatory directory %s doesn't exist

$ #_CWD Original Message:(can't determine current directory)
# can't determine current directory

$ #_NO_TREE Original Message:(warning: %s does not have a man tree component)
# warning: %s does not have a man tree component

$ #_PREFIX Original Message:(warning: %s does not begin with %s)
# warning: %s does not begin with %s
