$set 9 #compression

$ #_TEMPNAM Original Message:(can't create a temporary filename)
# can't create a temporary filename
