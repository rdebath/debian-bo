$set 6 #stray

$ #_OPENDIR Original Message:(can't search directory %s)
# Kann Verzeichnis %s nicht durchsuchen

$ #_BOGUS Original Message:(warning: %s: ignoring bogus filename)
# Warnung: %s: Ignoriere seltsamen Dateinamen

$ #_NO_WHATIS Original Message:(warning: %s: whatis parse for %s(%s) failed)
# Warnung: %s: Kann keinen whatis Eintrag f�r %s(%s) erstellen

$ #_CHECK Original Message:(Checking for stray cats under %s...\n)
# Suche nach Manual-Seiten ohne Quellcode...\n

$ #_UPDATE_DB Original Message:(warning: can't update index cache %s)
# Warnung: Kann Indexcache %s nicht updaten
