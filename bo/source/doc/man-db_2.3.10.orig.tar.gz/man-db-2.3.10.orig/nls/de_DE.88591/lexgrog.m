$set 7 #lexgrog

$ #_TOOBIG Original Message:(warning: whatis for %s exceeds %d bytes, truncating.)
# Warnung: whatis-Eintrag f�r %s ist gr�sser als %d Bytes, verk�rze ihn.

$ #_OPEN Original Message:(can't open %s)
# Kann %s nicht �ffnen
