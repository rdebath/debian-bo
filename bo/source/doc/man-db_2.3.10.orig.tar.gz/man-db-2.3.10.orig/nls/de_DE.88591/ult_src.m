$set 4 #u_s

$ #_OPENDIR Original Message:(can't search directory %s)
# Kann Verzeichnis %s nicht durchsuchen

$ #_DANGLE Original Message:(warning: %s is a dangling symlink)
# Warnung: Symbolischer Link %s zeigt auf nicht existierende Datei

$ #_RESOLVE Original Message:(can't resolve %s)
# Kann %s nicht aufl�sen

$ #_SELF_REF Original Message:(%s is self referencing)
# %s bezieht sich auf sich selbst

$ #_OPEN Original Message:(can't open %s)
# Kann %s nicht �ffnen
