$set 104 #db_lookup

$ #_LOCK_DB Original Message:(can't lock index cache %s)
# Kann Indexcachezugriff nicht sperren

$ #_CORRUPT Original Message:(index cache %s corrupt)
# Indexcache %s fehlerhaft

$ #_REPLACE Original Message:(cannot replace key %s)
# Kann Suchschl�ssel %s nicht ersetzen

$ #_FEW_FIELDS Original Message:(only %d fields in content)
# nur %d Felder im Dateneintrag enthalten

$ #_BAD_MULTI Original Message:(bad fetch on multi key %s)
# Kann Suchschl�ssel %s nicht einlesen
