$set 3 #security

$ #_EUID Original Message:(can't set effective uid)
# Kann effektive Benutzerkennung nicht setzen

$ #_REMOVE Original Message:(can't remove %s)
# Kann %s nicht l�schen

$ #_FORK Original Message:(can't fork)
# Kann keinen neuen Proze� erzeugen
