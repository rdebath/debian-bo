$set 9 #compression

$ #_TEMPNAM Original Message:(can't create a temporary filename)
# Kann tempor�ren Dateinamen nicht erzeugen
