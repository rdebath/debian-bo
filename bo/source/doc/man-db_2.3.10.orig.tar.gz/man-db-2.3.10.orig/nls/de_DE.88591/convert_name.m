$set 11 #convnam

$ #_FAIL Original Message:(Can't convert %s to cat name)
# Kann %s nicht in Dateinamen f�r vorformatierte Manual-Seiten umwandeln
