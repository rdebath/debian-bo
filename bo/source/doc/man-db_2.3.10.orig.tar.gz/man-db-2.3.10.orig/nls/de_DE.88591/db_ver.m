$set 101 #db_ver

$ #_WR_VERS Original Message:(fatal: unable to insert version identifier into %s)
# Fatal: Kann Versionsnummer nicht in %s einf�gen

$ #_NO_VERS Original Message:(warning: %s has no version identifier)
# Warnung: %s hat keine Versionsnummer

$ #_BAD_VERS Original Message:(warning: %s is version %s, expecting %s)
# Warnung: %s hat Versionsnummer %s, erwarte aber %s
