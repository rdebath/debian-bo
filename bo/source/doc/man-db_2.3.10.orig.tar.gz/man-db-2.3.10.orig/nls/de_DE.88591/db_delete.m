$set 103 #db_delete

$ #_NO_MULTI Original Message:(multi key %s does not exist)
# Suchschl�ssel %s existiert nicht
