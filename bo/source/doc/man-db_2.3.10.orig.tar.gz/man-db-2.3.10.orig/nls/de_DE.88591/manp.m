$set 1 #manp

$ #_PARSE_CONF Original Message:(can't make sense of the manpath configuration file %s)
# Kann Manualpfad-Konfigurationsdatei %s nicht verstehen

$ #_STAT Original Message:(warning: %s)
# Warnung: %s

$ #_NOT_DIR Original Message:(warning: %s isn't a directory)
# Warnung: %s ist kein Verzeichnis

$ #_NULL_MANPATH Original Message:(internal manpath equates to NULL)
# Interner manpath ist NULL

$ #_MANPATH Original Message:(warning: $MANPATH set, ignoring %s)
# Warnung: $MANPATH ist gesetzt, ignoriere %s

$ #_NO_PATH Original Message:(warning: $PATH not set)
# Warnung: $PATH nicht gesetzt

$ #_MT_PATH Original Message:(warning: empty $PATH)
# Warnung: $PATH ist leer

$ #_OPEN_CONF Original Message:(can't open the manpath configuration file %s)
# Kann Manualpfad-Konfigurationsdatei %s nicht �ffnen

$ #_PARSE_DIRS Original Message:(can't parse directory list `%s')
# Kann Verzeichnisliste `%s' nicht verstehen

$ #_MISS_DIR Original Message:(warning: mandatory directory %s doesn't exist)
# Warnung: Verzeichnis %s existiert nicht

$ #_CWD Original Message:(can't determine current directory)
# Kann momentanes Verzeichnis nicht feststellen

$ #_NO_TREE Original Message:(warning: %s does not have a man tree component)
# Warnung: %s hat keine Manual-Verzeichniskomponente

$ #_PREFIX Original Message:(warning: %s does not begin with %s)
# Warnung: %s f�ngt nicht mit %s an
