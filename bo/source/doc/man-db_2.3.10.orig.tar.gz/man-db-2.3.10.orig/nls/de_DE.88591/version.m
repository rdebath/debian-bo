$set 10 #version

$ #_STRING Original Message:(%s, version %s, db %s, %s (G.Wilford@ee.surrey.ac.uk)\n)
# %s, Version %s, db-Version %s, %s (G.Wilford@ee.surrey.ac.uk)\n
