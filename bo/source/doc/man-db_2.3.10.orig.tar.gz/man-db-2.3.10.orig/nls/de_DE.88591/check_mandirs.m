$set 12 #c_m

$ #_BOGUS Original Message:(warning: %s: ignoring bogus filename)
# Warnung: %s: ignoriere seltsamen Dateinamen

$ #_MULT_EXT Original Message:(warning: %s/man%s/%s.%s*: competing extensions)
# Warnung: %s/man%s/%s.%s*: konkurrierende Dateierweiterungen

$ #_BAD_INCL Original Message:(warning: %s: bad symlink or ROFF `.so' request)
# Warnung: %s: ung�ltiger symbolischer Link oder falsche ROFF `.so' Anfrage

$ #_MT_MAN Original Message:(warning: %s: ignoring empty file)
# Warnung: %s: ignoriere leere Datei

$ #_NO_WHATIS Original Message:(warning: %s: whatis parse for %s(%s) failed)
# Warnung: %s: Kann keinen whatis Eintrag f�r %s(%s) erzeugen

$ #_OPENDIR Original Message:(can't search directory %s)
# Kann Verzeichnis %s nicht durchsuchen

$ #_UPDATE_DB Original Message:(can't update index cache %s)
# Kann Indexcache %s nicht updaten

$ #_UPDATE_DB_MSG Original Message:(\rUpdating index cache for path `%s'. Wait...)
# \rUpdate Indexcache von Pfad `%s'. Bitte warten...

$ #_CREATE_DB Original Message:(can't create index cache %s)
# Kann Indexcache %s nicht erzeugen

$ #_DONE Original Message:(done.\n)
# fertig.\n
