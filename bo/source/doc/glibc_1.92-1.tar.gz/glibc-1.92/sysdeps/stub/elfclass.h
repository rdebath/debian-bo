/* This file specifies the native word size of the machine, which indicates
   the ELF file class used for executables and shared objects on this
   machine.  */

#define __ELF_NATIVE_CLASS ??

/* This file goes in sysdeps/wordsize-?? and sysdeps/MACHINE/Implies lists
   wordsize-?? for MACHINE's wordsize.  */
