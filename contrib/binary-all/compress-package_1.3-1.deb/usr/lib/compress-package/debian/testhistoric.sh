#! /bin/sh

me=`basename $0`

historic="uncompress zcat zmore zless zcmp zdiff zgrep zegrep zfgrep"

findcmdargs="( -name `echo $historic | sed 's/ / -o -name /g'` )"

if [ ! -d debian-tmp/usr/bin -o ! -d debian-tmp/usr/man ]
then
    >&2 echo $me: no correct debian-tmp directory here, aborting
    exit 2
fi

test ! -z "`find debian-tmp/usr/bin $findcmdargs -print`"

