switch (difficulty)
  {
  case 0:
    ROCKET_SPEED = 0.8;
    BALL_SPEED = 1.2;
    BBALL_SPEED = 1.2;
    SLOWDOWN = 0.9;
    GUMM = 20;


    BALLM = 3;
    LBALLM = 3;
    BBALLM = 8;
    APPLEM = 40;
    ROCKETM = 2;
    break;
  case 1:
    ROCKET_SPEED = 1.0;
    BALL_SPEED = 1.2;
    BBALL_SPEED = 1.2;
    SLOWDOWN = 0.9;
    GUMM = 20;


    BALLM = 3;
    LBALLM = 3;
    BBALLM = 8;
    APPLEM = 40;
    ROCKETM = 4;

    break;
  case 2:
    ROCKET_SPEED = 1.2;
    BALL_SPEED = 1.2;
    BBALL_SPEED = 1.2;
    SLOWDOWN = 0.8;
    GUMM = 20;


    APPLEM = 34;
    BALLM = 3;
    LBALLM = 3;
    BBALLM = 8;
    ROCKETM = 4;
    break;
  case 3:
    ROCKET_SPEED = 2.0;
    BALL_SPEED = 1.2;
    BBALL_SPEED = 1.2;
    SLOWDOWN = 0.8;
    GUMM = 20;


    BALLM = 3;
    LBALLM = 3;
    APPLEM = 24;
    BBALLM = 8;
    ROCKETM = 5;
  case 5:
    ROCKET_SPEED = 2.0;
    BALL_SPEED = 1.2;
    BBALL_SPEED = 1.2;
    SLOWDOWN = 0.8;
    GUMM = 15;


    BALLM = 3;
    LBALLM = 3;
    APPLEM = 24;
    BBALLM = 8;
    ROCKETM = 7;


  }
