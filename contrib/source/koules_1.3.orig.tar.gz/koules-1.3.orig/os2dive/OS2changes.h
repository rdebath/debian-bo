/* Changes for OS/2 Warp with Dive.                        *
*  Copyright(c)1996 by Thomas A. K. Kjaer                  *
***********************************************************/
