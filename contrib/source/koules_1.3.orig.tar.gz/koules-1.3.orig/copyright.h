/* This copyright is only for sound servers!!!!!!!!!!!!!!!!!!!!!!!!
   for koules sources read README */
/*
   Copyright (c) 1995   Joe Rumsey

   Permission to use, copy, modify, and distribute this
   software and its documentation for any purpose and without
   fee is hereby granted, provided that the above copyright
   notice appear in all copies and that both that copyright
   notice and this permission notice appear in supporting
   documentation.  No representations are made about the
   suitability of this software for any purpose.  It is
   provided "as is" without express or implied warranty.

 */
