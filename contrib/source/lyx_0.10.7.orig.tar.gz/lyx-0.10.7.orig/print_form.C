/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "print_form.h"

FD_form_print *create_form_form_print(void)
{
  FL_OBJECT *obj;
  FD_form_print *fdui = (FD_form_print *) fl_calloc(1, sizeof(*fdui));

  fdui->form_print = fl_bgn_form(FL_NO_BOX, 440, 300);
  obj = fl_add_box(FL_UP_BOX,0,0,440,300,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,300,30,130,70,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,140,30,150,100,"");
  obj = fl_add_button(FL_RETURN_BUTTON,20,260,130,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,PrintOKCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,160,260,130,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,PrintApplyCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,300,260,130,30,"Cancel");
    fl_set_button_shortcut(obj,"#C^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,PrintCancelCB,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,30,80,30,"Print");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,20,140,400,100,"");
  obj = fl_add_text(FL_NORMAL_TEXT,30,130,60,20,"Print to");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->input_printer = obj = fl_add_input(FL_NORMAL_INPUT,100,160,300,30,"");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
  fdui->input_file = obj = fl_add_input(FL_NORMAL_INPUT,100,200,300,30,"");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);

  fdui->group_radio_printto = fl_bgn_group();
  fdui->radio_printer = obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,160,70,30,"Printer");
    fl_set_button_shortcut(obj,"#P",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_file = obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,200,70,30,"File");
    fl_set_button_shortcut(obj,"#F",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,150,20,50,20,"Print");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);

  fdui->group_radio_pages = fl_bgn_group();
  fdui->radio_all_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,40,150,30,"All Pages");
    fl_set_button_shortcut(obj,"#G",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_odd_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,70,150,30,"Only Odd Pages");
    fl_set_button_shortcut(obj,"#O",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_even_pages = obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,100,150,30,"Only Even Pages");
    fl_set_button_shortcut(obj,"#E",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();


  fdui->group_radio_order = fl_bgn_group();
  fdui->radio_order_normal = obj = fl_add_checkbutton(FL_RADIO_BUTTON,300,40,120,30,"Normal Order");
    fl_set_button_shortcut(obj,"#N",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_order_reverse = obj = fl_add_checkbutton(FL_RADIO_BUTTON,300,70,120,30,"Reverse Order");
    fl_set_button_shortcut(obj,"#R",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,310,20,50,20,"Order");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

