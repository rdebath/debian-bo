#ifndef FD_form_spell_options_h_
#define FD_form_spell_options_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void SpellOptionsOKCB(FL_OBJECT *, long);
extern void SpellOptionsCancelCB(FL_OBJECT *, long);
extern void SpellOptionsApplyCB(FL_OBJECT *, long);



/**** Forms and Objects ****/

typedef struct {
	FL_FORM *form_spell_options;
	FL_OBJECT *lang_buts;
	FL_OBJECT *buflang;
	FL_OBJECT *altlang;
	FL_OBJECT *altlang_input;
	FL_OBJECT *compounds;
	FL_OBJECT *rootaffix;
	FL_OBJECT *ok;
	FL_OBJECT *perdict;
	FL_OBJECT *esc_chars;
	FL_OBJECT *perdict_input;
	FL_OBJECT *esc_chars_input;
	void *vdata;
	long ldata;
} FD_form_spell_options;

extern FD_form_spell_options * create_form_form_spell_options(void);
typedef struct {
	FL_FORM *form_spell_check;
	FL_OBJECT *text;
	FL_OBJECT *input;
	FL_OBJECT *browser;
	FL_OBJECT *options;
	FL_OBJECT *start;
	FL_OBJECT *insert;
	FL_OBJECT *ignore;
	FL_OBJECT *accept;
	FL_OBJECT *stop;
	FL_OBJECT *done;
	FL_OBJECT *slider;
	FL_OBJECT *replace;
	void *vdata;
	long ldata;
} FD_form_spell_check;

extern FD_form_spell_check * create_form_form_spell_check(void);

#endif /* FD_form_spell_options_h_ */
