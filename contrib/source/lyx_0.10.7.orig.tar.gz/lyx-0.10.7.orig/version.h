/* Version and release date definition */
#define VERSION "0.10.7 BETA"
#define RELEASE "Thu, Oct 17, 1996"
