/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "math_panel.h"

FD_panel *create_form_panel(void)
{
  FL_OBJECT *obj;
  FD_panel *fdui = (FD_panel *) fl_calloc(1, sizeof(*fdui));

  fdui->panel = fl_bgn_form(FL_NO_BOX, 340, 170);
  obj = fl_add_box(FL_UP_BOX,0,0,340,170,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,110,320,50,"");
  fdui->greek = obj = fl_add_button(FL_NORMAL_BUTTON,20,120,50,30,"Greek");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,15);
    fl_set_object_callback(obj,button_cb,MM_GREEK);
  fdui->arrow = obj = fl_add_button(FL_NORMAL_BUTTON,170,120,50,30,"� �");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,15);
    fl_set_object_callback(obj,button_cb,MM_ARROW);
  fdui->boperator = obj = fl_add_button(FL_NORMAL_BUTTON,70,120,50,30,"� �");
    fl_set_object_lsize(obj,0);
    fl_set_object_lstyle(obj,15);
    fl_set_object_callback(obj,button_cb,MM_BOP);
  fdui->brelats = obj = fl_add_button(FL_NORMAL_BUTTON,120,120,50,30,"� @");
    fl_set_object_lsize(obj,0);
    fl_set_object_lstyle(obj,15);
    fl_set_object_callback(obj,button_cb,MM_BRELATS);
  fdui->varsize = obj = fl_add_button(FL_NORMAL_BUTTON,220,120,50,30,"S  �");
    fl_set_object_lsize(obj,0);
    fl_set_object_lstyle(obj,15);
    fl_set_object_callback(obj,button_cb,MM_VARSIZE);
  fdui->misc = obj = fl_add_button(FL_NORMAL_BUTTON,270,120,50,30,"Misc");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE);
    fl_set_object_callback(obj,button_cb,MM_MISC);
  obj = fl_add_button(FL_RETURN_BUTTON,240,20,90,30,"Close ");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,button_cb,100);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,130,40,"Math Panel");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,100,70,20,"Symbols");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->equation = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,260,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_EQU);
  fdui->sqrt = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,20,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_SQRT);
  fdui->frac = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,60,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_lcol(obj,FL_COL1);
    fl_set_object_callback(obj,button_cb,MM_FRAC);
  fdui->delim = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,100,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_DELIM);
  fdui->matrix = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,220,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_MATRIX);
  fdui->deco = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,140,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_DECO);
  fdui->space = obj = fl_add_pixmapbutton(FL_NORMAL_BUTTON,180,60,30,30,"");
    fl_set_object_color(obj,FL_MCOL,FL_BLUE);
    fl_set_object_callback(obj,button_cb,MM_SPACE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_delim *create_form_delim(void)
{
  FL_OBJECT *obj;
  FD_delim *fdui = (FD_delim *) fl_calloc(1, sizeof(*fdui));

  fdui->delim = fl_bgn_form(FL_NO_BOX, 250, 300);
  obj = fl_add_box(FL_UP_BOX,0,0,250,300,"");
  fdui->menu = obj = fl_add_bmtable(FL_PUSH_BUTTON,40,110,170,140,"");
    fl_set_object_lcol(obj,FL_BLUE);
    fl_set_object_callback(obj,delim_cb,2);

  fdui->lado = fl_bgn_group();
  fdui->right = obj = fl_add_checkbutton(FL_RADIO_BUTTON,40,80,80,30,"Right");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,delim_cb,4);
  fdui->left = obj = fl_add_checkbutton(FL_RADIO_BUTTON,40,50,80,30,"Left");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,delim_cb,3);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,10,10,110,40,"Delimiter");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_button(FL_NORMAL_BUTTON,170,260,70,30,"Cancel");
    fl_set_button_shortcut(obj,"^[#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,delim_cb,MM_CLOSE);
  fdui->pix = obj = fl_add_pixmap(FL_NORMAL_PIXMAP,130,60,50,40,"");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
  obj = fl_add_button(FL_NORMAL_BUTTON,90,260,70,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,delim_cb,MM_APPLY);
  obj = fl_add_button(FL_RETURN_BUTTON,10,260,70,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,delim_cb,MM_OK);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_matrix *create_form_matrix(void)
{
  FL_OBJECT *obj;
  FD_matrix *fdui = (FD_matrix *) fl_calloc(1, sizeof(*fdui));

  fdui->matrix = fl_bgn_form(FL_NO_BOX, 310, 210);
  obj = fl_add_box(FL_UP_BOX,0,0,310,210,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,80,40,"Matrix");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_button(FL_RETURN_BUTTON,10,170,80,30,"OK  ");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,matrix_cb,MM_OK);
  obj = fl_add_button(FL_NORMAL_BUTTON,210,170,90,30,"Cancel");
    fl_set_button_shortcut(obj,"^[#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,matrix_cb,MM_CLOSE);
  fdui->rows = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,10,70,180,30,"Rows");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,matrix_cb,-1);
    fl_set_slider_precision(obj, 0);
    fl_set_slider_bounds(obj, 1, 20);
    fl_set_slider_value(obj, 3);
     fl_set_slider_return(obj, FL_RETURN_END_CHANGED);
  fdui->columns = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,10,130,180,30,"Columns");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,matrix_cb,2);
    fl_set_slider_precision(obj, 0);
    fl_set_slider_bounds(obj, 1, 20);
    fl_set_slider_value(obj, 3);
     fl_set_slider_return(obj, FL_RETURN_END_CHANGED);
  fdui->valign = obj = fl_add_choice(FL_NORMAL_CHOICE,210,130,90,30,"Vertical align");
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,matrix_cb,-1);
  fdui->halign = obj = fl_add_input(FL_NORMAL_INPUT,210,70,90,30,"Horizontal align");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_callback(obj,matrix_cb,2);
  obj = fl_add_button(FL_NORMAL_BUTTON,110,170,80,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,matrix_cb,MM_APPLY);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_deco *create_form_deco(void)
{
  FL_OBJECT *obj;
  FD_deco *fdui = (FD_deco *) fl_calloc(1, sizeof(*fdui));

  fdui->deco = fl_bgn_form(FL_NO_BOX, 220, 190);
  obj = fl_add_box(FL_UP_BOX,0,0,220,190,"");
  fdui->menu = obj = fl_add_bmtable(FL_PUSH_BUTTON,60,60,144,72,"");
    fl_set_object_lcol(obj,FL_BLUE);
    fl_set_object_callback(obj,deco_cb,MM_APPLY);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,120,40,"Decoration");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,10,60,50,20,"Over");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,10,110,50,20,"Under");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_RIGHT|FL_ALIGN_INSIDE);
  obj = fl_add_button(FL_RETURN_BUTTON,60,150,110,30,"Close");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,deco_cb,MM_CLOSE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_space *create_form_space(void)
{
  FL_OBJECT *obj;
  FD_space *fdui = (FD_space *) fl_calloc(1, sizeof(*fdui));

  fdui->space = fl_bgn_form(FL_NO_BOX, 270, 210);
  obj = fl_add_box(FL_UP_BOX,0,0,270,210,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,130,40,"Math space");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_TIMESITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_button(FL_RETURN_BUTTON,10,170,70,30,"OK ");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,MM_OK);
  obj = fl_add_button(FL_NORMAL_BUTTON,190,170,70,30,"Cancel");
    fl_set_button_shortcut(obj,"^[#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,MM_CLOSE);
  obj = fl_add_button(FL_NORMAL_BUTTON,100,170,70,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,MM_APPLY);

  fdui->spaces = fl_bgn_group();
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,60,110,30,"Thin");
    fl_set_button_shortcut(obj,"#T",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,1);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,90,120,30,"Medium");
    fl_set_button_shortcut(obj,"#M",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,2);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,120,120,30,"Thick");
    fl_set_button_shortcut(obj,"#H",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,3);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,60,120,30,"Negative");
    fl_set_button_shortcut(obj,"#N",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,0);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,90,120,30,"Quadratin");
    fl_set_button_shortcut(obj,"#Q",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,4);
  obj = fl_add_checkbutton(FL_RADIO_BUTTON,140,120,120,30,"2Quadratin");
    fl_set_button_shortcut(obj,"#2",1);
    fl_set_object_color(obj,FL_MCOL,FL_YELLOW);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,space_cb,5);
  fl_end_group();

  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

