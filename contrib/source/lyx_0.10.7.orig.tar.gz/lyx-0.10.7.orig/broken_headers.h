// -*- C++ -*-
/* This file is part of
* ======================================================
* 
*           LyX, the High Level Word Processor
*        
*           Copyright (C) 1995,1996 Matthias Ettrich
*
*======================================================
 A few prototypes missing from Sun and SCO header files */

#ifndef BROKEN_HEADERS_H
#define BROKEN_HEADERS_H

#ifndef HAVE_MEMMOVE
extern "C" void bcopy(unsigned char *b1, unsigned char *b2, int length);
#endif
extern "C" char *mktemp(char *templ);
extern "C" int readlink(const char *path, char *buf, int bufsiz);
extern "C" int strcasecmp(const char *s1, const char *s2);

#endif /* BROKEN_HEADERS_H */
