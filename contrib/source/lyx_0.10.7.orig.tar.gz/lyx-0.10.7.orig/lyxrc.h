// -*- C++ -*-
/* This file is part of
* ======================================================
* 
*           LyX, the High Level Word Processor
* 	 
*	    Copyright (C) 1995 Matthias Ettrich
*
*======================================================*/
#ifndef _LYXRC_H
#define _LYXRC_H

#include "lyxparameters.h"

class LyXRC {
public:
	LyXRC();
	~LyXRC();
	int Read (const char * filename);
        void Print();
	LyXTextParameters parameters;
	char * printer;
	char * print_command;
	char * print_evenpage_flag;
	char * print_oddpage_flag;
	char * print_reverse_flag;
	char * print_landscape_flag;
	char * print_to_printer;
	char * print_to_file;
	char * print_file_extension;
	char * print_extra_options;
	char * print_spool_cmd;
	char * latex_command;
	char * xdvi_extra_options;
	char * sgml_extra_options;
	char * lyx_layout_lib;
	char * template_path;
	char * tempdir_path;
	bool use_tempdir;
	char * lastfiles;
	char default_zoom;
	char * fontenc;
	bool allowAccents;
	int autosave;
	bool auto_region_delete;
};

extern LyXRC lyxrc;
#endif
