// -*- C++ -*-
/* This file is part of
 * ======================================================
 * 
 *           LyX, the High Level Word Processor
 * 	 
 *	    Copyright (C) 1995 Matthias Ettrich
 *
 *======================================================*/

#ifndef _LYXROW_H
#define _LYXROW_H

#include "lyxparagraph.h"

struct Row {
  LyXParagraph *par;
  int pos;
  unsigned short  baseline;
  int fill; /* what is missing to a full row 
	     * can be negative.
	     * needed for hfills, flushright, block etc. */
  unsigned short  height;
   unsigned short ascent_of_text;
   
   
  Row* next;
  Row* previous;
};

#endif
