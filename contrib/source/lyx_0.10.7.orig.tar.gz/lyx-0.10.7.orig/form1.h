#ifndef FD_KeyMap_h_
#define FD_KeyMap_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void Keymap(FL_OBJECT *, long);

extern void EpsFig(FL_OBJECT *, long);

extern void FileDlgCB(FL_OBJECT *, long);

extern void TableOKCB(FL_OBJECT *, long);
extern void TableApplyCB(FL_OBJECT *, long);
extern void TableCancelCB(FL_OBJECT *, long);

extern void SearchForwardCB(FL_OBJECT *, long);
extern void SearchBackwardCB(FL_OBJECT *, long);
extern void SearchReplaceCB(FL_OBJECT *, long);
extern void SearchCancelCB(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *KeyMap;
	FL_OBJECT *Charset;
	FL_OBJECT *ChsetErr;
	FL_OBJECT *KeymapErr;
	FL_OBJECT *AcceptChset;
	FL_OBJECT *Accept;
//	FL_OBJECT *Language;
	FL_OBJECT *OtherKeymap;
	FL_OBJECT *KeyYZ;
//	FL_OBJECT *Language2;
	FL_OBJECT *OtherKeymap2;
	FL_OBJECT *KeyMapOn;
	FL_OBJECT *KeyOnBtn;
	FL_OBJECT *KeyOffBtn;
	FL_OBJECT *KeyOnBtn2;
	void *vdata;
	long ldata;
} FD_KeyMap;

extern FD_KeyMap * create_form_KeyMap(void);
typedef struct {
	FL_FORM *Figure;
	FL_OBJECT *Command;
	FL_OBJECT *WidthLabel;
	FL_OBJECT *EpsFile;
	FL_OBJECT *Preview;
	FL_OBJECT *Browse;
	FL_OBJECT *Width;
	FL_OBJECT *Height;
	FL_OBJECT *ApplyCmd;
	FL_OBJECT *WidthGrp;
	FL_OBJECT *Default1;
	FL_OBJECT *cm1;
	FL_OBJECT *in1;
	FL_OBJECT *page1;
	FL_OBJECT *Extra;
	FL_OBJECT *ApplyBtn;
	FL_OBJECT *OkBtn;
	FL_OBJECT *CancelBtn;
	FL_OBJECT *Frame;
	FL_OBJECT *Translations;
	FL_OBJECT *HeightLabel;
	FL_OBJECT *Angle;
	FL_OBJECT *Wysiwyg;
	FL_OBJECT *Wysiwyg3;
	FL_OBJECT *Wysiwyg0;
	FL_OBJECT *Wysiwyg2;
	FL_OBJECT *Wysiwyg1;
	FL_OBJECT *HeightGrp;
	FL_OBJECT *page2;
	FL_OBJECT *Default2;
	FL_OBJECT *cm2;
	FL_OBJECT *in2;
	void *vdata;
	long ldata;
} FD_Figure;

extern FD_Figure * create_form_Figure(void);
typedef struct {
	FL_FORM *FileDlg;
	FL_OBJECT *PatBox;
	FL_OBJECT *FileInfo;
	FL_OBJECT *Filename;
	FL_OBJECT *Rescan;
	FL_OBJECT *Home;
	FL_OBJECT *List;
	FL_OBJECT *Cancel;
	FL_OBJECT *User2;
	FL_OBJECT *User1;
	FL_OBJECT *Ready;
	FL_OBJECT *DirBox;
	void *vdata;
	long ldata;
} FD_FileDlg;

extern FD_FileDlg * create_form_FileDlg(void);
typedef struct {
	FL_FORM *form_table;
	FL_OBJECT *slider_columns;
	FL_OBJECT *slider_rows;
	FL_OBJECT *button_ok;
	FL_OBJECT *button_apply;
	FL_OBJECT *button_cancel;
	void *vdata;
	long ldata;
} FD_form_table;

extern FD_form_table * create_form_form_table(void);
typedef struct {
	FL_FORM *form_search;
	FL_OBJECT *input_search;
	FL_OBJECT *input_replace;
	void *vdata;
	long ldata;
} FD_form_search;

extern FD_form_search * create_form_form_search(void);

#endif /* FD_KeyMap_h_ */
