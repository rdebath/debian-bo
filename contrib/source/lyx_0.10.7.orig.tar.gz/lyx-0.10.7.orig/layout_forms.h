#ifndef FD_form_document_h_
#define FD_form_document_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void ChoiceClassCB(FL_OBJECT *, long);
extern void DocumentCancelCB(FL_OBJECT *, long);
extern void DocumentApplyCB(FL_OBJECT *, long);
extern void DocumentOKCB(FL_OBJECT *, long);

extern void CharacterOKCB(FL_OBJECT *, long);
extern void CharacterApplyCB(FL_OBJECT *, long);
extern void CharacterCancelCB(FL_OBJECT *, long);

extern void ParagraphOKCB(FL_OBJECT *, long);
extern void ParagraphApplyCB(FL_OBJECT *, long);
extern void ParagraphCancelCB(FL_OBJECT *, long);

extern void PreambleOKCB(FL_OBJECT *, long);
extern void PreambleApplyCB(FL_OBJECT *, long);
extern void PreambleCancelCB(FL_OBJECT *, long);

extern void QuotesOKCB(FL_OBJECT *, long);
extern void QuotesApplyCB(FL_OBJECT *, long);
extern void QuotesCancelCB(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *form_document;
	FL_OBJECT *choice_class;
	FL_OBJECT *choice_pagestyle;
	FL_OBJECT *choice_fonts;
	FL_OBJECT *choice_fontsize;
	FL_OBJECT *choice_papersize;
	FL_OBJECT *input_float_placement;
	FL_OBJECT *choice_epsfig;
	FL_OBJECT *choice_inputenc;
	FL_OBJECT *slider_baselinestretch;
	FL_OBJECT *slider_secnumdepth;
	FL_OBJECT *slider_tocdepth;
	FL_OBJECT *group_radio_sides;
	FL_OBJECT *radio_sides_one;
	FL_OBJECT *radio_sides_two;
	FL_OBJECT *greoup_radio_orientation;
	FL_OBJECT *radio_portrait;
	FL_OBJECT *radio_landscape;
	FL_OBJECT *group_radio_columns;
	FL_OBJECT *radio_columns_one;
	FL_OBJECT *radio_columns_two;
	FL_OBJECT *group_radio_separation;
	FL_OBJECT *radio_indent;
	FL_OBJECT *radio_skip;
	FL_OBJECT *input_extra;
	FL_OBJECT *choice_language;
	void *vdata;
	long ldata;
} FD_form_document;

extern FD_form_document * create_form_form_document(void);
typedef struct {
	FL_FORM *form_character;
	FL_OBJECT *choice_family;
	FL_OBJECT *choice_series;
	FL_OBJECT *choice_shape;
	FL_OBJECT *choice_size;
	FL_OBJECT *choice_bar;
	FL_OBJECT *button_ok;
	FL_OBJECT *button_apply;
	FL_OBJECT *button_cancel;
	void *vdata;
	long ldata;
} FD_form_character;

extern FD_form_character * create_form_form_character(void);
typedef struct {
	FL_FORM *form_paragraph;
	FL_OBJECT *button_ok;
	FL_OBJECT *button_apply;
	FL_OBJECT *button_cancel;
	FL_OBJECT *input_labelwidth;
	FL_OBJECT *check_lines_top;
	FL_OBJECT *check_lines_bottom;
	FL_OBJECT *check_pagebreaks_top;
	FL_OBJECT *check_pagebreaks_bottom;
	FL_OBJECT *check_noindent;
	FL_OBJECT *group_radio_alignment;
	FL_OBJECT *radio_align_right;
	FL_OBJECT *radio_align_left;
	FL_OBJECT *radio_align_block;
	FL_OBJECT *radio_align_center;
	FL_OBJECT *slider_spaces_top;
	FL_OBJECT *slider_spaces_bottom;
	FL_OBJECT *check_fill_top;
	FL_OBJECT *check_fill_bottom;
	void *vdata;
	long ldata;
} FD_form_paragraph;

extern FD_form_paragraph * create_form_form_paragraph(void);
typedef struct {
	FL_FORM *form_preamble;
	FL_OBJECT *button_ok;
	FL_OBJECT *button_apply;
	FL_OBJECT *button_cancel;
	FL_OBJECT *input_preamble;
	void *vdata;
	long ldata;
} FD_form_preamble;

extern FD_form_preamble * create_form_form_preamble(void);
typedef struct {
	FL_FORM *form_quotes;
	FL_OBJECT *choice_quotes_language;
	FL_OBJECT *group_radio_quotes_number;
	FL_OBJECT *radio_single;
	FL_OBJECT *radio_double;
	void *vdata;
	long ldata;
} FD_form_quotes;

extern FD_form_quotes * create_form_form_quotes(void);

#endif /* FD_form_document_h_ */
