/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "form1.h"

FD_KeyMap *create_form_KeyMap(void)
{
  FL_OBJECT *obj;
  FD_KeyMap *fdui = (FD_KeyMap *) fl_calloc(1, sizeof(*fdui));

  fdui->KeyMap = fl_bgn_form(FL_NO_BOX, 320, 550);
  obj = fl_add_box(FL_UP_BOX,0,0,320,550,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,20,400,280,90,"");
  fdui->Charset = obj = fl_add_input(FL_NORMAL_INPUT,130,410,160,30,"Character set:");
    fl_set_input_shortcut(obj,"#H",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,26);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,200,250,100,140,"");
  fdui->ChsetErr = obj = fl_add_text(FL_NORMAL_TEXT,210,270,80,100,"Error:\n\nCharset\nnot found");
    fl_set_object_lcol(obj,FL_RED);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE+FL_EMBOSSED_STYLE);
  fdui->KeymapErr = obj = fl_add_text(FL_NORMAL_TEXT,210,270,80,100,"Error:\n\nKeymap\nnot found");
    fl_set_object_lcol(obj,FL_RED);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE+FL_EMBOSSED_STYLE);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,20,250,170,100,"");
  fdui->AcceptChset = obj = fl_add_button(FL_NORMAL_BUTTON,100,450,120,30,"Set Charset");
    fl_set_button_shortcut(obj,"#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,27);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,20,60,280,170,"");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,20,360,170,30,"");
  fdui->Accept = obj = fl_add_button(FL_RETURN_BUTTON,100,500,120,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,0);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,240,40,"Keyboard Mapping");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
    
    //  fdui->Language = obj = fl_add_choice(FL_NORMAL_CHOICE,110,70,170,30,"Primary");
    //fl_set_object_shortcut(obj,"#P",1);
    //fl_set_object_boxtype(obj,FL_FRAME_BOX);
    //fl_set_object_lsize(obj,0);
    //fl_set_object_callback(obj,Keymap,4);
    
  fdui->OtherKeymap = obj = fl_add_input(FL_NORMAL_INPUT,110,110,170,30,"Other...");
    fl_set_input_shortcut(obj,"#O",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,5);
  fdui->KeyYZ = obj = fl_add_checkbutton(FL_PUSH_BUTTON,20,360,170,30,"Switch Y<->Z");
    fl_set_button_shortcut(obj,"#Y",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,6);

    //fdui->Language2 = obj = fl_add_choice(FL_NORMAL_CHOICE,110,150,170,30,"Secondary");
    //fl_set_object_shortcut(obj,"#S",1);
    //fl_set_object_boxtype(obj,FL_FRAME_BOX);
    //fl_set_object_lsize(obj,0);
    //fl_set_object_callback(obj,Keymap,24);
    
  fdui->OtherKeymap2 = obj = fl_add_input(FL_NORMAL_INPUT,110,190,170,30,"Other...");
    fl_set_input_shortcut(obj,"#T",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,25);
  obj = fl_add_text(FL_NORMAL_TEXT,30,50,80,20,"Language");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,30,240,70,20,"Mapping");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);

  fdui->KeyMapOn = fl_bgn_group();
  fdui->KeyOnBtn = obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,290,170,30,"Primary key map");
    fl_set_button_shortcut(obj,"#r",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,23);
  fdui->KeyOffBtn = obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,260,170,30,"No key mapping");
    fl_set_button_shortcut(obj,"#N",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,3);
  fdui->KeyOnBtn2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,20,320,170,30,"Secondary key map");
    fl_set_button_shortcut(obj,"#e",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,Keymap,43);
  fl_end_group();

  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_Figure *create_form_Figure(void)
{
  FL_OBJECT *obj;
  FD_Figure *fdui = (FD_Figure *) fl_calloc(1, sizeof(*fdui));

  fdui->Figure = fl_bgn_form(FL_NO_BOX, 450, 540);
  obj = fl_add_box(FL_UP_BOX,0,0,450,540,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,360,250,130,"");
  fdui->Command = obj = fl_add_input(FL_NORMAL_INPUT,80,310,360,30,"Command:");
    fl_set_object_boxtype(obj,FL_SHADOW_BOX);
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,170,430,50,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,270,360,170,70,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,100,430,50,"");
  fdui->WidthLabel = obj = fl_add_text(FL_NORMAL_TEXT,20,90,50,20,"Width");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->EpsFile = obj = fl_add_input(FL_NORMAL_INPUT,70,50,260,30,"EPS file");
    fl_set_input_shortcut(obj,"#E",1);
    fl_set_object_lsize(obj,0);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,150,40,"EPS Figure");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->Preview = obj = fl_add_button(FL_NORMAL_BUTTON,270,450,170,30,"Full Screen Preview");
    fl_set_button_shortcut(obj,"#P",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,1);
  fdui->Browse = obj = fl_add_button(FL_NORMAL_BUTTON,350,50,90,30,"Browse...");
    fl_set_button_shortcut(obj,"#B",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,0);
  fdui->Width = obj = fl_add_input(FL_FLOAT_INPUT,340,110,90,30,"");
    fl_set_object_lsize(obj,0);
  fdui->Height = obj = fl_add_input(FL_FLOAT_INPUT,340,180,90,30,"");
    fl_set_object_lsize(obj,0);
  fdui->ApplyCmd = obj = fl_add_button(FL_NORMAL_BUTTON,270,270,170,30,"Update Command");
    fl_set_button_shortcut(obj,"#U",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,2);

  fdui->WidthGrp = fl_bgn_group();
  fdui->Default1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,110,80,30,"Default");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,10);
  fdui->cm1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,90,110,70,30,"cm");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,11);
  fdui->in1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,160,110,70,30,"inches");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,12);
  fdui->page1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,230,110,100,30,"% of Page");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,13);
  fl_end_group();

  fdui->Extra = obj = fl_add_input(FL_NORMAL_INPUT,130,230,310,30,"Extra Parameters:");
    fl_set_input_shortcut(obj,"#X",1);
    fl_set_object_lsize(obj,0);
  fdui->ApplyBtn = obj = fl_add_button(FL_NORMAL_BUTTON,200,500,110,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,7);
  fdui->OkBtn = obj = fl_add_button(FL_RETURN_BUTTON,70,500,110,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,8);
  fdui->CancelBtn = obj = fl_add_button(FL_NORMAL_BUTTON,330,500,110,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,9);
  fdui->Frame = obj = fl_add_checkbutton(FL_PUSH_BUTTON,270,370,170,30,"Display Frame");
    fl_set_button_shortcut(obj,"#F",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,53);
  fdui->Translations = obj = fl_add_checkbutton(FL_PUSH_BUTTON,270,400,170,30,"Do Translations");
    fl_set_button_shortcut(obj,"#T",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,54);
  obj = fl_add_text(FL_NORMAL_TEXT,20,350,60,20,"Display");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->HeightLabel = obj = fl_add_text(FL_NORMAL_TEXT,20,160,60,20,"Height");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,280,350,70,20,"Options");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->Angle = obj = fl_add_input(FL_FLOAT_INPUT,130,270,90,30,"Angle:");
    fl_set_input_shortcut(obj,"#L",1);
    fl_set_object_lsize(obj,0);

  fdui->Wysiwyg = fl_bgn_group();
  fdui->Wysiwyg3 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,430,240,30,"Display this figure in Color");
    fl_set_button_shortcut(obj,"#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,63);
  fdui->Wysiwyg0 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,460,240,30,"Do not display this figure");
    fl_set_button_shortcut(obj,"#D",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,3);
  fdui->Wysiwyg2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,400,240,30,"Display this figure Grayscale");
    fl_set_button_shortcut(obj,"#G",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,43);
  fdui->Wysiwyg1 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,370,240,30,"Display this figure Monochrome");
    fl_set_button_shortcut(obj,"#M",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,33);
  fl_end_group();


  fdui->HeightGrp = fl_bgn_group();
  fdui->page2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,230,180,100,30,"% of Page");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,23);
  fdui->Default2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,180,80,30,"Default");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,20);
  fdui->cm2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,90,180,70,30,"cm");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,21);
  fdui->in2 = obj = fl_add_checkbutton(FL_RADIO_BUTTON,160,180,70,30,"inches");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,EpsFig,22);
  fl_end_group();

  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_FileDlg *create_form_FileDlg(void)
{
  FL_OBJECT *obj;
  FD_FileDlg *fdui = (FD_FileDlg *) fl_calloc(1, sizeof(*fdui));

  fdui->FileDlg = fl_bgn_form(FL_NO_BOX, 440, 380);
  obj = fl_add_box(FL_UP_BOX,0,0,440,380,"");
  fdui->PatBox = obj = fl_add_input(FL_NORMAL_INPUT,80,40,350,30,"Pattern:");
    fl_set_input_shortcut(obj,"#P",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthWest, FL_NorthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
    fl_set_object_callback(obj,FileDlgCB,1);
  fdui->FileInfo = obj = fl_add_text(FL_NORMAL_TEXT,10,260,420,30,"");
    fl_set_object_boxtype(obj,FL_SHADOW_BOX);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_gravity(obj, FL_SouthWest, FL_SouthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
    fl_set_object_callback(obj,FileDlgCB,0);
  fdui->Filename = obj = fl_add_input(FL_NORMAL_INPUT,80,300,350,30,"Filename:");
    fl_set_input_shortcut(obj,"#F",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthWest, FL_SouthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
    fl_set_object_callback(obj,FileDlgCB,3);
  fdui->Rescan = obj = fl_add_button(FL_NORMAL_BUTTON,340,80,90,30,"Rescan");
    fl_set_button_shortcut(obj,"#R#r",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthEast, FL_NorthEast);
    fl_set_object_callback(obj,FileDlgCB,10);
  fdui->Home = obj = fl_add_button(FL_NORMAL_BUTTON,340,120,90,30,"Home");
    fl_set_button_shortcut(obj,"#H#h",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthEast, FL_NorthEast);
    fl_set_object_callback(obj,FileDlgCB,11);
  fdui->List = obj = fl_add_browser(FL_HOLD_BROWSER,10,80,320,170,"");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_TOP);
    fl_set_object_gravity(obj, FL_NorthWest, FL_SouthEast);
  fdui->Cancel = obj = fl_add_button(FL_NORMAL_BUTTON,330,340,100,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
  fdui->User2 = obj = fl_add_button(FL_NORMAL_BUTTON,340,200,90,30,"User2");
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthEast, FL_NorthEast);
    fl_set_object_callback(obj,FileDlgCB,13);
  fdui->User1 = obj = fl_add_button(FL_NORMAL_BUTTON,340,160,90,30,"User1");
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthEast, FL_NorthEast);
    fl_set_object_callback(obj,FileDlgCB,12);
  fdui->Ready = obj = fl_add_button(FL_RETURN_BUTTON,210,340,100,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
  fdui->DirBox = obj = fl_add_input(FL_NORMAL_INPUT,80,10,350,30,"Directory:");
    fl_set_input_shortcut(obj,"#D",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthWest, FL_NorthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
    fl_set_object_callback(obj,FileDlgCB,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_table *create_form_form_table(void)
{
  FL_OBJECT *obj;
  FD_form_table *fdui = (FD_form_table *) fl_calloc(1, sizeof(*fdui));

  fdui->form_table = fl_bgn_form(FL_NO_BOX, 300, 160);
  obj = fl_add_box(FL_UP_BOX,0,0,300,160,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,170,40,"Insert Table");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->slider_columns = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,80,80,200,30,"Columns");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->slider_rows = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,80,50,200,30,"Rows");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->button_ok = obj = fl_add_button(FL_RETURN_BUTTON,10,120,86,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,TableOKCB,0);
  fdui->button_apply = obj = fl_add_button(FL_NORMAL_BUTTON,106,120,86,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,TableApplyCB,0);
  fdui->button_cancel = obj = fl_add_button(FL_NORMAL_BUTTON,204,120,86,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,TableCancelCB,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_search *create_form_form_search(void)
{
  FL_OBJECT *obj;
  FD_form_search *fdui = (FD_form_search *) fl_calloc(1, sizeof(*fdui));

  fdui->form_search = fl_bgn_form(FL_NO_BOX, 290, 120);
  obj = fl_add_box(FL_UP_BOX,0,0,290,120,"");
  fdui->input_search = obj = fl_add_input(FL_NORMAL_INPUT,100,10,180,30,"Find");
    fl_set_input_shortcut(obj,"#n",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_NorthWest, FL_NorthEast);
    fl_set_object_resize(obj, FL_RESIZE_X);
  fdui->input_replace = obj = fl_add_input(FL_NORMAL_INPUT,100,40,180,30,"Replace with");
    fl_set_input_shortcut(obj,"#W",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_West, FL_East);
    fl_set_object_resize(obj, FL_RESIZE_X);
  obj = fl_add_button(FL_NORMAL_BUTTON,227,80,53,30,"@>");
    fl_set_button_shortcut(obj,"#F",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SearchForwardCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,100,80,53,30,"@<");
    fl_set_button_shortcut(obj,"#B",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SearchBackwardCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,153,80,74,30,"Replace");
    fl_set_button_shortcut(obj,"#R#r",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SearchReplaceCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,10,80,80,30,"Close");
    fl_set_button_shortcut(obj,"#C^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthWest, FL_SouthWest);
    fl_set_object_callback(obj,SearchCancelCB,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

