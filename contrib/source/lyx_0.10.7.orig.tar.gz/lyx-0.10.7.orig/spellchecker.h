// -*- C++ -*-
#ifndef _SPELLCHECKER_H
#define _SPELLCHECKER_H

/* these functions are defined in lyx_cb.C */


char* NextWord(float &value);		       /* the returned word has 
					* to be deleted
					* manually*/


/* MarkLastWord should only be used immidiately after NextWord().
 * If you give control back to the user, you _have_ to call EndOfSpellCheck()
 * or SelectLastWord(), otherwise segfaults should appear.
 */
void EndOfSpellCheck();
void SelectLastWord();

void ReplaceWord(const char* replacestringstring);



/* this function has to be implented by the spell checker.
 * It will show the spellcheker form*/ 
void ShowSpellChecker();
void SpellCheckerOptions(void);

#endif
