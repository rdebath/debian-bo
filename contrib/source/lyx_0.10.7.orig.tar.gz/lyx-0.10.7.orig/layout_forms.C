/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "layout_forms.h"

FD_form_document *create_form_form_document(void)
{
  FL_OBJECT *obj;
  FD_form_document *fdui = (FD_form_document *) fl_calloc(1, sizeof(*fdui));

  fdui->form_document = fl_bgn_form(FL_NO_BOX, 510, 460);
  obj = fl_add_box(FL_UP_BOX,0,0,510,460,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,260,40,"Document Layout");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->choice_class = obj = fl_add_choice(FL_NORMAL_CHOICE,100,60,130,30,"Class:");
    fl_set_object_shortcut(obj,"#C",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,ChoiceClassCB,0);
  fdui->choice_pagestyle = obj = fl_add_choice(FL_NORMAL_CHOICE,100,90,130,30,"Pagestyle:");
    fl_set_object_shortcut(obj,"#P",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_fonts = obj = fl_add_choice(FL_NORMAL_CHOICE,100,130,130,30,"Fonts:");
    fl_set_object_shortcut(obj,"#F",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_fontsize = obj = fl_add_choice(FL_NORMAL_CHOICE,100,160,130,30,"Font Size:");
    fl_set_object_shortcut(obj,"#S",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_papersize = obj = fl_add_choice(FL_NORMAL_CHOICE,100,230,130,30,"Papersize:");
    fl_set_object_shortcut(obj,"#Z",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,390,420,110,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,DocumentCancelCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,260,420,110,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,DocumentApplyCB,0);
  obj = fl_add_button(FL_RETURN_BUTTON,130,420,110,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,DocumentOKCB,0);
  fdui->input_float_placement = obj = fl_add_input(FL_NORMAL_INPUT,350,260,150,30,"Float Placement:");
    fl_set_input_shortcut(obj,"#O",1);
    fl_set_object_lsize(obj,0);
  fdui->choice_epsfig = obj = fl_add_choice(FL_NORMAL_CHOICE,100,270,130,30,"Epsfig Driver:");
    fl_set_object_shortcut(obj,"#D",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_inputenc = obj = fl_add_choice(FL_NORMAL_CHOICE,100,300,130,30,"Encoding:");
    fl_set_object_shortcut(obj,"#E",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->slider_baselinestretch = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,140,350,360,20,"Baselinestretch");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->slider_secnumdepth = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,140,370,360,20,"Sec. Num. Depth");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->slider_tocdepth = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,140,390,360,20,"Toc. Depth");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,250,150,120,70,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,390,150,110,70,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,250,60,120,70,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,390,60,110,70,"");
    fl_set_object_lsize(obj,0);

  fdui->group_radio_sides = fl_bgn_group();
  fdui->radio_sides_one = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,70,120,30,"One");
    fl_set_object_lsize(obj,0);
  fdui->radio_sides_two = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,100,120,30,"Two");
    fl_set_object_lsize(obj,0);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,260,140,90,20,"Orientation");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,400,140,90,20,"Separation");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,260,50,50,20,"Sides");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);

  fdui->greoup_radio_orientation = fl_bgn_group();
  fdui->radio_portrait = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,160,120,30,"Portrait");
    fl_set_button_shortcut(obj,"#R",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_landscape = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,190,120,30,"Landscape");
    fl_set_button_shortcut(obj,"#L",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,400,50,70,20,"Columns");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);

  fdui->group_radio_columns = fl_bgn_group();
  fdui->radio_columns_one = obj = fl_add_checkbutton(FL_RADIO_BUTTON,390,70,110,30,"One");
    fl_set_object_lsize(obj,0);
  fdui->radio_columns_two = obj = fl_add_checkbutton(FL_RADIO_BUTTON,390,100,110,30,"Two");
    fl_set_object_lsize(obj,0);
  fl_end_group();


  fdui->group_radio_separation = fl_bgn_group();
  fdui->radio_indent = obj = fl_add_checkbutton(FL_RADIO_BUTTON,390,160,110,30,"Indent");
    fl_set_button_shortcut(obj,"#I",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_skip = obj = fl_add_checkbutton(FL_RADIO_BUTTON,390,190,110,30,"Skip");
    fl_set_button_shortcut(obj,"#K",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  fdui->input_extra = obj = fl_add_input(FL_NORMAL_INPUT,350,300,150,30,"Extra Options:");
    fl_set_input_shortcut(obj,"#X",1);
    fl_set_object_lsize(obj,0);
  fdui->choice_language = obj = fl_add_box(FL_FRAME_BOX,100,195,130,30,"Language:");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_character *create_form_form_character(void)
{
  FL_OBJECT *obj;
  FD_form_character *fdui = (FD_form_character *) fl_calloc(1, sizeof(*fdui));

  fdui->form_character = fl_bgn_form(FL_NO_BOX, 250, 310);
  obj = fl_add_box(FL_UP_BOX,0,0,250,310,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,210,40,"Character Layout");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->choice_family = obj = fl_add_choice(FL_NORMAL_CHOICE,70,60,160,30,"Family:");
    fl_set_object_shortcut(obj,"#F",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_series = obj = fl_add_choice(FL_NORMAL_CHOICE,70,100,160,30,"Series:");
    fl_set_object_shortcut(obj,"#S",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_shape = obj = fl_add_choice(FL_NORMAL_CHOICE,70,140,160,30,"Shape:");
    fl_set_object_shortcut(obj,"#H",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_size = obj = fl_add_choice(FL_NORMAL_CHOICE,70,180,160,30,"Size:");
    fl_set_object_shortcut(obj,"#Z",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->choice_bar = obj = fl_add_choice(FL_NORMAL_CHOICE,70,220,160,30,"Bar:");
    fl_set_object_shortcut(obj,"#B",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);
  fdui->button_ok = obj = fl_add_button(FL_RETURN_BUTTON,10,270,64,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,CharacterOKCB,0);
  fdui->button_apply = obj = fl_add_button(FL_NORMAL_BUTTON,88,270,64,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,CharacterApplyCB,0);
  fdui->button_cancel = obj = fl_add_button(FL_NORMAL_BUTTON,166,270,64,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,CharacterCancelCB,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_paragraph *create_form_form_paragraph(void)
{
  FL_OBJECT *obj;
  FD_form_paragraph *fdui = (FD_form_paragraph *) fl_calloc(1, sizeof(*fdui));

  fdui->form_paragraph = fl_bgn_form(FL_NO_BOX, 460, 340);
  obj = fl_add_box(FL_UP_BOX,0,0,460,340,"");
  fdui->button_ok = obj = fl_add_button(FL_RETURN_BUTTON,80,300,110,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,ParagraphOKCB,0);
  fdui->button_apply = obj = fl_add_button(FL_NORMAL_BUTTON,210,300,110,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,ParagraphApplyCB,0);
  fdui->button_cancel = obj = fl_add_button(FL_NORMAL_BUTTON,340,300,110,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,ParagraphCancelCB,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,340,230,110,50,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,120,320,90,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,340,120,110,90,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,340,30,110,70,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,180,30,150,70,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,150,40,"Paragraph");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,30,50,100,40,"Layout");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,20,110,120,20,"Vertical Spaces");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->input_labelwidth = obj = fl_add_input(FL_NORMAL_INPUT,100,240,210,30,"Label Width");
    fl_set_object_lsize(obj,0);
  obj = fl_add_text(FL_NORMAL_TEXT,190,20,80,20,"Alignment");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,350,110,90,20,"Pagebreaks");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,350,20,50,20,"Lines");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,350,220,60,20,"Indent");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  fdui->check_lines_top = obj = fl_add_checkbutton(FL_PUSH_BUTTON,340,40,110,30,"Above");
    fl_set_button_shortcut(obj,"#O",1);
    fl_set_object_lsize(obj,0);
  fdui->check_lines_bottom = obj = fl_add_checkbutton(FL_PUSH_BUTTON,340,70,110,30,"Below");
    fl_set_button_shortcut(obj,"#E",1);
    fl_set_object_lsize(obj,0);
  fdui->check_pagebreaks_top = obj = fl_add_checkbutton(FL_PUSH_BUTTON,340,135,110,30,"Above");
    fl_set_button_shortcut(obj,"#V",1);
    fl_set_object_lsize(obj,0);
  fdui->check_pagebreaks_bottom = obj = fl_add_checkbutton(FL_PUSH_BUTTON,340,170,110,30,"Below");
    fl_set_button_shortcut(obj,"#W",1);
    fl_set_object_lsize(obj,0);
  fdui->check_noindent = obj = fl_add_checkbutton(FL_PUSH_BUTTON,340,240,110,30,"No Indent");
    fl_set_button_shortcut(obj,"#N",1);
    fl_set_object_lsize(obj,0);

  fdui->group_radio_alignment = fl_bgn_group();
  fdui->radio_align_right = obj = fl_add_checkbutton(FL_RADIO_BUTTON,180,40,70,30,"Right");
    fl_set_button_shortcut(obj,"#R",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_align_left = obj = fl_add_checkbutton(FL_RADIO_BUTTON,180,70,70,30,"Left");
    fl_set_button_shortcut(obj,"#L",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_align_block = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,40,80,30,"Block");
    fl_set_button_shortcut(obj,"#B",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_align_center = obj = fl_add_checkbutton(FL_RADIO_BUTTON,250,70,80,30,"Center");
    fl_set_button_shortcut(obj,"#C",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  fdui->slider_spaces_top = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,70,140,200,20,"Above");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
    fl_set_slider_value(obj, 0.51);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->slider_spaces_bottom = obj = fl_add_valslider(FL_HOR_NICE_SLIDER,70,175,200,20,"Below");
    fl_set_object_boxtype(obj,FL_FLAT_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  fdui->check_fill_top = obj = fl_add_checkbutton(FL_PUSH_BUTTON,270,135,50,30,"Fill");
    fl_set_button_shortcut(obj,"#F",1);
    fl_set_object_lsize(obj,0);
  fdui->check_fill_bottom = obj = fl_add_checkbutton(FL_PUSH_BUTTON,270,170,50,30,"Fill");
    fl_set_button_shortcut(obj,"#I",1);
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,230,320,50,"");
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_preamble *create_form_form_preamble(void)
{
  FL_OBJECT *obj;
  FD_form_preamble *fdui = (FD_form_preamble *) fl_calloc(1, sizeof(*fdui));

  fdui->form_preamble = fl_bgn_form(FL_NO_BOX, 380, 420);
  obj = fl_add_box(FL_UP_BOX,0,0,380,420,"");
  fdui->button_ok = obj = fl_add_button(FL_NORMAL_BUTTON,20,380,110,30,"OK");
    fl_set_button_shortcut(obj,"#O#o",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,PreambleOKCB,0);
  fdui->button_apply = obj = fl_add_button(FL_NORMAL_BUTTON,140,380,110,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,PreambleApplyCB,0);
  fdui->button_cancel = obj = fl_add_button(FL_NORMAL_BUTTON,260,380,110,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,PreambleCancelCB,0);
  fdui->input_preamble = obj = fl_add_input(FL_MULTILINE_INPUT,20,60,350,300,"");
    fl_set_object_lsize(obj,FL_NORMAL_SIZE);
    fl_set_object_gravity(obj, FL_NorthWest, FL_SouthEast);
  obj = fl_add_text(FL_NORMAL_TEXT,20,10,120,40,"Preamble");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
    fl_set_object_gravity(obj, FL_NorthWest, FL_NorthWest);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_quotes *create_form_form_quotes(void)
{
  FL_OBJECT *obj;
  FD_form_quotes *fdui = (FD_form_quotes *) fl_calloc(1, sizeof(*fdui));

  fdui->form_quotes = fl_bgn_form(FL_NO_BOX, 330, 200);
  obj = fl_add_box(FL_UP_BOX,0,0,330,200,"");
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,90,40,"Quotes");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_CENTER|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  obj = fl_add_button(FL_RETURN_BUTTON,10,160,90,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,QuotesOKCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,120,160,90,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,QuotesApplyCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,230,160,90,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,QuotesCancelCB,0);
  fdui->choice_quotes_language = obj = fl_add_choice(FL_NORMAL_CHOICE,90,60,160,30,"Type:");
    fl_set_object_shortcut(obj,"#T",1);
    fl_set_object_boxtype(obj,FL_FRAME_BOX);
    fl_set_object_lsize(obj,0);

  fdui->group_radio_quotes_number = fl_bgn_group();
  fdui->radio_single = obj = fl_add_checkbutton(FL_RADIO_BUTTON,90,110,80,30,"Single");
    fl_set_button_shortcut(obj,"#S",1);
    fl_set_object_lsize(obj,0);
  fdui->radio_double = obj = fl_add_checkbutton(FL_RADIO_BUTTON,170,110,80,30,"Double");
    fl_set_button_shortcut(obj,"#D",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  obj = fl_add_text(FL_NORMAL_TEXT,290,230,10,10,"Text");
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

