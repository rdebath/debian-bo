#ifndef FD_LaTeXOptions_h_
#define FD_LaTeXOptions_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void LaTeXOptionsOK(FL_OBJECT *, long);
extern void LaTeXOptionsApply(FL_OBJECT *, long);
extern void LaTeXOptionsCancel(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *LaTeXOptions;
	FL_OBJECT *accents;
	void *vdata;
	long ldata;
} FD_LaTeXOptions;

extern FD_LaTeXOptions * create_form_LaTeXOptions(void);

#endif /* FD_LaTeXOptions_h_ */
