// -*- C++ -*-
#ifndef _LYX_CB_H
#define _LYX_CB_H

#include "forms.h"
#include "file.h"

extern bool quitting;
extern char * system_lyxdir;
extern char * system_tempdir;

// When still False after reading lyxrc, warn user
//about failing \bind_file command. RVDK_PATCH_5
extern bool BindFileSet;

extern void FootCB(FL_OBJECT *, long);
extern void EmphCB(FL_OBJECT *, long);
extern void BoldCB(FL_OBJECT *, long);
extern void NounCB(FL_OBJECT *, long);
extern void MarginCB(FL_OBJECT *, long);
extern void FigureCB(FL_OBJECT *, long);
extern void TableCB(FL_OBJECT *, long);
extern void CutCB(FL_OBJECT *, long);
extern void PasteCB(FL_OBJECT *, long);
extern void MeltCB(FL_OBJECT *, long);
extern void TexCB(FL_OBJECT *, long);
extern void FormulaCB(FL_OBJECT *, long);
extern void DepthCB(FL_OBJECT *, long);
extern void FreeCB(FL_OBJECT *, long);

extern void FootCB(FL_OBJECT *, long);
extern void EmphCB(FL_OBJECT *, long);
extern void BoldCB(FL_OBJECT *, long);
extern void NounCB(FL_OBJECT *, long);
extern void MarginCB(FL_OBJECT *, long);
extern void FigureCB(FL_OBJECT *, long);
extern void TableCB(FL_OBJECT *, long);
extern void CutCB();
extern void PasteCB();
extern void MeltCB(FL_OBJECT *, long);
extern void TexCB(FL_OBJECT *, long);
extern void FormulaCB(FL_OBJECT *, long);
extern void DepthCB(FL_OBJECT *, long);
extern void FreeCB(FL_OBJECT *, long);
extern void CopyCB();
extern void NoteCB();
extern void HtmlUrlCB();
extern void UrlCB();
extern void ProhibitInput();

extern void AllowInput();
extern const char *getFileFromDir(char*, char*, char*, char*);

#endif


