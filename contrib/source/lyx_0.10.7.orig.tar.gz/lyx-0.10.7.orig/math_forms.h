#ifndef FD_panel_h_
#define FD_panel_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void button_cb(FL_OBJECT *, long);

extern void delim_cb(FL_OBJECT *, long);

extern void matrix_cb(FL_OBJECT *, long);

extern void deco_cb(FL_OBJECT *, long);

extern void space_cb(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *panel;
	FL_OBJECT *greek;
	FL_OBJECT *arrow;
	FL_OBJECT *boperator;
	FL_OBJECT *brelats;
	FL_OBJECT *varsize;
	FL_OBJECT *misc;
	FL_OBJECT *equation;
	FL_OBJECT *sqrt;
	FL_OBJECT *frac;
	FL_OBJECT *delim;
	FL_OBJECT *matrix;
	FL_OBJECT *deco;
	FL_OBJECT *space;
	void *vdata;
	long ldata;
} FD_panel;

extern FD_panel * create_form_panel(void);
typedef struct {
	FL_FORM *delim;
	FL_OBJECT *menu;
	FL_OBJECT *lado;
	FL_OBJECT *right;
	FL_OBJECT *left;
	FL_OBJECT *pix;
	void *vdata;
	long ldata;
} FD_delim;

extern FD_delim * create_form_delim(void);
typedef struct {
	FL_FORM *matrix;
	FL_OBJECT *rows;
	FL_OBJECT *columns;
	FL_OBJECT *valign;
	FL_OBJECT *halign;
	void *vdata;
	long ldata;
} FD_matrix;

extern FD_matrix * create_form_matrix(void);
typedef struct {
	FL_FORM *deco;
	FL_OBJECT *menu;
	void *vdata;
	long ldata;
} FD_deco;

extern FD_deco * create_form_deco(void);
typedef struct {
	FL_FORM *space;
	FL_OBJECT *spaces;
	void *vdata;
	long ldata;
} FD_space;

extern FD_space * create_form_space(void);

#endif /* FD_panel_h_ */
