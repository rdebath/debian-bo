/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "latex.h"

FD_LaTeXOptions *create_form_LaTeXOptions(void)
{
  FL_OBJECT *obj;
  FD_LaTeXOptions *fdui = (FD_LaTeXOptions *) fl_calloc(1, sizeof(*fdui));

  fdui->LaTeXOptions = fl_bgn_form(FL_NO_BOX, 330, 170);
  obj = fl_add_box(FL_UP_BOX,0,0,330,170,"");
  obj = fl_add_frame(FL_NO_FRAME,10,10,190,40,"LaTeX Options");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->accents = obj = fl_add_checkbutton(FL_PUSH_BUTTON,260,70,40,40,"Allow accents on ALL characters");
    fl_set_button_shortcut(obj,"#w",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
  obj = fl_add_button(FL_RETURN_BUTTON,10,130,90,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,LaTeXOptionsOK,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,120,130,90,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,LaTeXOptionsApply,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,230,130,90,30,"Cancel");
    fl_set_button_shortcut(obj,"^[",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_callback(obj,LaTeXOptionsCancel,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

