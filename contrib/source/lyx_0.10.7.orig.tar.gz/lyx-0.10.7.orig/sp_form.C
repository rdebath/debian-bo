/* Form definition file generated with fdesign. */

#include "forms.h"
#include <stdlib.h>
#include "sp_form.h"

FD_form_spell_options *create_form_form_spell_options(void)
{
  FL_OBJECT *obj;
  FD_form_spell_options *fdui = (FD_form_spell_options *) fl_calloc(1, sizeof(*fdui));

  fdui->form_spell_options = fl_bgn_form(FL_NO_BOX, 360, 440);
  obj = fl_add_box(FL_UP_BOX,0,0,360,440,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,60,340,110,"");
  obj = fl_add_frame(FL_ENGRAVED_FRAME,10,190,340,200,"");

  fdui->lang_buts = fl_bgn_group();
  fdui->buflang = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,70,350,30,"Use language of document for dictionary");
    fl_set_button_shortcut(obj,"#D",1);
    fl_set_object_lsize(obj,0);
  fdui->altlang = obj = fl_add_checkbutton(FL_RADIO_BUTTON,10,100,350,30,"Use alternate language for dictionary:");
    fl_set_button_shortcut(obj,"#U",1);
    fl_set_object_lsize(obj,0);
  fl_end_group();

  fdui->altlang_input = obj = fl_add_input(FL_NORMAL_INPUT,50,130,230,30,"");
    fl_set_object_lsize(obj,0);
  fdui->compounds = obj = fl_add_checkbutton(FL_PUSH_BUTTON,10,200,340,30,"Treat run-together words as legal");
    fl_set_button_shortcut(obj,"#T",1);
    fl_set_object_lsize(obj,0);
  fdui->rootaffix = obj = fl_add_checkbutton(FL_PUSH_BUTTON,10,230,340,30,"Suggest words made from root/affix combinations");
    fl_set_button_shortcut(obj,"#S",1);
    fl_set_object_lsize(obj,0);
  fdui->ok = obj = fl_add_button(FL_RETURN_BUTTON,10,400,100,30,"OK");
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SpellOptionsOKCB,0);
  obj = fl_add_button(FL_NORMAL_BUTTON,250,400,100,30,"Cancel");
    fl_set_button_shortcut(obj,"^[#C",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SpellOptionsCancelCB,0);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,280,40,"Options for spellchecker");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->perdict = obj = fl_add_checkbutton(FL_PUSH_BUTTON,10,260,340,30,"Use alternate personal dictionary:");
    fl_set_button_shortcut(obj,"#P",1);
    fl_set_object_lsize(obj,0);
  fdui->esc_chars = obj = fl_add_checkbutton(FL_PUSH_BUTTON,10,320,340,30,"Additional characters that can be part of a word:");
    fl_set_button_shortcut(obj,"#D",1);
    fl_set_object_lsize(obj,0);
  fdui->perdict_input = obj = fl_add_input(FL_NORMAL_INPUT,50,290,230,30,"");
    fl_set_object_lsize(obj,0);
  fdui->esc_chars_input = obj = fl_add_input(FL_NORMAL_INPUT,50,350,230,30,"");
    fl_set_object_lsize(obj,0);
  obj = fl_add_text(FL_NORMAL_TEXT,20,50,80,20,"Dictionary");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_text(FL_NORMAL_TEXT,30,180,70,20,"Options");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_BOLD_STYLE);
  obj = fl_add_button(FL_NORMAL_BUTTON,130,400,100,30,"Apply");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
    fl_set_object_gravity(obj, FL_SouthEast, FL_SouthEast);
    fl_set_object_callback(obj,SpellOptionsApplyCB,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

FD_form_spell_check *create_form_form_spell_check(void)
{
  FL_OBJECT *obj;
  FD_form_spell_check *fdui = (FD_form_spell_check *) fl_calloc(1, sizeof(*fdui));

  fdui->form_spell_check = fl_bgn_form(FL_NO_BOX, 640, 370);
  obj = fl_add_box(FL_UP_BOX,0,0,640,370,"");
    fl_set_object_lsize(obj,0);
  fdui->text = obj = fl_add_text(FL_NORMAL_TEXT,70,60,330,30,"");
    fl_set_object_boxtype(obj,FL_DOWN_BOX);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
  obj = fl_add_text(FL_NORMAL_TEXT,10,10,370,40,"Spellchecker");
    fl_set_object_lsize(obj,FL_LARGE_SIZE);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT|FL_ALIGN_INSIDE);
    fl_set_object_lstyle(obj,FL_ITALIC_STYLE+FL_ENGRAVED_STYLE);
  fdui->input = obj = fl_add_input(FL_NORMAL_INPUT,70,110,330,30,"Replace");
    fl_set_object_lsize(obj,0);
  fdui->browser = obj = fl_add_browser(FL_SELECT_BROWSER,70,150,330,150,"Near\nMisses");
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
  fdui->options = obj = fl_add_button(FL_NORMAL_BUTTON,430,280,200,30,"Spellchecker Options...");
    fl_set_button_shortcut(obj,"#O",1);
    fl_set_object_lsize(obj,0);
  fdui->start = obj = fl_add_button(FL_NORMAL_BUTTON,430,60,200,30,"Start spellchecking");
    fl_set_button_shortcut(obj,"#S",1);
    fl_set_object_lsize(obj,0);
  fdui->insert = obj = fl_add_button(FL_NORMAL_BUTTON,430,100,200,30,"Insert in personal dictionary");
    fl_set_button_shortcut(obj,"#I",1);
    fl_set_object_lsize(obj,0);
  fdui->ignore = obj = fl_add_button(FL_NORMAL_BUTTON,430,160,200,30,"Ignore word");
    fl_set_button_shortcut(obj,"#g",1);
    fl_set_object_lsize(obj,0);
  fdui->accept = obj = fl_add_button(FL_NORMAL_BUTTON,430,130,200,30,"Accept word in this session");
    fl_set_button_shortcut(obj,"#A",1);
    fl_set_object_lsize(obj,0);
  fdui->stop = obj = fl_add_button(FL_NORMAL_BUTTON,430,230,200,30,"Stop spellchecking");
    fl_set_button_shortcut(obj,"#T",1);
    fl_set_object_lsize(obj,0);
  fdui->done = obj = fl_add_button(FL_NORMAL_BUTTON,430,320,200,30,"Close Spellchecker");
    fl_set_button_shortcut(obj,"#C^[",1);
    fl_set_object_lsize(obj,0);
  fdui->slider = obj = fl_add_slider(FL_HOR_FILL_SLIDER,10,320,390,20,"");
    fl_set_object_color(obj,FL_BLUE,FL_COL1);
    fl_set_object_lsize(obj,0);
    fl_set_object_lalign(obj,FL_ALIGN_LEFT);
    fl_set_slider_value(obj, 0.00);
     fl_set_slider_return(obj, FL_RETURN_CHANGED);
  obj = fl_add_box(FL_NO_BOX,0,340,50,20,"0 %");
    fl_set_object_lsize(obj,0);
  obj = fl_add_box(FL_NO_BOX,370,340,50,20,"100 %");
    fl_set_object_lsize(obj,0);
  fdui->replace = obj = fl_add_button(FL_NORMAL_BUTTON,430,190,200,30,"Replace word");
    fl_set_button_shortcut(obj,"#R",1);
    fl_set_object_lsize(obj,0);
  fl_end_form();

  return fdui;
}
/*---------------------------------------*/

