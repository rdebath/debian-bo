#ifndef FD_form_credits_h_
#define FD_form_credits_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void CreditsOKCB(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *form_credits;
	FL_OBJECT *browser_credits;
	void *vdata;
	long ldata;
} FD_form_credits;

extern FD_form_credits * create_form_form_credits(void);

#endif /* FD_form_credits_h_ */
