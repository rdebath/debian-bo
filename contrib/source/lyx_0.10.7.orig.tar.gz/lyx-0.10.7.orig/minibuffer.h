// -*- C++ -*-
#ifndef _MINIBUFFER_H
#define _MINIBUFFER_H

#include "forms.h"

class MiniBuffer {
private:
	
	char text[200];
        char* text_stored;
	static void ExecutingCB(FL_OBJECT *ob, long);
	static void AbortingCB(FL_OBJECT *ob, long);
	static void bufferCB(FL_OBJECT *ob, long);
	static void TimerCB(FL_OBJECT *ob, long);
	FL_OBJECT *timer;
	FL_OBJECT *the_buffer;
	FL_OBJECT *execcommand;
	FL_OBJECT *abortcommand;
	char *cur_cmd;
public:
	bool shows_no_match;
	void setTimer(int a) {
		fl_set_timer(timer, a);
	}
	MiniBuffer() {
		sprintf(text,"Welcome to LyX!");
		shows_no_match = false;
		text_stored = NULL;
	}
	FL_OBJECT *add(int,  FL_Coord, FL_Coord,
		       FL_Coord, FL_Coord, const char *);
	void Set(const char *s1=NULL,
		 const char *s2=NULL,
		 const char *s3=NULL,
		 int delay_secs=4);  // RVDK_PATCH_5
	void Init();
	void ExecCommand();
       void Store(); // allows to store and reset the contents one time. Usefull for status messages like "load font" (Matthias)
       void Reset();
       void Activate();
       void Deactivate();
};

extern MiniBuffer minibuffer;

#endif


