
/* Define to work around a bug with const handling in gcc 2.7.[012] */
#undef BROKEN_CONST

/* Define on SunOS 4 and SCO, were some functions are missing from the headers */
#undef BROKEN_HEADERS

/* Define if you want debugging turned on as default. */
#undef DEBUG_AS_DEFAULT

/* Define if you are building a development version of LyX */
#undef DEVEL_VERSION

/* Define if the bool type is known to your compiler */
#undef HAVE_bool

/* You might want to define TWO_COLOR_ICONS if you want to spare
 your colormap.  This will use monochrome icons instead of colored
 ones. */
#undef TWO_COLOR_ICONS

/* define this if xpm.h is not in a directory in the form X11/xpm.h.*/
#undef XPM_H_WITHOUT_X11 

 
