// -*- C++ -*-
#ifndef LASTFILES_H
#define LASTFILES_H

class LastFiles 
{
	char *files[4];
	void ReadFile(const char*);
public:
	LastFiles(const char*);
	void newfile(const char*);
	void WriteFile(const char*);
	void MakeMenu(int);
	const char *GetFileName(int);
};

extern LastFiles *lastfiles;
#endif
