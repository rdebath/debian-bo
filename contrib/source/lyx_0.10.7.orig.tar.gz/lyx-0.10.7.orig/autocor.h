// -*- C++ -*-
/* This file is part of
* ======================================================
* 
*           LyX, the High Level Word Processor
* 	 
*	    Copyright (C) 1995 1996 Matthias Ettrich
*           and the LyX Team.
*
*======================================================*/

#ifndef _AUTOCOR_H
#define _AUTOCOR_H
#include "definitions.h"
#include "lyxparagraph.h"

// this functions returns a pointer to a corrected string 
// or NULL if no correction is possible

//const char* AutoCorrectString(const char* string);

// if AutoCorrect returns True, posend contains the new
// cursor position in this paragraph
bool  AutoCorrect(LyXParagraph* par, int &pos, int &posend);

#endif







