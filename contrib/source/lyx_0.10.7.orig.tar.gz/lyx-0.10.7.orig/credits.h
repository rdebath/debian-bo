// -*- C++ -*-
#ifndef _CREDITS_H
#define _CREDITS_H

void ShowCredits();

#endif
