#ifndef FD_form_print_h_
#define FD_form_print_h_
/* Header file generated with fdesign. */

/**** Callback routines ****/

extern void PrintOKCB(FL_OBJECT *, long);
extern void PrintApplyCB(FL_OBJECT *, long);
extern void PrintCancelCB(FL_OBJECT *, long);


/**** Forms and Objects ****/

typedef struct {
	FL_FORM *form_print;
	FL_OBJECT *input_printer;
	FL_OBJECT *input_file;
	FL_OBJECT *group_radio_printto;
	FL_OBJECT *radio_printer;
	FL_OBJECT *radio_file;
	FL_OBJECT *group_radio_pages;
	FL_OBJECT *radio_all_pages;
	FL_OBJECT *radio_odd_pages;
	FL_OBJECT *radio_even_pages;
	FL_OBJECT *group_radio_order;
	FL_OBJECT *radio_order_normal;
	FL_OBJECT *radio_order_reverse;
	void *vdata;
	long ldata;
} FD_form_print;

extern FD_form_print * create_form_form_print(void);

#endif /* FD_form_print_h_ */
