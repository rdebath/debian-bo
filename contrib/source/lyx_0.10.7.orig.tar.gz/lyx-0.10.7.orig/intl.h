// -*- C++ -*-
/* International support for LyX


*/
#ifndef _INTL_H
#define _INTL_H

#include "lyxtext.h"

#define DEFCHSET "iso8859-1"	// default character set

void MenuKeymap();
	/* show key mapping dialog */

void KeyMapOn(bool on);
void KeyMapPrim();
void KeyMapSec();
void ToggleKeyMap();
	/* turn on/off key mappings, status in keymapon */
void setPrimary(char*);
void setSecondary(char*);


void TranslateAndInsert(char c, LyXText *text);
	/* insert correct stuff into paragraph */

void InitKeyMapper();
	/* initialize key mapper */

#endif
