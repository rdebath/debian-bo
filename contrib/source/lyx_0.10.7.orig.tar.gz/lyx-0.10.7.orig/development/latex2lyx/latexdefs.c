/*----------------------------------------------------------------------------*/
/*      Terminal and Nonterminal names - to print trees and to help debuging  */
/*----------------------------------------------------------------------------*/

char 	*DocStyleName[] = {
    "article", "book", "report", "letter"};

char	*HeadingName[] = {
    "Part", "Chapter", "Section", "Subsection", "Subsubsection", 
    "Paragraph", "Subparagraph"};

char 	*FontShapeName[] = {
    "up", "typewriter", "smallcaps", "slant", "sans", "bold", 
    "roman", "italic", "up", "medium", "Cal"};

char 	*FontShapeMathName[] = {
    "\\em", "\\tt", "\\sc", "\\sl", "\\sf", "\\bf", "\\rm", "\\it", "\\up",
    "\\md", "\\cal"};

char	*FontSizeName[] = {
    "tiny", "scriptsize", "footnotesize", "small", "normalsize", 
    "large", "larger", "largest", "huge", "giant"};

char 	*EnvironmentName[] = {
    "Abstract", "{array}", "{center}", "Description", "{displaymath}", 
    "{document}", "Enumerate", "{eqnarray}", "{eqnarray*}", "{equation}", "fig",
    "{flushleft}", "{flushright}", "Itemize", "List", "{math}", "{minipage}",
    "{picture}", "Quotation", "Quote", "{sloppypar}", "{tabbing}", 
    "tab", "{tabular}", "{thebibliography}", "{theindex}", "{titlepage}",
    "{trivlist}", "{verbatin}", "Verse"}; 

char 	*MathGreekName[] = {
    "\\alpha", "\\beta", "\\gamma", "\\delta", "\\epsilon", "\\varepsilon", 
    "\\zeta", "\\eta", "\\theta", "\\vartheta", "\\iota", "\\kappa", "\\lambda",
    "\\mu", "\\nu", "\\xi", "\\pi", "\\varpi", "\\rho", "\\varrho", "\\sigma",
    "\\varsigma", "\\tau", "\\upsilon", "\\phi", "\\varphi", "\\chi", "\\psi",
    "\\omega", "\\Gamma", "\\Delta", "\\Theta", "\\Lambda", "\\Xi", "\\Pi", 
    "\\Sigma", "\\Upsilon", "\\Phi", "\\Psi", "\\Omega"};

char  	*MathSymbolName[] = {
    "\\ldots", "\\vdots", "\\cdots", "\\ddots", "\\pm", "\\mp", "\\times", 
    "\\div", "\\ast", "\\star", "\\circ", "\\bullet", "\\cdot",  "\\cap", 
    "\\cup", "\\uplus", "\\sqcap", "\\sqcup", "\\vee", "\\wedge", "\\setminus",
    "\\wr", "\\diamond", "\\bigtriangleup", "\\bigtriangledown", 
    "\\triangleleft", "\\triangleright", "\\lhd", "\\rhd", "\\unlhd", 
    "\\unrhd", "\\oplus", "\\ominus", "\\otimes", "\\oslash", "\\odot", 
    "\\bigcirc", "\\dagger", "\\ddagger", "\\amalg", "\\leq", "\\preq", 
    "\\preceq", "\\ll", "\\subset", "\\subseteq", "\\sqsubset", "\\sqsubseteq",
    "\\in", "\\vdash", "\\geq", "\\succ", "\\suceq", "\\gg", "\\supset", 
    "\\supseteq", "\\sqsupset", "\\sqsupseteq", "\\ni", "\\dashv", "\\equiv",
    "\\sim", "\\simeq", "\\asymp", "\\approx", "\\cong", "\\neq", "\\doteq",
    "\\propto", "\\models", "\\perp", "\\mid", "\\parallel", "\\bowtie", 
    "\\Join", "\\smile", "\\frown", "\\leftarrow", "\\Leftarrow", "\\rightarrow",
    "\\Rightarrow", "\\lefrighttarrow", "\\Lefrighttarrow", "\\longleftarrow", 
    "\\Longleftarrow", "\\longrightarrow", "\\Longrightarrow", 
    "\\longlefrighttarrow", "\\Longlefrighttarrow", "\\uparrow", "\\Uparrow",
    "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "\\nearrow",
    "\\searrow", "\\swarrow", "\\nwarrow", "\\mapsto", "\\longmapsto", 
    "\\leadsto", "\\hookleftarrow", "\\leftharpoonup", "\\rightharpoonup", 
    "\\leftharpoondown", "\\rightharpoondown", "\\rightleftharpoons", "\\aleph",
    "\\hbar", "\\imath", "\\jmath", "\\ell", "\\wp", "\\Re", "\\Im", "\\mho", 
    "\\prime", "\\emptyset", "\\nabla", "\\surd", "\\top", "\\bot", "\\|", 
    "\\angle", "\\forall", "\\exists", "\\neg", "\\flat", "\\natural", "\\sharp",
    "\\backslash", "\\partial", "\\infty", "\\Box", "\\Diamond", "\\triangle",
    "\\clubsuit", "\\diamondsuit", "\\heartsuit", "\\spadesuit", "\\sum", 
    "\\prod",  "\\coprod", "\\int", "\\oint", "\\bigcap", "\\bigcup", 
    "\\bigsqcup", "\\bigvee", "\\bigwedge", "\\bigdot", "\\bigotimes", 
    "\\bigoplus", "\\biguplus", "\\bmod", "\\arccos", "\\arcsin", "\\arctan", 
    "\\arg", "\\cos", "\\cosh", "\\cot", "\\coth", "\\csc", "\\deg", "\\det", 
    "\\dim", "\\exp", "\\gcd",  "\\hom", "\\inf", "\\ker", "\\lg", "\\lim", 
    "\\liminf", "\\limsup", "\\ln", "\\log", "\\max", "\\min", "\\Pr",
    "\\sec", "\\sin", "\\sinh", "\\tan", "\\tanh"};

char 	*MathDelimName[] = {
    "\\lfloor", "\\rfloor", "\\lceil", "\\rceli", "\\langle", "\\rangle", 
    "\\{", "\\}"};

char	*CommandName[] = {
    "", "documentstyle", "pagenumbering", "pagestyle", "maketitle", 
    "tableofcontents", "begin", "end", "item", "bibitem", "label", "ref", 
    "cite", "noindent", "input", "include", "includeonly", 
    "centerline", "mbox", "fbox", "framebox", "sbox", "savebox", "newsavebox",
    "usebox", "newpage", "clearpage", "samepage", "linebreak",
    "nolinebreak", "sloppy", "hline", "cline", "multicolumn", "caption", "kill",
    "vspace", "hspace", "vfill", "hfill", "put", "multiput", "makebox", "dashbox",
    "line", "vector", "shortstack", "circle", "oval", "frame", "thinlines", 
    "thicklines", "sqrt", "frac", "overline", "appendix", "=", ">",
    "pmod", "vec", "stacker", "centering", "lbracket", "rbracket", "lcurly", "rcurly",
    "word", "linefeed", "bibliographystyle", "newline", "smallspace", "today", 
    "footnote", "_", "^", "thinspace", "negspace", "mediumspace",
    "thickspace", "plus", "div", "equal", "math_begin", "math_end",
    "less", "more", "amper", "margin", "lparen", "rparen", "tilde", 
    "$", "backslash", "mathspace", "box", "textwidth", "bibliography", "linespacing",
    "pagebreak", "nopagebreak", "", "", "", "", "", "", "", "", "", "", "", "", "", 
    "pageref", "rule" };
