// -*- C++ -*-
#ifndef _DOCU_H
#define _DOCU_H

void MenuDocu();

#endif
