
#ifndef GIMP_STRETCH_H
#define GIMP_STRETCH_H

void RectStretch(
Image	input,	/* Source image	*/
Image	output,	/* Destination image	*/
	long		xs1,	/* xs1, ys1, - first point of source	*/
	long		ys1,
	long		xs2,	/* xs2, ys2, - second point of source	*/
	long		ys2,
	long		xd1,	/* xd1, yd1 - first point of destination */
	long		yd1,
	long		xd2,
	long		yd2
	);
	

void RectStretch(
Image	input,	/* Source image	*/
Image	output,	/* Destination image	*/
	long		xs1,	/* xs1, ys1, - first point of source	*/
	long		ys1,
	long		xs2,	/* xs2, ys2, - second point of source	*/
	long		ys2,
	long		xd1,	/* xd1, yd1 - first point of destination */
	long		yd1,
	long		xd2,
	long		yd2
	);
		
#endif



