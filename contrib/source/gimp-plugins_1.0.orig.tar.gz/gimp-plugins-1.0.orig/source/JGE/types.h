
#ifndef	PLUG_INS_TYPES_H
#define	PLUG_INS_TYPES_H

/*
 ************************************************************************
 *									*
 * Usefull? type definition stuff.					*
 *									*
 ************************************************************************
 */
 
 
/*
 *
 * Copyright (C) 1993/94/95/96 Jim Geuther
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *
 */
 
#ifndef	_H_TYPES
#include	<sys/types.h>
#endif

typedef int	return_code;

enum return_codes
{
        RETURN_OK=0,		
        RETURN_WARN=5,		/* Possible error			*/
        RETURN_ERROR=10,	/* Error				*/
        RETURN_FATAL=20,	/* Fatal error (nomem is not fatal!) 	*/
        RETURN_FAIL=20
};


struct gws_rgb
{
	u_char	r;
	u_char	g;
	u_char	b;
};


#ifndef	DEVTOOLS_DOSI2WORD_H
#define	DEVTOOLS_DOSI2WORD_H

/*
 * Wintel types
 *
 */

typedef short		MSWORD;	
typedef long int	MSDWORD;
typedef unsigned char	MSBYTE;	/* These must be declared as unsigned	*/
				/* otherwise you get palette color	*/
				/* differences				*/

#endif
 

#endif


