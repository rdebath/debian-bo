
/* colormap antique filter for the Gimp
 * Jim GEUTHER
 *
 * V1.00
 *
 * This filter creates an antiquess colormap.
 *
 */


#include "gimp.h"


static char *prog_name;
static long amount = 9;
static int dialog_ID;

static void anal(Image image);

int
main (argc, argv)
     int argc;
     char *argv[];
{
Image	input,output;
  /* Save the program name so we can use it later in reporting errors
   */
  prog_name = argv[0];

  /* Call 'gimp_init' to initialize this filter.
   * 'gimp_init' makes sure that the filter was properly called and
   *  it opens pipes for reading and writing.
   */
  if (gimp_init (argc, argv))
    {
	if(input=gimp_get_input_image(0)) {
		switch(gimp_image_type(input)) {
		case INDEXED_IMAGE :

			/* A new output image is created, to ensure the
			   image is displayed correctly. */
			if(output=gimp_new_image(0,gimp_image_width(input),
						gimp_image_height(input),
						INDEXED_IMAGE)) {
				req_antique(input,output);
				gimp_display_image(output);
				gimp_update_image(output);
				gimp_free_image(output);
			} else printf("%s: get output image failed\n",prog_name);
			break;
		default :
			gimp_message("cmapanal: can only operate on indexed color images");
			break;
		}
		gimp_free_image(input);
	}			
       /* Quit
       */
      gimp_quit ();
    }

  return 0;
}




