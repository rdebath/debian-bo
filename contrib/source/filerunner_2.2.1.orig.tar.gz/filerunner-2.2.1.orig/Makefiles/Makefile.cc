

# This makefile is for the cc compiler on Solaris 2.x.
# It has been tested under SunOS 5.5 and UnixWare.

# Change this if you have this stuff somewhere else.
TCLINC = /usr/local/lib/tcl7.6
TKINC  = /usr/local/lib/tk4.2
X11INC = /usr/openwin/include

#define this for the ustat() function:
DEFS = -DSVR4

CFLAGS = -v -KPIC -O $(DEFS) -I$(TCLINC) -I$(TKINC) -I$(X11INC)

CC = cc

all: ext.so

ext.so: ext.o
	cc -G -o ext.so ext.o

