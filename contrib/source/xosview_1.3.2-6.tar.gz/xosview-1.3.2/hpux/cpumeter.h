//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _CPUMETER_H_
#define _CPUMETER_H_

#include "fieldmeter.h"

class CPUMeter : public FieldMeter {
public:
  CPUMeter( XOSView *parent, int x, int y, int width, int height );
  ~CPUMeter( void );

  const char *name( void ) { return "CPUMeter"; }
  void checkevent( void );
protected:
  float cputime_[2][4];
  int cpuindex_;

  void getcputime( void );
private:
};

#endif
