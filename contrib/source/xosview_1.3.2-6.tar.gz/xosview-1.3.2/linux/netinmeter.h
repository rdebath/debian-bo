//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _NETINMETER_H_
#define _NETINMETER_H_

#include "fieldmeter.h"
#include "netmeter.h"

class NetInMeter : public FieldMeter, public NetMeter {
public:
  NetInMeter(XOSView *parent, int x, int y, int width, int height, float max);
  ~NetInMeter( void );

  const char *name( void ) { return "NetInMeter"; }  
  void checkevent( void );

  void checkResources( void );
protected:
  float maxpackets_;
private:
};

#endif
