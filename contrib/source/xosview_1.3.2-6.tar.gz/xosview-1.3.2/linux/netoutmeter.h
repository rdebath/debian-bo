//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _NETOUTMETER_H_
#define _NETOUTMETER_H_

#include "fieldmeter.h"
#include "netmeter.h"

class NetOutMeter : public FieldMeter, public NetMeter {
public:
  NetOutMeter(XOSView *parent, int x, int y, int width, int height, float max);
  ~NetOutMeter( void );

  const char *name( void ) { return "NetOutMeter"; }    
  void checkevent( void );

  void checkResources( void );
protected:
  float maxpackets_;
private:
};


#endif
