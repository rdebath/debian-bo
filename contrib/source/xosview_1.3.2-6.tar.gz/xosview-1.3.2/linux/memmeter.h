//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _MEMMETER_H_
#define _MEMMETER_H_

#include "fieldmeter.h"

class MemMeter : public FieldMeter {
public:
  MemMeter( XOSView *parent, int x, int y, int width, int height );
  ~MemMeter( void );

  const char *name( void ) { return "MemMeter"; }  
  void checkevent( void );

  void checkResources( void );
protected:

  void getmeminfo( void );
private:
};


#endif
