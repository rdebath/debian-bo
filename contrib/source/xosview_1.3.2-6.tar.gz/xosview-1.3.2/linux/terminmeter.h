//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _TERMINMETER_H_
#define _TERMINMETER_H_

#include "fieldmeter.h"
#include "termmeter.h"

class TermInMeter : public FieldMeter, public TermMeter {
public:
  TermInMeter(XOSView *parent, int x, int y, int width, int height, float max);
  ~TermInMeter( void );

  const char *name( void ) { return "TermInMeter"; }  
  void checkevent( void );
protected:
  float maxpackets_;
private:
};

#endif
