//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _SWAPMETER_H_
#define _SWAPMETER_H_


#include "fieldmeter.h"


class SwapMeter : public FieldMeter {
public:
  SwapMeter( XOSView *parent, int x, int y, int width, int height );
  ~SwapMeter( void );

  const char *name( void ) { return "SwapMeter"; }  
  void checkevent( void );

  void checkResources( void );
protected:

  void getswapinfo( void );
private:
};


#endif
