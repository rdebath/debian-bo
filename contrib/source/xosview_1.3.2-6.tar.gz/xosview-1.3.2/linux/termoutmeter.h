//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#ifndef _TERMOUTMETER_H_
#define _TERMOUTMETER_H_

#include "fieldmeter.h"
#include "termmeter.h"

class TermOutMeter : public FieldMeter, public TermMeter {
public:
  TermOutMeter(XOSView *parent, int x, int y, int width,
	       int height, float max);
  ~TermOutMeter( void );

  const char *name( void ) { return "TermOutMeter"; }    
  void checkevent( void );
protected:
  float maxpackets_;
private:
};


#endif
