//  
//  Copyright (c) 1994 by Mike Romberg (  romberg@md.fsl.noaa.gov )
//
//  This file may be distributed under terms of the GPL
//

#include "xosview.h"

main( int argc, char *argv[] )

{
  XOSView xosview( argc, argv );

  xosview.run();
}

