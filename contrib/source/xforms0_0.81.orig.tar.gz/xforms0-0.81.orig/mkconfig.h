# Linux

CC=gcc
CCFLAG=-O -fpic
LDFLAG=-O -s
AR=ar rs
RANLIB=touch
XINCLUDE=
SYSLIB=-L/usr/X11R6/lib -lX11 -lm

# where the library should be installed

LIB_DIR=/usr/lib
LIBMODE=644

HEADER_DIR=/usr/include
HEADERMODE=644

BIN_DIR=/usr/local/bin
BINMODE=711

MAN5_DIR=/usr/man/man5
MAN1_DIR=/usr/man/man1
DOC_DIR=/usr/local/lib
MANMODE=644
# name and header of the library
FORMLIB=libforms.a
FORMHEADER=forms.h

# make shared lib: $(MKSHLIB)
SHARED_LIB=libforms.so.0.81
SHARED_SO=libforms.so.0.81
SHARED_NAME=libforms.so

MKSHLIB=ld -shared -soname $(SHARED_SO) -o $(SHARED_LIB)\
     `ls *.o|grep -v gl.o` ulib/*.o ../xpm-3.4g/lib/libXpm.a

LN=ln -fs
