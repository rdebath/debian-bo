/* Header file generated with fdesign. */

/**** Callback routines ****/




/**** Forms and Objects ****/

extern FL_FORM *ttt;

extern FL_OBJECT
        *done,
        *load;



/**** Creation Routine ****/

extern void create_the_forms(void);
