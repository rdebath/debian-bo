/* include file to hook skyviewmenu.c and skyhist.c together.
 */


/* history record */
typedef struct {
    double fov;			/* sv_fov value */
    double azra;		/* sv_azra value */
    double altdec;		/* sv_altdec value */
    int aa_mode;		/* aa_mode value */
    int flip_lr, flip_tb;	/* flip values */
    int fmag, magstp;		/* magnitude settings */
    int justd, eclip, galac;	/* justdots, ecliptic and galactic options */
    int conn, conf, conb;	/* constellatin name, figures, boundaries opts*/
    int eyep;			/* eyepiece option */
    int magscale;		/* mag scale option */
    int grid;			/* grid option */
    int lbl_n, lbl_m;		/* name/mags label options */
    int lbl_a, lbl_b;		/* all/brightest label options */
    int lbl_f;			/* field-star label option */
    char type_table[NOBJTYPES];	/* copy of skyfilt's type table */
    char fclass_table[NCLASSES];/* copy of skyfilt's fclass table */
} SvHistory;


/* skyviewmenu.c */
extern void svh_goto P_((SvHistory *hp));
extern void svh_get P_((SvHistory *hp));


/* skyhist.c */
extern void svh_create P_((Widget mb));
