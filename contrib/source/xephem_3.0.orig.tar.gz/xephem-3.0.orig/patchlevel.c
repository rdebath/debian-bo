char PATCHLEVEL[] = "3.0";
char PATCHDATE[] = "9 February 1997";
