extern char PATCHLEVEL[];
extern char PATCHDATE[];
