/* include file to hook skyviewmenu.c and skylist.c together.
 * we are just trying this split to keep skyviewmenu.c from growing endlessly.
 */


/* Obj.flags or TSky flags values */
#define OBJF_ONSCREEN	FUSER0	/* bit set if obj is on screen */
#define OBJF_RLABEL	FUSER1	/* set if right-label is to be on */
#define OBJF_LLABEL	FUSER4	/* set if left-label is to be on */
#define OBJF_LABEL	(OBJF_RLABEL|OBJF_LLABEL) /* set if either-label is on*/


/* skyviewmenu.c */
extern void sv_getcenter P_((int *aamode, double *fov,
    double *altp, double *azp, double *rap, double *decp));
extern void sv_getfldstars P_((ObjF **fsp, int *nfsp));

/* skylist.c */
extern void sv_list_cb P_((Widget w, XtPointer client, XtPointer call));
extern void se_eyepd_cb P_((Widget w, XtPointer client, XtPointer call));
extern void se_eyepsz P_((double *wp, double *hp, int *rp));
extern int se_ismanaged P_((void));
extern void se_manage P_((void));
extern void se_unmanage P_((void));
