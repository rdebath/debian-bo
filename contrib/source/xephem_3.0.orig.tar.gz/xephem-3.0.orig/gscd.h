/* parameters that must be the same in the GSC server and all clients.
 */

#define	MAXFOV	(2*PI)	/* max FOV we can request */
#define	BMAG	(-30.)	/* brightest mag limit we can request */
#define	FMAG	(30.)	/* faintest mag limit we can request */
#define	GSCPORT	7577	/* tcp/ip port to use */
#define	SPKTSZ	11	/* bytes in a request packet sent to the GSC server */
#define	RPKTSZ	13	/* bytes in a star packet back from the GSC server */
