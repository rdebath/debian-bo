/*  $Id: INDEX.pl,v 1.8 1995/04/18 12:28:50 jan Exp $

    Creator: make/0

    Purpose: Provide index for autoload
*/

index((a), 0, a, a).
index((b), 0, b, b).
index((a), 0, a, c).
index((hello), 1, t, t).
index((test), 1, t2, t2).
