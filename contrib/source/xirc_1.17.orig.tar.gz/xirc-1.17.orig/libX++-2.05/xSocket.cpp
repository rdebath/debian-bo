/***************************************************************************
**    xSocket.cpp  $Revision: 1.17 $ - $Name: V2-05 $ 
**    Class to manipulate sockets
**
**    Copyright (C) 1996 Joseph Croft <jcroft@unicomp.net>
**
**    This library is free software; you can redistribute it and/or
**    modify it under the terms of the GNU Library General Public
**    License as published by the Free Software Foundation; either
**    version 2 of the License, or (at your option) any later version.
**
**    This library is distributed in the hope that it will be useful,
**    but WITHOUT ANY WARRANTY; without even the implied warranty of
**    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
**    Library General Public License for more details.
**
**    You should have received a copy of the GNU Library General Public
**    License along with this library; if not, write to the Free
**    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
**
 ***************************************************************************/
#include <unistd.h>
#include <fcntl.h>
#include <sys/time.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <signal.h>
#include <setjmp.h>
#include <qmsgbox.h>
#include "xSocket.h"

#ifndef INADDR_NONE
#define INADDR_NONE 0xffffffff
#endif

extern int errno;
extern char *sys_errlist[];

static int dbg = 0;

static const char *pInitialResources[] =
{
   "*ConnectTime: 60000",
   "*AcceptTime: 300000"
};

xSocketTCP::xSocketTCP(xWidgetResInfo *pPRes, QObject *pParent, const char *pHost, 
                       const char *pService, QObject *pSocketDialog, 
                       const char *pSlotStatus, const char *pSlotProgress, 
                       int &err) :
            QObject(NULL, NULL)
{
   struct servent *se = NULL;
   int port;
   int timeOut;
   const char *pTimeVal;

   if (dbg) fprintf(stdout, "xSocketTCP::xSocketTCP.connect():Enter\n");
   if (dbg) fflush(stdout);
   wdtRes = new xWidgetResInfo(pPRes, QString("tcpsocket"), 
                               QString("TCPSocket"));
   Resources->setWidgetInit(pInitialResources);
   err = 0;
   fd = -1;
//   dbf = fopen("qtTextOut.txt", "w");
   dbf = NULL;
   snw = NULL;
   snr = NULL;
   sna = NULL;
   snc = NULL;
   socketOff = FALSE;
   pTimer = new QTimer(this);

   if (dbg) fprintf(stdout, "xSocketTCP::xSocketTCP.connect():Getting service name\n");
   if (dbg) fflush(stdout);
   memset((void *)&connAddr, '\0', sizeof(connAddr));
   if ((se = getservbyname(pService, "tcp")) != NULL)
      port = se->s_port;
   else if ((port = htons((u_short)atoi(pService))) == 0)
   {
      err = xSocketTCP::ERROR_INVALIDSERVICE;
      return;
   }

   phe = NULL;
   if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():getting Host Entry\n");
   if (dbg) fflush(stdout);
   if ((phe = gethostbyname(pHost)) == NULL)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Maybe by Dotted Quad\n");
      if (dbg) fflush(stdout);
      if ((connAddr.sin_addr.s_addr = inet_addr(pHost)) == INADDR_NONE)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Must be INET address number\n");
         if (dbg) fflush(stdout);
         if ((connAddr.sin_addr.s_addr = atoi(pHost)) == 0)
         {
            err = xSocketTCP::ERROR_INVALIDHOST;
            return;
         }
      }
      if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Found Lone address: %d\n",
                               connAddr.sin_addr.s_addr);
      if (dbg) fflush(stdout);
   }
   else
   {
      if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Was a name after all!!!\n");
      if (dbg) fflush(stdout);
      bcopy(phe->h_addr, (char *)&connAddr.sin_addr, phe->h_length);
   }

   connAddr.sin_family = AF_INET;
   connAddr.sin_port = port;
   fd = socket(AF_INET, SOCK_STREAM, PF_UNSPEC);
   if (fd < 0)
   {
      err = xSocketTCP::ERROR_OPENINGSOCKET;
      return;
   }
   if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Socket Opened: %d\n", fd);
   if (dbg) fflush(stdout);
   snc = new QSocketNotifier(fd, QSocketNotifier::Write, this);
   QObject::connect(snc, SIGNAL(activated(int)), this, SLOT(retryConnect(int)));

   QObject::connect(this, SIGNAL(connecting(const char*)),
                    pSocketDialog, pSlotProgress);
   QObject::connect(this, SIGNAL(status(int)),
                    pParent, pSlotStatus);
   
   emit connecting(inet_ntoa(connAddr.sin_addr));

   if ((pTimeVal = Resources->get(wdtRes, "connecttime", "ConnectTime"))
       == NULL)
      timeOut = 60000;
   else
   {
      if ((timeOut = atol(pTimeVal)) == 0)
         timeOut = 60000;
   }
   QObject::connect(pTimer, SIGNAL(timeout()), this, SLOT(timeout()));
   pTimer->start(timeOut);
   if (dbg) fprintf(stdout, "xSocketTCP::connectTCP():Exit\n");
   if (dbg) fflush(stdout);
}   

xSocketTCP::xSocketTCP(xWidgetResInfo *pPRes, QObject *pParent,
                       const char *pService, 
                       const char *pSlotStatus,
                       int &err) :
            QObject(NULL, NULL)
{
   struct servent *se;
   int port, sock, rv = 0;
   char *cp;
   const char *pTimeVal;
   long timeOut;

   if (dbg) fprintf(stdout, "xSocketTCP::xSocketTCP.Accept():Enter\n");
   if (dbg) fflush(stdout);
   snw = NULL;
   snr = NULL;
   sna = NULL;
   snc = NULL;
   wdtRes = new xWidgetResInfo(pPRes, QString("tcpsocket"), 
                               QString("TCPSocket"));
   Resources->setWidgetInit(pInitialResources);
   err = 0;

   pTimer = new QTimer(this);
   if (dbg) fprintf(stdout, "xSocketTCP::accept():getting Service\n");
   if (dbg) fflush(stdout);
   if (pService == NULL)
      pService = "0";
   if ((se = getservbyname(pService, "tcp")) != NULL)
      port = se->s_port;
   else
      port = htons((u_short)atoi(pService));
   if (dbg) fprintf(stdout, "xSocketTCP::accept():got port %d\n", port);
   if (dbg) fflush(stdout);

   acceptAddr.sin_family = AF_INET;
   acceptAddr.sin_port = port;
   acceptAddr.sin_addr.s_addr = htonl(INADDR_ANY);
   
   cp = NULL;
   if (dbg) fprintf(stdout, "xSocketTCP::accept():Calling socket()\n");
   if (dbg) fflush(stdout);
   if ((sock = socket(AF_INET, SOCK_STREAM, PF_UNSPEC)) >= 0)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::accept():Socket Opened: %d\n", sock);
      if (dbg) fprintf(stdout, "xSocketTCP::accept():Calling bind()\n");
      if (dbg) fflush(stdout);
      if (::bind(sock, (struct sockaddr *)&acceptAddr, 
                 sizeof(acceptAddr)) >= 0)
      {
         sna = new QSocketNotifier(sock, QSocketNotifier::Read, this);
         QObject::connect(sna, SIGNAL(activated(int)), 
                          this, SLOT(readyAccept(int)));

         QObject::connect(this, SIGNAL(status(int)),
                          pParent, pSlotStatus);
   
         if (dbg) fprintf(stdout, "xSocketTCP::accept():Calling listen()\n");
         if (dbg) fflush(stdout);
         ::listen(sock, 5);
         fd = sock;
         if ((pTimeVal = Resources->get(wdtRes, "accepttime", "AcceptTime"))
             == NULL)
            timeOut = 300000;
         else
         {
            if ((timeOut = atol(pTimeVal)) == 0)
               timeOut = 300000;
         }
         QObject::connect(pTimer, SIGNAL(timeout()), this, SLOT(timeout()));
         pTimer->start(timeOut);

         if (dbg) fprintf(stdout, "xSocketTCP::accept():fd = %d\n", fd);
         if (dbg) fflush(stdout);
      }
      else 
      {
         if (dbg) fprintf(stdout, "xSocketTCP::accept():Error binding name\n");
         if (dbg) fflush(stdout);
         err = xSocketTCP::ERROR_BINDINGSOCKET;
      }
   }
   else
   {
      if (dbg) fprintf(stdout, "xSocketTCP::accept():Error opening socket\n");
      if (dbg) fflush(stdout);
         err = xSocketTCP::ERROR_OPENINGSOCKET;
   }
   if (dbg) fprintf(stdout, "xSocketTCP::accept():Exit(%d)\n", fd);
   if (dbg) fflush(stdout);
   err = rv;
}

xSocketTCP::~xSocketTCP()
{
   if (snw)
   {
      QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
      delete snw;
   }
   snw = NULL;
   if (snr)
   {
      QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
      delete snr;
   }
   snr = NULL;
   if (dbf)
      fclose(dbf);
   if (pTimer)
      delete pTimer;
}

void xSocketTCP::retryConnect(int sock)
{
   int n;

   if (dbg) fprintf(stdout, "xSocketTCP::retryConnect(%d:%d):Enter\n", sock, fd);
   if (dbg) fflush(stdout);
   if ((n = fcntl(sock, F_GETFL, 0)) < 0)
      return;
   n |= FNDELAY;
   fcntl(sock, F_SETFL, n); // SVR4 non-blocking incantation

   if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Calling ::connect!!!\n");
   if (dbg) fflush(stdout);
   if (::connect(sock, (struct sockaddr *)&connAddr, sizeof(connAddr)) >= 0)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Success!!!\n");
      if (dbg) fflush(stdout);
      pTimer->stop();
      if (snc)
      {
         QObject::disconnect(snc, SIGNAL(activated(int)), this, SLOT(retryConnect(int)));
         delete snc;
      }
      snc = NULL;

      snr = new QSocketNotifier(sock, QSocketNotifier::Read, this);
      connect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));

      snw = new QSocketNotifier(sock, QSocketNotifier::Write, this);
      connect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
      if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():setting snw->Enabled to %d\n",
                               FALSE);
      if (dbg) fflush(stdout);
      snw->setEnabled( FALSE );
      emit status(0);
   }
   else
   {
      if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Connection?? Uh??\n");
      if (dbg) fflush(stdout);
      if (errno != EWOULDBLOCK &&
          errno != EINPROGRESS &&
          errno != EALREADY &&
          errno != EAGAIN)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Failed!!!\n");
         if (dbg) fflush(stdout);
         pTimer->stop();
         close(sock);
         fd = -1;
         if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Connection failed:%s\n", strerror(errno));
         if (dbg) fflush(stdout);
         perror("xSocketTCP::retryConnect():Connection Failed!!!\n");
         if (snc)
         {
            QObject::disconnect(snc, SIGNAL(activated(int)), this, SLOT(retryConnect(int)));
            delete snc;
         }
         snc = NULL;
         pTimer->stop();
         QObject::disconnect(pTimer, SIGNAL(timeout()), this, SLOT(timeout()));
         emit status(errno);
      }
      else
      {
         if (dbg) fprintf(stdout, "xSocketTCP::retryConnect():Expected error!\n");
         if (dbg) fflush(stdout);
      }
   }
   if (dbg) fprintf(stdout, "xSocketTCP::retryConnect(%d:%d):Exit\n", sock, fd);
   if (dbg) fflush(stdout);
}

void xSocketTCP::readyAccept(int sock)
{
   int n;

   if (dbg) fprintf(stdout, "xSocketTCP::readyAccept(%d:%d):Enter\n", sock, fd);
   if (dbg) fflush(stdout);
   n = sizeof(acceptAddr);
   if ((fd = ::accept(sock, (struct sockaddr *)&acceptAddr, &n)) < 0)
   {
      if (errno != EWOULDBLOCK &&
          errno != EINPROGRESS &&
          errno != EALREADY &&
          errno != EAGAIN)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Error Found!\n");
         if (dbg) fflush(stdout);
         close(fd);
         perror("xSocketTCP::readyAccept():Connection Failed!!!\n");
         if (sna)
         {
            if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Disconnecting socket!\n");
            if (dbg) fflush(stdout);
            QObject::disconnect(sna, SIGNAL(activated(int)), this, SLOT(readyAccept(int)));
            delete sna;
         }
         sna = NULL;
         if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Emiting failed signal!\n");
         if (dbg) fflush(stdout);
         emit status(errno);
         if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Back from signal!\n");
         if (dbg) fflush(stdout);
      }
   }
   else
   {
      if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Accept succeded!\n");
      if (dbg) fflush(stdout);
      pTimer->stop();

      if (sna)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Disconnecting/deleting Accept Notifier!\n");
         if (dbg) fflush(stdout);
         QObject::disconnect(sna, SIGNAL(activated(int)), this, SLOT(readyAccept(int)));
         delete sna;
      }
      sna = NULL;

      n = fcntl(fd, F_GETFL, 0);
      n |= FNDELAY;
      fcntl(fd, F_SETFL, n); // SVR4 non-blocking incantation

      snr = new QSocketNotifier(fd, QSocketNotifier::Read, this);
      connect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));

      snw = new QSocketNotifier(fd, QSocketNotifier::Write, this);
      connect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
      if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():setting snw->Enabled to %d\n",
                               FALSE);
      snw->setEnabled( FALSE );
      socketOff = FALSE;
      connectFlag = TRUE;
      if (dbg) fprintf(stdout, "xSocketTCP::readyAccept():Emitting signal!\n");
      emit status(0);
   }
   if (dbg) fprintf(stdout, "xSocketTCP::readyAccept(%d:%d):Exit\n", sock, fd);
   if (dbg) fflush(stdout);
}

void xSocketTCP::timeout()
{
   close(fd);
   connectFlag = FALSE;
   if (dbg) fprintf(stdout, "xSocketTCP::timeout():Emitting signal!\n");
   emit status(ETIMEDOUT);
}

void xSocketTCP::readyRead(int sfd)
{
   int n;
   char buf[512];

   if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead(%d:%d):Enter\n", sfd, fd);
   if (dbg) fflush(stdout);
   if ((n = ::read(sfd, buf, sizeof(buf - 1))) < 0)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::readyRead():Error Reading from Socket %d\n", sfd);
      if (dbg) fflush(stdout);
      close(sfd);
      if (sfd == fd)
      {
         if (snw)
         {
            QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
            delete snw;
         }
         snw = NULL;
         if (snr)
         {
            QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
            delete snr;
         }
         snr = NULL;
         connectFlag = FALSE;
         if (dbg) fprintf(stdout, "xSocketTCP::readyRead():SOCKET %d:%d CLOSED!\n", sfd, fd);
         if (dbg) fflush(stdout);
         if (dbg) fprintf(stdout, "xSocketTCP::readyRead():Emitting Socket Closed Signal\n");
         if (dbg) fflush(stdout);
         close(fd);
         emit socketClosed();
         fd = -1;
         delete this;
      }
   }
   else if (n > 0)
   {
      if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead(%d):Read %d chars from socket\n", sfd, n);
      if (dbg) fflush(stdout);
      buf[n] = '\0';
      if (dbf) fprintf(dbf, buf);
      if (dbf) fflush(dbf);
      if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead():Emitin readFromSocket signal\n");
      if (dbg > 3) fflush(stdout);
      emit readFromSocket(buf);
      if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead():Back from sending signal\n");
      if (dbg > 3) fflush(stdout);
   }
   else
   {
      connectFlag = FALSE;
      if (dbg) fprintf(stdout, "xSocketTCP::readyRead():SOCKET %d CLOSED!\n", sfd);
      if (dbg) fflush(stdout);
      close(sfd);
      if (sfd == fd)
      {
         if (snw)
         {
            QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
            delete snw;
         }
         snw = NULL;
         if (snr)
         {
            QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
            delete snr;
         }
         snr = NULL;
         fd = -1;
         if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead():Emitting Socket Closed Signal\n");
         if (dbg) fflush(stdout);
         emit socketClosed();
      }
      delete this;
   }
   if (dbg > 3) fprintf(stdout, "xSocketTCP::readyRead(%d:%d):Exit\n", sfd, fd);
}

void xSocketTCP::readyWrite(int sfd)
{
   int n;
   bool tf;
   char buf[512];

   if (dbg) fprintf(stdout, "xSocketTCP::readyWrite(%d:%d):Enter\n", sfd, fd);
   if (dbg) fflush(stdout);
   if ((n = writeBuffer.length()) > 0)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::readyWrite(%d:%d):writing %d chars, |%s|, to socket\n", sfd, fd, n, (const char *)writeBuffer);
      if (dbg) fflush(stdout);
      sprintf(buf, "Client>>|%s|\n", (const char *)writeBuffer);
      if (dbf) fprintf(dbf, buf);
      if (dbf) fflush(dbf);
      if ((n = ::write(fd, (const char *)writeBuffer, n)) > 0)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::readyWrite():Wrote %d chars to socket\n", n);
         if (dbg) fprintf(stdout, "xSocketTCP::readyWrite():Removing string from buffer\n");
         if (dbg) fflush(stdout);
         writeBuffer.remove(0, n);

         if (dbg) fprintf(stdout, "xSocketTCP::readyWrite():Chars removed\n");
         if (dbg) fflush(stdout);
      }
      else if (n < 0)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::readyWrite():Error writing!\n");
         if (dbg) fflush(stdout);
         close(sfd);
         if (sfd == fd)
         {
            fd = -1;
            writeBuffer = "";
            connectFlag = FALSE;
            emit socketClosed();
            if (snw)
            {
               QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
               delete snw;
            }
            snw = NULL;
            if (snr)
            {
               QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
               delete snr;
            }
            snr = NULL;
            delete this;
         }
      }
      else
      {
         if (dbg) fprintf(stdout, "xSocketTCP::readyWrite(%d:%d):Write SOCKET CLOSED!\n", sfd, fd);
         if (dbg) fflush(stdout);
         close(sfd);
         if (sfd == fd)
         {
            fd = -1;
            writeBuffer = "";
            connectFlag = FALSE;
            emit socketClosed();
            if (snw)
            {
               QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
               delete snw;
            }
            snw = NULL;
            if (snr)
            {
               QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
               delete snr;
            }
            snr = NULL;
            delete this;
         }
      }
   }
   if (snw)
   {
      tf = !writeBuffer.isEmpty();
      if (dbg) fprintf(stdout, "xSocketTCP::readyWrite():setting snw->Enabled to %d\n",
                               tf);
      if (dbg) fflush(stdout);
      snw->setEnabled(tf);
   }
   if (dbg) fprintf(stdout, "xSocketTCP::readyWrite(%d:%d):Done\n", sfd,fd);
   if (dbg) fflush(stdout);
}

struct sockaddr_in xSocketTCP::socketName()
{
   struct sockaddr_in addr;
   int x;

   addr.sin_family = AF_INET;
   addr.sin_port = 0;
   addr.sin_addr.s_addr = htonl(INADDR_ANY);

   if (fd >= 0)
   {
      x = sizeof(addr);
      getsockname(fd, (struct sockaddr *)&addr, &x);
   }
   return(addr);
}

void xSocketTCP::off()
{
   if (dbg) fprintf(stdout, "xSocketTCP::off():Turning Socket Off!\n");
   if (dbg) fflush(stdout);
   socketOff = TRUE;
}

void xSocketTCP::sendToSocket(const char *pText)
{
   bool tf;

   if (!socketOff && snw != NULL && snr != NULL)
   {
//      if (connectFlag == TRUE && fd >= 0)
      if (fd >= 0)
      {
         if (dbg) fprintf(stdout, "xSocketTCP::sendToSocket():Adding |%s| to writeBuffer\n", pText);
         if (dbg) fflush(stdout);
         writeBuffer += pText;
      }
      tf = !writeBuffer.isEmpty();
      if (dbg) fprintf(stdout, "xSocketTCP::sendToSocket():setting snw->Enabled to %d\n",
                               tf);
      snw->setEnabled(tf);
   }
   else
   {
      if (dbg) fprintf(stdout, "xSocketTCP::sendToSocket():Read or Write slot not connected!\n");
      if (dbg) fflush(stdout);
   }
}

void xSocketTCP::stopConnect()
{
   int x = fd;

   if (dbg) fprintf(stdout, "xSocketTCP::stopConnect(%d):Enter\n", fd);
   if (dbg) fflush(stdout);
   pTimer->stop();
   QObject::disconnect(pTimer, SIGNAL(timeout()), this, SLOT(timeout()));
   disconnectTCP();
   if (snc)
   {
      QObject::disconnect(snc, SIGNAL(activated(int)), this, SLOT(retryConnect(int)));
      delete snc;
      errno = ECONNABORTED;
      emit status(errno);
   }
   snc = NULL;
   if (dbg) fprintf(stdout, "xSocketTCP::stopConnect(%d):Exit\n", x);
   if (dbg) fflush(stdout);
//   delete this;
}

int xSocketTCP::disconnectTCP()
{
   int rv = 0, x = fd;

   if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP(%d):Enter\n", fd);
   if (dbg) fflush(stdout);
   if (snw != NULL)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Disconnecting snw\n");
      if (dbg) fflush(stdout);
      QObject::disconnect(snw, SIGNAL(activated(int)), this, SLOT(readyWrite(int)));
      delete snw;
   }
   snw = NULL;
   if (snr != NULL)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Disconnecting snr\n");
      if (dbg) fflush(stdout);
      QObject::disconnect(snr, SIGNAL(activated(int)), this, SLOT(readyRead(int)));
      delete snr;
   }
   snr = NULL;
   if (sna != NULL)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Disconnecting sna\n");
      if (dbg) fflush(stdout);
      QObject::disconnect(sna, SIGNAL(activated(int)), this, SLOT(readyAccept(int)));
      delete sna;
   }
   sna = NULL;
   if (snc != NULL)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Disconnecting snc\n");
      if (dbg) fflush(stdout);
      QObject::disconnect(snc, SIGNAL(activated(int)), this, SLOT(retryConnect(int)));
      delete snc;
   }
   snc = NULL;
   if (fd >= 0)
   {
      if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Shutting down Socket!\n");
      if (dbg) fflush(stdout);
      rv = shutdown(fd, 2);
   }
   if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Calling readyRead()\n");
   if (dbg) fflush(stdout);
   connectFlag = FALSE;
   fd = -1;
   if (dbg) fprintf(stdout, "xSocketTCP::disconnectTCP():Exit(%d)\n", x);
   if (dbg) fflush(stdout);
   delete this;
   return(rv);
}

#include "xSocket.moc"

