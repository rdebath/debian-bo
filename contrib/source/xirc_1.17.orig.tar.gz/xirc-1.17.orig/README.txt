This  release  is an interim release to make xIrc compile and function
with  qt-1.0.  There  have  been  a  few  small  bug fixes and no real
enhancements  made.  See  "Changes..."  below  for the obvious changes
made.

Now  that  I  have a bit more free time for play, I hope to be making
xIrc  even  niftier in the up and coming months. Maybe even knocking
out some of the items in my wish list :)).

You  will  find  that there is now a users guide in xIrc.dvi, xIrc.ps,
xIrc.doc.  Take  your  choice  of  formats. The xIrc.doc file is plain
ASCII  for  those  of  you  with very limited text abilities. I highly
recommend  the  others  as this file is not very pretty. It was derived
from  xIrc.dvi  using dvi2tty. As handy as this program is, it doesn't
(and  I can understand why) handle going from a proportional font to a
fixed  font format very well. It also does not handle '_' at all well,
they  come  out  as  '='.  Therefore, in the names for the tags in the
xIrc.default file, substitute '_' where you see aa '='. In a pinch the
ASCII  file  beats  no  documentation at all. For you who are brave at
heart  and have alot of disk space, I provided xIrc.tex so that if you
run  'Make  doc'  it will create the various documents using latex and
dvi2tty  programs.  My personal preference at this point has been xdvi
for viewing purposes. I has much cleaner fonts and in my humble opinion
looks  a  nicer than ghost-view. Mind you I like and use ghost-view, but
if I had my druthers...

*** Late breaking note ***

Sadly, my dvips keeps giving me segmentation faults. So xIrc.ps is not in 
this release
Description:

**************************

xIrc is as the name implies, and IRC Client program that runs under X.
It is written in C++ and the binary for it provided was compiled using
gcc 2.7.2 and qt-1.0 using the ELF libraries. See the INSTALL document
provided for details on building it if you need or desire too, have no
fear, it's reasonably easy to build.


Plea for suggestions, bug reports and praise (if any is deserved):

Being  that  this  code  is  still  Beta,  I would appreciate any help
offered  in  finding any bugs that may crop up. This will be mostly in
the  form  of  turning on the various debug flags I have embedded then
mailing  me the output. Also, any suggestions for additions or changes
to  it's  look  and  feel will be appreciated. I cannot guarantee that
they will be implemented, but all will be taken into consideration.


Changes not reflected in the Documentation:

Added  the  command  "/msg <nick> <test>" to message other's without
opening a window to them.

The  X  resources  for the underlying widgets used have changed some.
here is a list of those changes I could find:

 Deletions:
   PushBtnFrame

 Additions:
   Input.TextHighlight
   Input.TextEnabled
   Input.BaseHighlight

I  doubt  that  changing  the  new resources for "input" will have any
effect  on  the  appearance of the application. They were put in place
for another application. I doubt xIrc uses the functionality needed to
make them take effect.

Known Bugs:

Well I do know there are probably numerous bugs. The one that comes to
mind  though  is  a  real nasty one that I'm still working at tracking
down. The program tends to crash if you get disconnected from a server
unexpectedly  then  try  to reconnect and fail. Any help from someone
with  a debugger that can detect a class making errant writes would be
much appreciated.

Also,  accepting  incoming  DCC  chat  requests can crash the program
after  one  has  already  been  closed. This is a very order dependent
problem,  and  if I'm not mistaken, if you close the connection first,
there won't be any problems.



