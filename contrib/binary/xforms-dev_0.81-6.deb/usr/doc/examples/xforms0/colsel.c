#include "forms.h"
int
main(int argc, char **argv)
{
   fl_initialize(&argc, argv, "FormDemo", 0, 0);
   fl_show_colormap(0);
   return 0;
}
